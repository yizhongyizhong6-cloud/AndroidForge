МЕТРО 2D — МАШИНИСТ (Android-проект)

Причина исходной проблемы: исходный архив содержал только index.html и README.txt, то есть браузерную игру, но не Android/Gradle-проект. Поэтому AndroidForge не мог определить версию Android Gradle Plugin (agp_version: null) и собрать APK.

Что исправлено:
- добавлен settings.gradle с подключением модуля :app;
- добавлен корневой build.gradle с Android Gradle Plugin 8.6.1;
- добавлен app/build.gradle (compileSdk 35, Java 17, minSdk 23);
- добавлен AndroidManifest.xml и MainActivity;
- игра помещена в app/src/main/assets/index.html и запускается через Android WebView;
- включены JavaScript и DOM storage, необходимые для игры и сохранения прогресса.

Как собрать:
1. Загрузите весь этот ZIP в AndroidForge.
2. Откройте корень Metro2D_Project (папка, в которой лежат settings.gradle и build.gradle).
3. Запустите сборку Android/Gradle.

local.properties намеренно не включён: путь к Android SDK зависит от среды сборки, AndroidForge должен задать его сам.

Примечание: синтез речи зависит от WebView и голосовых пакетов устройства. APK в этой среде не собран, поэтому сборку нужно проверить в AndroidForge.
