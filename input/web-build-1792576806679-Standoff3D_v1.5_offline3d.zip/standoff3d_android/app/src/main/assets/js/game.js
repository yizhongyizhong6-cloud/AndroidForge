/* ============================================================
   STANDOFF 3D — движок (Three.js r128)
   ============================================================ */
(function(){
'use strict';
if (typeof THREE === 'undefined') {
  console.error('THREE missing');
  return;
}
try {


// ---------- DOM ----------
const wrapper = document.getElementById('game-wrapper');
const container = document.getElementById('game-container');
const $ = id => document.getElementById(id);
const $$ = id => { const e=$(id); return e; };
const fpsVal=$('fps-val'), frameTimeEl=$('frame-time'), entityCount=$('entity-count');
const hpVal=$('hp-val'), armorVal=$('armor-val'), ammoCur=$('ammo-cur'), ammoMax=$('ammo-max');
const scoreCtEl=$('score-ct'), scoreTrEl=$('score-tr');
const killFeedEl=$('kill-feed'), vignette=$('damage-vignette'), scopeEl=$('sniper-scope');
const hitmarkerEl=$('hitmarker'), crosshairEl=$('crosshair');
const minimap=$('minimap'), mmCtx=minimap.getContext('2d');
const fpsGraph=$('fps-graph'), fgCtx=fpsGraph.getContext('2d');

// ---------- AUDIO (синтез, без ассетов) ----------
let AC=null;
function audio(){ if(!AC){ try{ AC=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } if(AC && AC.state==='suspended') AC.resume(); return AC; }
function sfxShot(pitch){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime, len=Math.floor(ac.sampleRate*0.11);
    const buf=ac.createBuffer(1,len,ac.sampleRate), d=buf.getChannelData(0);
    for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/len,2);
    const src=ac.createBufferSource(); src.buffer=buf;
    const f=ac.createBiquadFilter(); f.type='lowpass'; f.frequency.value=pitch;
    const g=ac.createGain(); g.gain.setValueAtTime(0.22,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.12);
    src.connect(f); f.connect(g); g.connect(ac.destination); src.start(t);
}
function sfxHit(){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime;
    const o=ac.createOscillator(), g=ac.createGain();
    o.type='square'; o.frequency.setValueAtTime(900,t); o.frequency.exponentialRampToValueAtTime(300,t+0.06);
    g.gain.setValueAtTime(0.12,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.07);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t+0.08);
}
function sfxDie(){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime;
    const o=ac.createOscillator(), g=ac.createGain();
    o.type='sawtooth'; o.frequency.setValueAtTime(220,t); o.frequency.exponentialRampToValueAtTime(60,t+0.35);
    g.gain.setValueAtTime(0.18,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.4);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t+0.45);
}

// ---------- THREE: сцена ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87a0b8);
scene.fog = new THREE.Fog(0x87a0b8, 60, 160);

const camera = new THREE.PerspectiveCamera(75, innerWidth/innerHeight, 0.08, 400);
camera.rotation.order='YXZ';
scene.add(camera);

const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference:'high-performance', alpha:false });
renderer.setClearColor(0x87a0b8, 1);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
if (THREE.sRGBEncoding !== undefined) renderer.outputEncoding = THREE.sRGBEncoding;
if (THREE.ACESFilmicToneMapping !== undefined) {
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.2;
}
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
renderer.setSize(window.innerWidth || 360, window.innerHeight || 640, false);
renderer.domElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;display:block;z-index:1;';
if (!container) throw new Error('#game-container not found');
container.insertBefore(renderer.domElement, container.firstChild);

const hemi = new THREE.HemisphereLight(0xd0e4ff, 0x6b5a40, 1.15);
scene.add(hemi);
const amb = new THREE.AmbientLight(0xffffff, 0.35); scene.add(amb);
const sun = new THREE.DirectionalLight(0xfff0d0, 1.25);
sun.position.set(35, 55, 25);
sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left=-45; sun.shadow.camera.right=45;
sun.shadow.camera.top=45; sun.shadow.camera.bottom=-45;
sun.shadow.camera.far=140;
scene.add(sun);

// ---------- КАРТА ----------
const WORLD = 30; // полуразмер арены
const colliders = [];   // {minX,maxX,minZ,maxZ,minY,maxY}
const wallMeshes = [];  // для рейкастов
const mapObjects = [];  // геометрия текущей карты

// Процедурные текстуры: создаются локально, без скачивания картинок и без тяжёлых ассетов.
const surfaceTextures = {};
function makeSurfaceTexture(kind){
    if(surfaceTextures[kind]) return surfaceTextures[kind];
    const cv=document.createElement('canvas'); cv.width=512; cv.height=512;
    const cx=cv.getContext('2d');
    if(kind==='concrete'){
        cx.fillStyle='#77766e'; cx.fillRect(0,0,512,512);
        for(let i=0;i<9000;i++){ const x=Math.random()*512,y=Math.random()*512,a=0.025+Math.random()*0.12; cx.fillStyle=Math.random()>.5?`rgba(235,230,210,${a})`:`rgba(20,24,26,${a})`; cx.fillRect(x,y,1+Math.random()*3,1+Math.random()*2); }
        cx.strokeStyle='rgba(25,29,30,.22)'; cx.lineWidth=2;
        for(let y=0;y<512;y+=128){cx.beginPath();cx.moveTo(0,y);cx.lineTo(512,y);cx.stroke();}
        for(let x=0;x<512;x+=128){cx.beginPath();cx.moveTo(x,0);cx.lineTo(x,512);cx.stroke();}
    } else if(kind==='crate'){
        cx.fillStyle='#98784b'; cx.fillRect(0,0,512,512);
        for(let y=12;y<512;y+=58){cx.fillStyle='rgba(43,29,15,.16)';cx.fillRect(0,y,512,4);cx.fillStyle='rgba(235,196,129,.13)';cx.fillRect(0,y+5,512,2);}
        for(let i=0;i<2600;i++){cx.fillStyle=Math.random()>.5?'rgba(30,22,13,.10)':'rgba(255,225,170,.09)';cx.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*8,1+Math.random()*2);}
        cx.strokeStyle='rgba(35,25,14,.55)';cx.lineWidth=8;cx.strokeRect(8,8,496,496);cx.lineWidth=3;cx.strokeRect(20,20,472,472);
    } else {
        cx.fillStyle='#85847d';cx.fillRect(0,0,512,512);
        for(let i=0;i<6500;i++){let a=.02+Math.random()*.10;cx.fillStyle=Math.random()>.5?`rgba(255,255,255,${a})`:`rgba(10,12,14,${a})`;cx.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*2,1+Math.random()*2);}
        cx.strokeStyle='rgba(20,24,28,.12)';cx.lineWidth=2;for(let y=64;y<512;y+=64){cx.beginPath();cx.moveTo(0,y);cx.lineTo(512,y);cx.stroke();}
    }
    const tex=new THREE.CanvasTexture(cv); tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.anisotropy= Math.min(8, renderer.capabilities.getMaxAnisotropy()); tex.encoding=THREE.sRGBEncoding; tex.needsUpdate=true;
    surfaceTextures[kind]=tex; return tex;
}
function addBox(x, z, w, h, d, color, opts){
    opts = opts || {};
    const isCrate = color===0x6b5432 || color===0x77603a || color===0x5c4a2e;
    const tex=makeSurfaceTexture(isCrate?'crate':'concrete');
    const m = new THREE.Mesh(
        new THREE.BoxGeometry(w,h,d),
        new THREE.MeshStandardMaterial({ color: color, map:tex, roughness: opts.rough!=null?opts.rough:0.88, metalness:0.03 })
    );
    m.position.set(x, opts.y!=null?opts.y:h/2, z);
    m.castShadow = true; m.receiveShadow = true;
    scene.add(m); mapObjects.push(m);
    colliders.push({ minX:x-w/2, maxX:x+w/2, minZ:z-d/2, maxZ:z+d/2, minY:(opts.y!=null?opts.y:h/2)-h/2, maxY:(opts.y!=null?opts.y:h/2)+h/2 });
    wallMeshes.push(m);
    return m;
}

function buildMap(mapName){
    // Удаляем геометрию прошлой карты, не трогая игроков, оружие и эффекты.
    for(const obj of mapObjects){
        scene.remove(obj);
        if(obj.geometry) obj.geometry.dispose();
        if(obj.material){
            const mats=Array.isArray(obj.material)?obj.material:[obj.material];
            mats.forEach(m=>m.dispose());
        }
    }
    mapObjects.length=0; colliders.length=0; wallMeshes.length=0;

    const floorColors={arena:0x8d918e,dust:0xc2a77b,mirage:0xb6a58a};
    const groundTex=makeSurfaceTexture('floor');
    groundTex.repeat.set(12,12);
    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(WORLD*2+4, WORLD*2+4),
        new THREE.MeshStandardMaterial({ color:floorColors[mapName]||floorColors.arena, map:groundTex, roughness:0.96, metalness:0.01 })
    );
    ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground); mapObjects.push(ground);
    const grid = new THREE.GridHelper(WORLD*2, WORLD, 0x3d4a5c, 0x2c3542);
    grid.position.y=0.01; scene.add(grid); mapObjects.push(grid);

    const wallColor=mapName==='dust'?0x9a835f:(mapName==='mirage'?0xb0a18b:0x39424f);
    addBox(0, -WORLD-0.5, WORLD*2+4, 5, 1, wallColor);
    addBox(0,  WORLD+0.5, WORLD*2+4, 5, 1, wallColor);
    addBox(-WORLD-0.5, 0, 1, 5, WORLD*2+4, wallColor);
    addBox( WORLD+0.5, 0, 1, 5, WORLD*2+4, wallColor);

    if(mapName==='dust'){
        // Карта в духе классических пустынных соревновательных арен: длинный мид,
        // две открытые площадки и обходные проходы. Геометрия сделана заново.
        const stone=0xb7a078, dark=0x8b7455, crate=0x6b5432;
        addBox(0,0,2.0,3.2,25,stone);                 // длинная центральная линия
        addBox(-11,-15,12,3.4,2.0,stone); addBox(-11,-6,2.0,3.4,16,stone);
        addBox(-19,-2,8,3.4,2.0,dark); addBox(-22,5,2.0,3.4,13,stone);
        addBox(11,15,12,3.4,2.0,stone); addBox(11,6,2.0,3.4,16,stone);
        addBox(19,2,8,3.4,2.0,dark); addBox(22,-5,2.0,3.4,13,stone);
        addBox(-8,22,9,2.2,1.5,crate); addBox(8,-22,9,2.2,1.5,crate);
        addBox(-15,20,3,1.4,3,crate); addBox(15,-20,3,1.4,3,crate);
        addBox(0,-12,5,1.6,2,crate); addBox(0,12,5,1.6,2,crate);
        addBox(-4,4,2,2.0,2,crate); addBox(4,-4,2,2.0,2,crate);
    } else if(mapName==='mirage'){
        // Оригинальная компактная карта с центральной площадью, арками и боковыми маршрутами,
        // вдохновлённая городской пустынной эстетикой, без копирования игровых ассетов.
        const plaster=0xc1ad8f, shade=0x82745f, crate=0x6b5432;
        addBox(-12,0,2.2,4.2,26,plaster); addBox(12,0,2.2,4.2,26,plaster);
        addBox(0,-12,22,3.6,2.2,plaster); addBox(0,12,22,3.6,2.2,plaster);
        addBox(-5,0,2.0,2.4,8,shade); addBox(5,0,2.0,2.4,8,shade);
        addBox(0,-4,7,2.0,1.5,crate); addBox(0,4,7,2.0,1.5,crate);
        addBox(-19,-17,10,3.2,2.0,plaster); addBox(-23,-10,2.0,3.2,14,plaster);
        addBox(19,17,10,3.2,2.0,plaster); addBox(23,10,2.0,3.2,14,plaster);
        addBox(-17,10,4,1.7,3,crate); addBox(17,-10,4,1.7,3,crate);
        addBox(-7,21,5,1.4,2,crate); addBox(7,-21,5,1.4,2,crate);
        addBox(-20,0,3,2.2,3,crate); addBox(20,0,3,2.2,3,crate);
    } else {
        // Исходная арена.
        addBox(0, 0, 10, 2.6, 1.2, 0x4a4038);
        addBox(-12, -10, 2, 2.2, 2, 0x6b5432);
        addBox(-9.2, -10.5, 1.6, 1.4, 1.6, 0x77603a);
        addBox(12, -12, 2, 2.2, 2, 0x6b5432);
        addBox(9, 12, 2.4, 2.2, 2.4, 0x6b5432);
        addBox(-11, 11, 2, 2.2, 2, 0x6b5432);
        addBox(-13, 13.2, 1.5, 1.3, 1.5, 0x77603a);
        addBox(0, -18, 6, 2.4, 1, 0x4a5568);
        addBox(0, 18, 6, 2.4, 1, 0x4a5568);
        addBox(-20, 0, 1, 2.6, 8, 0x4a5568);
        addBox(20, 2, 1, 2.6, 8, 0x4a5568);
        addBox(16, -4, 3, 1.6, 3, 0x5c4a2e);
        addBox(-16, 5, 3, 1.6, 3, 0x5c4a2e);
    }
    // Small visual accents; decorative meshes are tracked so switching maps cleans them up.
    const stripMat = new THREE.MeshBasicMaterial({ color:mapName==='dust'?0xffc16c:(mapName==='mirage'?0xf0d5a1:0xff8c00) });
    const accents = mapName==='arena' ? [[0,-0.72,10.4,0.06],[0,0.72,10.4,0.06]] : [[-7,0,0.08,12],[7,0,0.08,12]];
    accents.forEach(a=>{
        const st=new THREE.Mesh(new THREE.BoxGeometry(a[2],0.06,a[3]||0.06), stripMat);
        st.position.set(a[0], mapName==='arena'?2.65:0.035, a[1]); scene.add(st); mapObjects.push(st);
    });
}
let currentMap='arena';
buildMap(currentMap);
try { camera.position.set(0, 1.7, 24); renderer.render(scene, camera); } catch(e) { console.error(e); } placeSites();

// ---------- ИГРОК ----------
const player = {
    pos: new THREE.Vector3(0, 0, 24),
    vel: new THREE.Vector3(),
    yaw: 0, pitch: 0,
    hp: 100, armor: 100,
    crouch: false, onGround: true,
    alive: true, eyeH: 1.7,
    money: 800
};

// ---------- ОРУЖИЕ ----------
const WEAPONS = {
    1:{ name:'AK-47',  cat:'rifle',  price:2700, dmg:36, rpm:600, mag:30, reserve:90,  auto:true,  reloadTime:2200, aimFov:55, spread:0.013, recoil:0.015, scoped:false, snd:1750, pellets:1 },
    2:{ name:'M4A1',   cat:'rifle',  price:3100, dmg:33, rpm:680, mag:30, reserve:90,  auto:true,  reloadTime:2000, aimFov:55, spread:0.010, recoil:0.011, scoped:false, snd:2200, pellets:1 },
    3:{ name:'AWP',    cat:'sniper', price:4750, dmg:115,rpm:41,  mag:5,  reserve:15,  auto:false, reloadTime:3200, aimFov:18, spread:0.001, recoil:0.055, scoped:true,  snd:900,  pellets:1 },
    4:{ name:'GLOCK',  cat:'pistol', price:200,  dmg:26, rpm:400, mag:20, reserve:120, auto:false, reloadTime:1500, aimFov:62, spread:0.015, recoil:0.009, scoped:false, snd:2600, pellets:1 },
    5:{ name:'DEAGLE', cat:'pistol', price:700,  dmg:63, rpm:267, mag:7,  reserve:35,  auto:false, reloadTime:2000, aimFov:58, spread:0.012, recoil:0.028, scoped:false, snd:1100, pellets:1 },
    6:{ name:'MP9',    cat:'smg',    price:1250, dmg:26, rpm:857, mag:30, reserve:120, auto:true,  reloadTime:1800, aimFov:60, spread:0.018, recoil:0.008, scoped:false, snd:2400, pellets:1 },
    7:{ name:'NOVA',   cat:'shotgun',price:1200, dmg:22, rpm:68,  mag:8,  reserve:32,  auto:false, reloadTime:2800, aimFov:60, spread:0.045, recoil:0.035, scoped:false, snd:1400, pellets:8 },
    8:{ name:'FAMAS',  cat:'rifle',  price:2250, dmg:30, rpm:666, mag:25, reserve:90,  auto:true,  reloadTime:2100, aimFov:56, spread:0.012, recoil:0.012, scoped:false, snd:2000, pellets:1 }
};
const owned = { 4:true };
const wstate = {};
for (const k in WEAPONS){ wstate[k]={ ammo:WEAPONS[k].mag, reserve:WEAPONS[k].reserve }; }
let curWeapon = 4, lastShot = 0, reloading = false, reloadTimer = null;
let aiming = false, fireHeld = false, bloom = 0;
let sensitivity = 1.0;
let gunKick = { x:0, y:0, z:0 }, gunBob = 0, gunSway = 0;
// --- game modes / rounds ---
const MODE = { TDM:'tdm', PLANT:'plant' };
let gameMode = MODE.TDM;
let playerSide = 'ct'; // 'ct' спецназ | 't' террористы
const ROUND_BUY_TIME = 10, ROUND_TIME_TDM = 75, ROUND_TIME_PLANT = 100, ROUNDS_TO_WIN = 8;
let roundState = 'buy', roundTimer = ROUND_BUY_TIME, roundNumber = 1;
let playerMoney = 800;
const BOMB_FUSE = 35, PLANT_TIME = 3.5, DEFUSE_TIME = 5.5;
let bomb = null, defuseProgress = 0, plantProgress = 0;
let hasBomb = false; // игрок-T несёт бомбу
let nades = 0; // HE гранаты
let lastNade = 0;
const GRENADE_PRICE = 300;
const knifeReady = { slot: 9 };
WEAPONS[9] = { name:'НОЖ', cat:'melee', price:0, dmg:55, rpm:120, mag:1, reserve:0, auto:false, reloadTime:0, aimFov:70, spread:0.0, recoil:0.0, scoped:false, snd:800, pellets:1, melee:true };
owned[9] = true;
wstate[9] = { ammo:1, reserve:0 };

const BOMB_SITES = {
  arena:[{x:0,z:-12,r:3.5,name:'A'},{x:12,z:10,r:3.2,name:'B'}],
  dust:[{x:-15,z:-8,r:3.5,name:'A'},{x:15,z:8,r:3.5,name:'B'}],
  mirage:[{x:-10,z:10,r:3.2,name:'A'},{x:12,z:-8,r:3.2,name:'B'}]
};
let siteMarkers = [];
function nearSite(pos){
  const sites = BOMB_SITES[currentMap]||BOMB_SITES.arena;
  for(const s of sites){ if(Math.hypot(pos.x-s.x,pos.z-s.z)<s.r) return s; }
  return null;
}
function clearSites(){ siteMarkers.forEach(m=>{ scene.remove(m); if(m.geometry)m.geometry.dispose(); }); siteMarkers=[]; }
function placeSites(){
  clearSites();
  if(gameMode!==MODE.PLANT) return;
  (BOMB_SITES[currentMap]||BOMB_SITES.arena).forEach(s=>{
    const ring=new THREE.Mesh(new THREE.RingGeometry(s.r*0.85,s.r,32), new THREE.MeshBasicMaterial({color:0xff8c00,transparent:true,opacity:0.35,side:THREE.DoubleSide}));
    ring.rotation.x=-Math.PI/2; ring.position.set(s.x,0.05,s.z); scene.add(ring); siteMarkers.push(ring);
  });
}

// viewmodel оружия (примитивы)
const gunGroup = new THREE.Group();
camera.add(gunGroup);
const muzzleLight = new THREE.PointLight(0xffb347, 0, 9);
muzzleLight.position.set(0.15,-0.1,-1.0);
camera.add(muzzleLight);

function buildGun(slot){
    while(gunGroup.children.length) gunGroup.remove(gunGroup.children[0]);
    const g = gunGroup;
    const M = (c,r,m,e)=> new THREE.MeshStandardMaterial({color:c,roughness:r!=null?r:0.45,metalness:m!=null?m:0.55,emissive:e||0x000000,emissiveIntensity:e?0.3:0});
    const black=M(0x1a1e24,0.4,0.7), steel=M(0x3a424e,0.35,0.85), dark=M(0x12151a,0.5,0.6);
    const wood=M(0x6b4423,0.75,0.05), polymer=M(0x2a3038,0.55,0.25), grip=M(0x1e2228,0.7,0.15);
    const orange=M(0xff8c00,0.4,0.3,0x3a1e00), chrome=M(0x9aa3ad,0.2,0.95);
    const add=(geo,mat,x,y,z,rx,ry,rz)=>{ const mesh=new THREE.Mesh(geo,mat); mesh.position.set(x,y,z); if(rx||ry||rz) mesh.rotation.set(rx||0,ry||0,rz||0); g.add(mesh); return mesh; };
    if(slot===1){ // AK-47
        add(new THREE.BoxGeometry(0.055,0.08,0.52), black, 0,0,-0.38);
        add(new THREE.CylinderGeometry(0.016,0.018,0.42,10), steel, 0,0.02,-0.82, Math.PI/2,0,0);
        add(new THREE.CylinderGeometry(0.022,0.022,0.06,8), dark, 0,0.02,-1.05, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.06,0.07,0.18), wood, 0,-0.01,-0.08);
        add(new THREE.BoxGeometry(0.048,0.14,0.07), wood, 0,-0.1,-0.28);
        add(new THREE.BoxGeometry(0.04,0.055,0.12), black, 0,-0.04,-0.48);
        add(new THREE.BoxGeometry(0.035,0.05,0.18), wood, 0,-0.02,0.16);
        add(new THREE.BoxGeometry(0.02,0.028,0.08), orange, 0,0.055,-0.55);
        add(new THREE.BoxGeometry(0.012,0.035,0.04), black, 0,0.06,-0.35);
    } else if(slot===2){ // M4A1
        add(new THREE.BoxGeometry(0.05,0.075,0.48), polymer, 0,0,-0.36);
        add(new THREE.CylinderGeometry(0.014,0.015,0.38,10), steel, 0,0.015,-0.78, Math.PI/2,0,0);
        add(new THREE.CylinderGeometry(0.02,0.02,0.08,8), dark, 0,0.015,-1.0, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.055,0.06,0.16), polymer, 0,0,-0.08);
        add(new THREE.BoxGeometry(0.045,0.13,0.065), grip, 0,-0.095,-0.26);
        add(new THREE.BoxGeometry(0.038,0.12,0.06), black, 0,-0.08,-0.45);
        add(new THREE.BoxGeometry(0.04,0.05,0.2), polymer, 0,-0.01,0.12);
        add(new THREE.BoxGeometry(0.035,0.025,0.2), black, 0,0.05,-0.5);
        add(new THREE.BoxGeometry(0.018,0.03,0.05), orange, 0,0.07,-0.55);
    } else if(slot===3){ // AWP
        add(new THREE.BoxGeometry(0.06,0.08,0.55), black, 0,0,-0.4);
        add(new THREE.CylinderGeometry(0.018,0.02,0.55,10), steel, 0,0.015,-0.95, Math.PI/2,0,0);
        add(new THREE.CylinderGeometry(0.028,0.028,0.1,8), dark, 0,0.015,-1.22, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.055,0.07,0.22), wood, 0,-0.01,-0.1);
        add(new THREE.BoxGeometry(0.045,0.12,0.07), wood, 0,-0.09,-0.22);
        add(new THREE.BoxGeometry(0.04,0.04,0.12), black, 0,-0.035,-0.42);
        add(new THREE.BoxGeometry(0.04,0.05,0.22), wood, 0,-0.02,0.15);
        add(new THREE.CylinderGeometry(0.028,0.028,0.22,10), dark, 0,0.08,-0.48, Math.PI/2,0,0);
        add(new THREE.CylinderGeometry(0.032,0.032,0.04,10), chrome, 0,0.08,-0.38, Math.PI/2,0,0);
        add(new THREE.CylinderGeometry(0.032,0.032,0.04,10), chrome, 0,0.08,-0.58, Math.PI/2,0,0);
    } else if(slot===4){ // Glock
        add(new THREE.BoxGeometry(0.04,0.07,0.22), polymer, 0,0.01,-0.18);
        add(new THREE.BoxGeometry(0.038,0.055,0.12), steel, 0,0.02,-0.3);
        add(new THREE.BoxGeometry(0.042,0.12,0.07), grip, 0,-0.07,-0.1);
        add(new THREE.BoxGeometry(0.015,0.015,0.02), orange, 0,0.05,-0.35);
    } else if(slot===5){ // Deagle
        add(new THREE.BoxGeometry(0.05,0.08,0.28), black, 0,0.01,-0.22);
        add(new THREE.BoxGeometry(0.045,0.06,0.14), steel, 0,0.025,-0.36);
        add(new THREE.CylinderGeometry(0.012,0.014,0.1,8), steel, 0,0.03,-0.48, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.048,0.14,0.08), grip, 0,-0.08,-0.12);
        add(new THREE.BoxGeometry(0.02,0.02,0.025), orange, 0,0.06,-0.42);
    } else if(slot===6){ // MP9
        add(new THREE.BoxGeometry(0.045,0.07,0.32), polymer, 0,0,-0.28);
        add(new THREE.CylinderGeometry(0.012,0.013,0.18,8), steel, 0,0.015,-0.55, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.04,0.11,0.06), grip, 0,-0.08,-0.18);
        add(new THREE.BoxGeometry(0.035,0.1,0.05), black, 0,-0.07,-0.32);
        add(new THREE.BoxGeometry(0.03,0.04,0.1), polymer, 0,0.01,0.0);
        add(new THREE.BoxGeometry(0.015,0.02,0.04), orange, 0,0.05,-0.4);
    } else if(slot===7){ // Nova
        add(new THREE.BoxGeometry(0.055,0.07,0.42), black, 0,0,-0.32);
        add(new THREE.CylinderGeometry(0.022,0.024,0.45,10), steel, 0,0.02,-0.75, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.05,0.06,0.16), wood, 0,-0.01,-0.06);
        add(new THREE.BoxGeometry(0.045,0.12,0.07), wood, 0,-0.09,-0.2);
        add(new THREE.BoxGeometry(0.04,0.05,0.2), wood, 0,-0.02,0.14);
        add(new THREE.BoxGeometry(0.015,0.02,0.03), orange, 0,0.05,-0.5);
    } else if(slot===9){ // Knife
        add(new THREE.BoxGeometry(0.03,0.012,0.22), steel, 0.02,-0.02,-0.25);
        add(new THREE.BoxGeometry(0.025,0.04,0.08), grip, 0.02,-0.03,-0.12);
        add(new THREE.BoxGeometry(0.01,0.01,0.04), orange, 0.02,-0.01,-0.35);
    } else if(slot===8){ // FAMAS
        add(new THREE.BoxGeometry(0.05,0.1,0.45), polymer, 0,0.02,-0.35);
        add(new THREE.CylinderGeometry(0.014,0.015,0.32,8), steel, 0,0.02,-0.72, Math.PI/2,0,0);
        add(new THREE.BoxGeometry(0.045,0.12,0.06), grip, 0,-0.08,-0.25);
        add(new THREE.BoxGeometry(0.038,0.1,0.055), black, 0,-0.07,-0.4);
        add(new THREE.BoxGeometry(0.04,0.045,0.18), polymer, 0,0.08,-0.35);
        add(new THREE.BoxGeometry(0.035,0.04,0.14), polymer, 0,-0.01,0.05);
        add(new THREE.BoxGeometry(0.015,0.02,0.04), orange, 0,0.12,-0.5);
    }
    g.position.set(0.28, -0.24, -0.42);
    g.rotation.set(0.02, 0.08, 0.04);
    g.visible = true;
}
buildGun(4);

// ---------- КОМАНДЫ И БОТЫ ----------
const ALLY_COUNT = 4, ENEMY_COUNT = 5, KILL_LIMIT = 30;
const ALLY_NAMES  = ['Alex','Bravo','Cobra','Delta','Echo','Fox'];
const ENEMY_NAMES = ['Viper','Wolf','Ghost','Hawk','Rex','Nova','Jet','Lynx'];
const TEAMS = {
    ally:  { body:0x2f6df0, head:0xd9a066, tag:'#38bdf8' },
    enemy: { body:0xb3401e, head:0xd9a066, tag:'#f87171' }
};
const SPAWNS = {
    ally:  [[-6,26],[-2,27],[2,27],[6,26],[10,25],[-10,25]],
    enemy: [[-6,-26],[-2,-27],[2,-27],[6,-26],[10,-25],[-10,-25],[14,-24],[-14,-24]]
};
player.name = 'Вы';
const bots = [];
let botIdSeq = 0, scoreCT = 0, scoreTR = 0, matchOver = false;

function pointInCollider(x,z,r){
    for(const c of colliders){
        if(x>c.minX-r && x<c.maxX+r && z>c.minZ-r && z<c.maxZ+r) return true;
    }
    return false;
}

function makeTag(name, color){
    const cv = document.createElement('canvas'); cv.width = 128; cv.height = 48;
    const g = cv.getContext('2d');
    g.font = 'bold 22px sans-serif'; g.textAlign = 'center';
    g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.85)'; g.strokeText(name, 64, 22);
    g.fillStyle = color; g.fillText(name, 64, 22);
    g.beginPath(); g.moveTo(54,30); g.lineTo(74,30); g.lineTo(64,44); g.closePath(); g.fill();
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map:new THREE.CanvasTexture(cv), depthTest:false, transparent:true }));
    spr.scale.set(1.3, 0.49, 1); spr.position.y = 2.35; spr.renderOrder = 10;
    return spr;
}

function spawnBot(team, name){
    const id = ++botIdSeq, T = TEAMS[team];
    const grp = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.34,0.42,1.05,10), new THREE.MeshStandardMaterial({ color:T.body, roughness:0.7 }));
    body.position.y = 0.85; body.castShadow = true;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23,12,10), new THREE.MeshStandardMaterial({ color:T.head, roughness:0.6 }));
    head.position.y = 1.62; head.castShadow = true;
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.3,0.08,0.1), new THREE.MeshStandardMaterial({ color:0x14181f }));
    visor.position.set(0,1.64,0.16);
    const gun = new THREE.Mesh(new THREE.BoxGeometry(0.07,0.08,0.55), new THREE.MeshStandardMaterial({ color:0x1c2129 }));
    gun.position.set(0.3,1.05,0.3);
    grp.add(body, head, visor, gun);
    if(team==='ally') grp.add(makeTag(name, T.tag));
    scene.add(grp);
    const bot = { id, name, team, grp, body, head, hp:100, dead:false, respawnT:0,
        target:new THREE.Vector3(), fireCd:1+Math.random(), strafe:Math.random()<0.5?1:-1, strafeT:0,
        checkT:Math.random()*0.4, enemy:null, enemyDist:99, stuckT:0, lastX:0, lastZ:0, slot:botIdSeq%6 };
    body.userData.bot = bot; body.userData.part = 'body';
    head.userData.bot = bot; head.userData.part = 'head';
    bots.push(bot);
    respawnBot(bot);
    return bot;
}

function respawnBot(bot){
    const list = SPAWNS[bot.team];
    let sp, tries = 0;
    do { sp = list[Math.floor(Math.random()*list.length)]; tries++; }
    while(tries<10 && bots.some(o=>o!==bot && !o.dead && Math.hypot(o.grp.position.x-sp[0], o.grp.position.z-sp[1])<1.4));
    bot.grp.position.set(sp[0]+(Math.random()-0.5), 0, sp[1]);
    bot.grp.rotation.y = bot.team==='ally' ? Math.PI : 0;
    bot.hp = 100; bot.dead = false; bot.enemy = null; bot.fireCd = 1+Math.random();
    bot.target.copy(bot.grp.position); bot.stuckT = 0;
    bot.grp.visible = true;
}

function enemyMeshes(){
    const out = [];
    for(const b of bots) if(b.team==='enemy' && !b.dead) out.push(b.body, b.head);
    return out;
}

function countAlive(team){ let n=0; for(const b of bots) if(b.team===team && !b.dead) n++; if(team==='ally' && player && player.alive) n++; return n; }

function createTeams(){
    const an = ALLY_NAMES.slice().sort(()=>Math.random()-0.5), en = ENEMY_NAMES.slice().sort(()=>Math.random()-0.5);
    for(let i=0;i<ALLY_COUNT;i++)  spawnBot('ally',  an[i]);
    for(let i=0;i<ENEMY_COUNT;i++) spawnBot('enemy', en[i]);
}

// ---------- ТРАССЕРЫ ----------
const tracers = [];
function spawnTracer(from, to, color){
    const geo = new THREE.BufferGeometry().setFromPoints([from, to]);
    const mat = new THREE.LineBasicMaterial({ color: color||0xffd27a, transparent:true, opacity:0.9 });
    const line = new THREE.Line(geo, mat);
    scene.add(line);
    tracers.push({ line, life:0.07 });
}

// ---------- СТРЕЛЬБА ----------
const raycaster = new THREE.Raycaster();
raycaster.far = 300;

function flashHitmarker(){
    hitmarkerEl.style.opacity='1';
    clearTimeout(flashHitmarker._t);
    flashHitmarker._t=setTimeout(()=>hitmarkerEl.style.opacity='0', 70);
}

function updateAmmoHUD(){
    const st = wstate[curWeapon];
    ammoCur.textContent = st.ammo;
    ammoMax.textContent = st.reserve;
    ammoCur.style.color = st.ammo===0 ? '#ff3b3b' : (st.ammo<=5 ? '#ff8c00' : '#fff');
}

function startReload(){
    if(roundState==='buy') return;
    const W = WEAPONS[curWeapon], st = wstate[curWeapon];
    if(reloading || st.ammo===W.mag || st.reserve<=0) return;
    reloading = true;
    $('btn-reload').classList.add('active');
    setTimeout(()=>{},0);
    reloadTimer = setTimeout(()=>{
        const need = W.mag - st.ammo;
        const take = Math.min(need, st.reserve);
        st.ammo += take; st.reserve -= take;
        reloading = false;
        $('btn-reload').classList.remove('active');
        updateAmmoHUD();
    }, W.reloadTime);
}

function showBanner(html, ms){
    let el = $('team-banner');
    if(!el){
        el = document.createElement('div'); el.id = 'team-banner';
        el.style.cssText = 'position:absolute;left:50%;top:30%;transform:translate(-50%,-50%);z-index:60;pointer-events:none;text-align:center;font:900 34px sans-serif;letter-spacing:.12em;color:#fff;text-shadow:0 2px 12px #000;display:none';
        container.appendChild(el);
    }
    el.innerHTML = html; el.style.display = 'block';
    clearTimeout(showBanner._t); showBanner._t = setTimeout(()=>{ el.style.display='none'; }, ms||2500);
}

function addScore(team){
    if(team==='ally'){ scoreCT++; scoreCtEl.textContent = scoreCT; }
    else { scoreTR++; scoreTrEl.textContent = scoreTR; }
    if(!matchOver && (scoreCT>=KILL_LIMIT || scoreTR>=KILL_LIMIT)){
        matchOver = true;
        const win = scoreCT>=KILL_LIMIT;
        showBanner(win?'<span style="color:#4ade80">ПОБЕДА КОМАНДЫ</span>':'<span style="color:#f87171">ПОРАЖЕНИЕ</span>', 4500);
        setTimeout(resetMatch, 5000);
    }
}

function resetMatch(){
    scoreCT = scoreTR = 0; scoreCtEl.textContent = 0; scoreTrEl.textContent = 0;
    bots.forEach(respawnBot);
    respawnPlayer();
    matchOver = false;
}

function killBot(bot, attacker, headshot){
    if(bot.dead) return;
    bot.dead = true; bot.grp.visible = false; bot.enemy = null;
    bot.respawnT = (gameMode===MODE.TDM) ? (4 + Math.random()*2) : 9999;
    const aTeam = attacker===player ? 'ally' : (attacker.team||'enemy');
    // In round modes score is by rounds; still track feed
    addKillFeed(attacker.name||'You', bot.name, attacker===player, headshot, aTeam, bot.team);
    if(attacker===player){ sfxDie(); playerMoney=Math.min(16000,playerMoney+(headshot?400:300)); updateMoneyHUD(); }
    checkRoundElim();
}

function damageBot(bot, dmg, part, attacker){
    if(bot.dead) return;
    bot.hp -= dmg;
    if(attacker===player){ flashHitmarker(); sfxHit(); }
    if(bot.hp<=0) killBot(bot, attacker, part==='head');
}


const nadeMeshes = [];
function throwNade(){
    if(!player.alive || roundState!=='live' || nades<=0) return;
    if(performance.now()-lastNade < 1000) return;
    lastNade = performance.now();
    nades--; updateMoneyHUD();
    const origin = camera.getWorldPosition(new THREE.Vector3());
    const dir = new THREE.Vector3(0,0.25,-1).applyQuaternion(camera.quaternion).normalize();
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(0.12,8,8), new THREE.MeshStandardMaterial({color:0x3d5c3a, roughness:0.6}));
    mesh.position.copy(origin);
    scene.add(mesh);
    const vel = dir.multiplyScalar(18); vel.y += 4;
    nadeMeshes.push({ mesh, vel, life:2.2, exploded:false });
    showBanner('<span style="color:#fbbf24">HE!</span>', 600);
}
function updateNades(dt){
    for(let i=nadeMeshes.length-1;i>=0;i--){
        const n=nadeMeshes[i];
        n.vel.y -= 18*dt;
        n.mesh.position.x += n.vel.x*dt;
        n.mesh.position.y += n.vel.y*dt;
        n.mesh.position.z += n.vel.z*dt;
        if(n.mesh.position.y<0.12){ n.mesh.position.y=0.12; n.vel.y*=-0.3; n.vel.x*=0.7; n.vel.z*=0.7; }
        n.life -= dt;
        if(n.life<=0 && !n.exploded){
            n.exploded=true;
            const p=n.mesh.position;
            // damage
            if(player.alive && Math.hypot(player.pos.x-p.x, player.pos.z-p.z)<7){
                const d=Math.hypot(player.pos.x-p.x, player.pos.z-p.z);
                applyDamage(Math.max(10, 90*(1-d/7)));
            }
            bots.forEach(b=>{
                if(b.dead) return;
                const d=Math.hypot(b.grp.position.x-p.x, b.grp.position.z-p.z);
                if(d<7){ b.hp -= Math.max(15, 110*(1-d/7)); if(b.hp<=0) killBot(b, player, false); }
            });
            // flash sphere
            const boom=new THREE.Mesh(new THREE.SphereGeometry(0.4,8,8), new THREE.MeshBasicMaterial({color:0xffaa44, transparent:true, opacity:0.8}));
            boom.position.copy(p); scene.add(boom);
            setTimeout(()=>{ scene.remove(boom); boom.geometry.dispose(); }, 200);
            scene.remove(n.mesh); n.mesh.geometry.dispose();
            nadeMeshes.splice(i,1);
            sfxDie();
        }
    }
}

function tryFire(now){
    if(roundState && roundState!=='live') return;
    const W0 = WEAPONS[curWeapon];
    if(W0 && W0.melee){
        if(now-lastShot < 500) return;
        lastShot = now;
        gunKick.z = -0.2; gunKick.x = -0.25;
        const origin = camera.getWorldPosition(new THREE.Vector3());
        const dir = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
        raycaster.set(origin, dir);
        const botMeshes = bots.filter(b=>!b.dead).map(b=>b.grp);
        const hits = raycaster.intersectObjects(botMeshes, true);
        if(hits.length && hits[0].distance < 2.2){
            let hitBot=null;
            for(const b of bots){ if(!b.dead && (hits[0].object===b.grp || b.grp.children.includes(hits[0].object))){ hitBot=b; break; } }
            if(hitBot && hitBot.team==='enemy'){
                hitBot.hp -= W0.dmg;
                flashHitmarker(); sfxHit();
                if(hitBot.hp<=0) killBot(hitBot, player, false);
            }
        }
        return;
    }
    if(!player.alive || reloading) return;
    const W = WEAPONS[curWeapon], st = wstate[curWeapon];
    if(now - lastShot < 60000/W.rpm) return;
    if(st.ammo<=0){ startReload(); return; }
    lastShot = now;
    st.ammo--;
    updateAmmoHUD();
    sfxShot(W.snd);

    // спред
    const moveFactor = Math.min(1, player.vel.length()/5);
    const spread = (W.spread + bloom*0.02 + moveFactor*0.02) * (aiming?0.45:1);
    const dir = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
    dir.x += (Math.random()*2-1)*spread;
    dir.y += (Math.random()*2-1)*spread;
    dir.z += (Math.random()*2-1)*spread;
    dir.normalize();
    raycaster.set(camera.position.clone(), dir);

    const botHits = raycaster.intersectObjects(enemyMeshes(), false);
    const wallHits = raycaster.intersectObjects(wallMeshes, false);
    const wallDist = wallHits.length ? wallHits[0].distance : Infinity;

    let endPoint = camera.position.clone().add(dir.clone().multiplyScalar(80));
    if(botHits.length && botHits[0].distance < wallDist){
        const h = botHits[0];
        endPoint = h.point;
        const part = h.object.userData.part;
        damageBot(h.object.userData.bot, W.dmg * (part==='head'?2:1), part, player);
    } else if(wallHits.length){
        endPoint = wallHits[0].point;
    }
    const from = camera.position.clone().add(new THREE.Vector3(0.22,-0.2,-0.6).applyQuaternion(camera.quaternion));
    spawnTracer(from, endPoint);

    muzzleLight.intensity = 2.2;
    player.pitch += W.recoil * (aiming?0.6:1);
    player.yaw += (Math.random()*2-1)*W.recoil*0.4;
    bloom = Math.min(1, bloom + (curWeapon===3?0.6:0.25));
    gunKick.z=-0.14-W.recoil*2; gunKick.x=-0.08-W.recoil; gunKick.y=(Math.random()-0.5)*0.04;
}

// ---------- УРОН ПО ИГРОКУ ----------
function applyDamage(d, attacker){
    if(!player.alive) return;
    const absorbed = Math.min(player.armor, d*0.55);
    player.armor = Math.max(0, player.armor - absorbed);
    player.hp = Math.max(0, player.hp - (d - absorbed));
    hpVal.textContent = Math.ceil(player.hp);
    armorVal.textContent = Math.ceil(player.armor);
    vignette.style.boxShadow = 'inset 0 0 120px rgba(255,0,0,0.65)';
    clearTimeout(applyDamage._t);
    applyDamage._t = setTimeout(()=>vignette.style.boxShadow='inset 0 0 100px rgba(255,0,0,0)', 130);
    if(player.hp<=0) playerDie(attacker);
}

function respawnPlayer(){
    const sideKey = playerSide==='ct' ? 'ally' : 'enemy';
    const list = SPAWNS[sideKey];
    const sp = list[Math.floor(Math.random()*list.length)] || [0,24];
    player.pos.set(sp[0], 0, sp[1]);
    player.vel.set(0,0,0);
    player.hp = 100; player.armor = 50;
    player.alive = true; player.onGround = true;
    player.yaw = playerSide==='ct' ? Math.PI : 0; player.pitch = 0;
    hpVal.textContent = 100; armorVal.textContent = 50;
    if(gameMode===MODE.PLANT && playerSide==='t') hasBomb = true;
    else hasBomb = false;
    for(const k in owned){
        if(owned[k] && WEAPONS[k] && !WEAPONS[k].melee){
            wstate[k].ammo = WEAPONS[k].mag;
            if(wstate[k].reserve < WEAPONS[k].reserve)
                wstate[k].reserve = Math.max(wstate[k].reserve, Math.floor(WEAPONS[k].reserve*0.5));
        }
    }
    reloading = false; clearTimeout(reloadTimer);
    const br = $('btn-reload'); if(br) br.classList.remove('active');
    updateAmmoHUD(); updateMoneyHUD(); updateSideHUD(); updatePrompt('');
}

function playerDie(attacker){
    player.alive = false;
    const killer = attacker || { name:'?', team:'enemy' };
    addScore('enemy');
    addKillFeed(killer.name, 'Вы', false, false, 'enemy', 'ally');
    $('death-overlay').style.display = 'flex';
    clearTimeout(playerDie._t);
    playerDie._t = setTimeout(()=>{ if(!player.alive) respawnPlayer(); }, 3000);
}

// ---------- KILL FEED ----------
function addKillFeed(a, b, playerIsKiller, headshot, aTeam, bTeam){
    const col = t => t==='ally' ? 'text-cyan-300' : 'text-amber-400';
    const div = document.createElement('div');
    div.className='kill-item so2-panel px-2 py-0.5 rounded text-[10px] font-sans';
    if(playerIsKiller) div.style.borderColor = '#38e8ff';
    div.innerHTML = '<span class="'+col(aTeam||'ally')+'">'+a+'</span>' +
        ' <i class="fa-solid '+(headshot?'fa-crosshairs':'fa-skull')+' text-slate-400 mx-1"></i> ' +
        '<span class="'+col(bTeam||'enemy')+'">'+b+'</span>';
    killFeedEl.prepend(div);
    while(killFeedEl.children.length>5) killFeedEl.lastChild.remove();
    setTimeout(()=>{ if(div.parentNode) div.remove(); }, 4500);
}

// ---------- ПЕРЕКЛЮЧЕНИЕ ОРУЖИЯ ----------
window.switchWeapon = function(slot){
    slot = Number(slot);
    if(!WEAPONS[slot] || !owned[slot]) return;
    if(slot===curWeapon) return;
    curWeapon = slot;
    save.weapon = slot; writeSave();
    reloading = false; clearTimeout(reloadTimer);
    const br=$('btn-reload'); if(br) br.classList.remove('active');
    buildGun(slot);
    updateAmmoHUD();
    refreshWeaponSwitcher();
    gunKick.z = 0.12; gunKick.x = -0.15;
};
function refreshWeaponSwitcher(){
    const box = $('weapon-switcher'); if(!box) return;
    box.innerHTML = '';
    Object.keys(owned).map(Number).filter(k=>owned[k]).sort((a,b)=>a-b).forEach(id=>{
        const b=document.createElement('button');
        b.id='wslot-'+id;
        b.className='px-2.5 py-1 rounded text-[10px] font-bold '+(id===curWeapon?'bg-white/20 border border-orange-500':'bg-black/40 border border-white/10 opacity-60');
        b.textContent=WEAPONS[id].name;
        b.onclick=()=>switchWeapon(id);
        box.appendChild(b);
    });
}
function updateMoneyHUD(){ const el=$('money-val'); if(el) el.textContent='$'+playerMoney; const bm=$('buy-money'); if(bm) bm.textContent='$'+playerMoney; if(player) player.money=playerMoney; const nd=$('nade-count'); if(nd) nd.textContent='HE×'+nades; }
function updateSideHUD(){
  const el=$('side-label'); if(!el) return;
  if(gameMode!==MODE.PLANT){ el.textContent='TDM'; el.style.color='#94a3b8'; return; }
  if(playerSide==='ct'){ el.textContent='CT · СПЕЦНАЗ'; el.style.color='#38bdf8'; }
  else { el.textContent='T · ТЕРРОР'; el.style.color='#f97316'; }
}
function updatePrompt(text){
  const el=$('action-prompt'); if(!el) return;
  if(!text){ el.classList.add('hidden'); el.textContent=''; return; }
  el.textContent=text; el.classList.remove('hidden');
}
function playerIsCT(){ return playerSide==='ct'; }
function playerIsT(){ return playerSide==='t'; }

function updateRoundHUD(){
    const rt=$('round-timer'), rs=$('round-state'), rn=$('round-num');
    if(rn) rn.textContent='R'+roundNumber;
    if(rt){ const sec=Math.max(0,Math.ceil(roundTimer)); const m=Math.floor(sec/60), s=sec%60;
      rt.textContent=m+':'+(s<10?'0':'')+s; rt.style.color=roundState==='buy'?'#4ade80':(sec<=10?'#f87171':'#fff'); }
    if(rs) rs.textContent=roundState==='buy'?'ПОКУКА':(roundState==='live'?(gameMode===MODE.PLANT?'LIVE':'БОЙ'):'РАУНД');
    scoreCtEl.textContent=scoreCT; scoreTrEl.textContent=scoreTR;
}
function openBuyMenu(){
    const m=$('buy-menu'); if(!m) return;
    if(roundState!=='buy'||!player.alive){ m.classList.add('hidden'); return; }
    m.classList.remove('hidden'); renderBuyList();
}
function closeBuyMenu(){ const m=$('buy-menu'); if(m) m.classList.add('hidden'); }
function renderBuyList(){
    const list=$('buy-list'); if(!list) return;
    list.innerHTML='';
    // grenade row
    const gb=document.createElement('button');
    gb.className='w-full flex justify-between items-center px-3 py-2 rounded-lg border text-left text-sm font-sans mb-1 '+(playerMoney>=GRENADE_PRICE?'bg-slate-800/80 border-amber-600':'bg-slate-900/50 border-slate-800 opacity-50');
    gb.innerHTML='<span><b>HE GRANATE</b> <span class="text-slate-400 text-xs">throw</span></span><span class="font-bold text-amber-400">$'+GRENADE_PRICE+' (есть '+nades+')</span>';
    gb.onclick=()=>{ if(roundState!=='buy'||playerMoney<GRENADE_PRICE||nades>=2) return; playerMoney-=GRENADE_PRICE; nades++; updateMoneyHUD(); renderBuyList(); showBanner('<span style="color:#fbbf24">HE +1</span>',900); };
    list.appendChild(gb);
    [4,5,6,8,1,2,7,3].forEach(id=>{
        const W=WEAPONS[id]; if(!W) return;
        const has=!!owned[id];
        const btn=document.createElement('button');
        btn.className='w-full flex justify-between items-center px-3 py-2 rounded-lg border text-left text-sm font-sans mb-1 '+(has?'bg-emerald-900/40 border-emerald-500/50':(playerMoney>=W.price?'bg-slate-800/80 border-slate-600':'bg-slate-900/50 border-slate-800 opacity-50'));
        btn.innerHTML='<span><b>'+W.name+'</b> <span class="text-slate-400 text-xs">'+W.cat+'</span></span><span class="font-bold '+(has?'text-emerald-400':'text-orange-400')+'">'+(has?'ЕСТЬ':'$'+W.price)+'</span>';
        btn.onclick=()=>buyWeapon(id);
        list.appendChild(btn);
    });
}
function buyWeapon(id){
    if(roundState!=='buy'||!player.alive) return;
    const W=WEAPONS[id]; if(!W) return;
    if(owned[id]){
        const refill=Math.floor(W.price*0.35);
        if(playerMoney>=refill){ playerMoney-=refill; wstate[id].ammo=W.mag; wstate[id].reserve=W.reserve; updateMoneyHUD(); switchWeapon(id); showBanner('<span style="color:#4ade80">ПАТРОНЫ: '+W.name+'</span>',1000); }
        renderBuyList(); return;
    }
    if(playerMoney<W.price) return;
    playerMoney-=W.price; owned[id]=true; wstate[id].ammo=W.mag; wstate[id].reserve=W.reserve;
    updateMoneyHUD(); switchWeapon(id); showBanner('<span style="color:#4ade80">КУПЛЕНО: '+W.name+'</span>',1200);
    renderBuyList(); refreshWeaponSwitcher();
}

// ---------- ВВОД: клавиатура/мышь ----------
const keys = {};
addEventListener('keydown', e=>{
    keys[e.code]=true;
    if(e.code==='KeyR') startReload();
    if(e.code==='KeyG') throwNade();
    if(e.code==='KeyB'){ if(roundState==='buy') openBuyMenu(); }
    if(e.code==='KeyE'||e.code==='KeyF') window._useHeld=true;
    if(e.code==='KeyC') toggleCrouch();
    if(e.code.startsWith('Digit')){ const n=Number(e.code.slice(5)); if(n>=1&&n<=8) switchWeapon(n); }
    if(e.code==='Digit2') switchWeapon(2);
    if(e.code==='Digit3') switchWeapon(3);
    if(e.code==='Digit4') switchWeapon(4);
});
addEventListener('keyup', e=>keys[e.code]=false);

const canvas = renderer.domElement;
canvas.addEventListener('click', ()=>{
    audio();
    if(!('ontouchstart' in window) && document.pointerLockElement!==canvas){
        canvas.requestPointerLock && canvas.requestPointerLock();
    }
});
addEventListener('mousemove', e=>{
    if(document.pointerLockElement===canvas){
        const sens = 0.0022 * sensitivity * (aiming?(WEAPONS[curWeapon].scoped?0.35:0.6):1);
        player.yaw -= e.movementX*sens;
        player.pitch -= e.movementY*sens;
        player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch));
    }
});
addEventListener('mousedown', e=>{
    audio();
    if(document.pointerLockElement!==canvas) return;
    if(e.button===0){ fireHeld=true; tryFire(performance.now()); }
    if(e.button===2){ aiming=true; }
});
addEventListener('mouseup', e=>{
    if(e.button===0) fireHeld=false;
    if(e.button===2) aiming=false;
});
addEventListener('contextmenu', e=>e.preventDefault());

function toggleCrouch(){
    player.crouch=!player.crouch;
    $('btn-crouch').classList.toggle('active', player.crouch);
}

// ---------- ВВОД: тач ----------
const joy = { x:0, y:0, id:null };
const joyEl=$('joystick-container'), stickEl=$('joystick-stick');
if(joyEl && stickEl){
const JOY_R = 46;

joyEl.addEventListener('pointerdown', e=>{
    if(hudEdit) return;
    joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId);
});
joyEl.addEventListener('pointermove', e=>{
    if(e.pointerId!==joy.id) return;
    const r = joyEl.getBoundingClientRect();
    let dx = e.clientX-(r.left+r.width/2), dy = e.clientY-(r.top+r.height/2);
    const len = Math.hypot(dx,dy);
    if(len>JOY_R){ dx=dx/len*JOY_R; dy=dy/len*JOY_R; }
    stickEl.style.transform = 'translate(calc(-50% + '+dx+'px), calc(-50% + '+dy+'px))';
    joy.x = dx/JOY_R; joy.y = dy/JOY_R;
});
function joyEnd(e){
    if(e.pointerId!==joy.id) return;
    joy.id=null; joy.x=0; joy.y=0;
    stickEl.style.transform='translate(-50%,-50%)';
}
joyEl.addEventListener('pointerup', joyEnd);
joyEl.addEventListener('pointercancel', joyEnd);
} // end joyEl

// зона обзора
const camArea=$('touch-camera-area');
let lookId=null, lookX=0, lookY=0;
function applyLook(dx,dy){
    const sens = 0.0042 * sensitivity * (aiming?(WEAPONS[curWeapon]&&WEAPONS[curWeapon].scoped?0.35:0.6):1);
    player.yaw -= dx*sens;
    player.pitch -= dy*sens;
    player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch));
}
if(camArea){
camArea.addEventListener('pointerdown', e=>{
    audio();
    if(lookId!==null) return;
    lookId=e.pointerId; lookX=e.clientX; lookY=e.clientY;
    try{ camArea.setPointerCapture(e.pointerId); }catch(_){}
});
camArea.addEventListener('pointermove', e=>{
    if(e.pointerId!==lookId) return;
    applyLook(e.clientX-lookX, e.clientY-lookY);
    lookX=e.clientX; lookY=e.clientY;
});
function lookEnd(e){ if(e.pointerId===lookId) lookId=null; }
camArea.addEventListener('pointerup', lookEnd);
camArea.addEventListener('pointercancel', lookEnd);
}

// кнопки (удержание привязано к конкретному пальцу)
function bindHold(el, down, up){
    let pid=null;
    el.addEventListener('pointerdown', e=>{
        if(hudEdit) return;
        e.preventDefault(); audio();
        pid=e.pointerId; el.setPointerCapture(e.pointerId); down();
    });
    const end=e=>{ if(e.pointerId!==pid) return; pid=null; up&&up(); };
    ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>el.addEventListener(ev, end));
}
if($('btn-jump')) bindHold($('btn-jump'), ()=>{ keys['Space']=true; }, ()=>{ keys['Space']=false; });

// МОБИЛЬНЫЙ ОГОНЬ + ОБЗОР: палец можно уводить за пределы кнопки,
// сама кнопка остаётся на месте. Захват указателя сохраняет стрельбу.
const fireBtn=$('btn-fire');
let fireLookId=null, fireLX=0, fireLY=0;
if(fireBtn){
fireBtn.style.touchAction='none';
fireBtn.addEventListener('pointerdown', e=>{
    if(hudEdit) return;
    e.preventDefault(); e.stopPropagation(); audio();
    if(fireLookId!==null) return;
    fireLookId=e.pointerId; fireLX=e.clientX; fireLY=e.clientY;
    fireHeld=true; tryFire(performance.now());
    try { fireBtn.setPointerCapture(e.pointerId); } catch(_) {}
});
addEventListener('pointermove', e=>{
    if(e.pointerId!==fireLookId) return;
    e.preventDefault();
    applyLook(e.clientX-fireLX, e.clientY-fireLY);
    fireLX=e.clientX; fireLY=e.clientY;
},{passive:false});
function fireTouchEnd(e){
    if(e.pointerId!==fireLookId) return;
    fireLookId=null; fireHeld=false;
}
['pointerup','pointercancel'].forEach(ev=>addEventListener(ev, fireTouchEnd));
}

const _aim=$('btn-aim'); if(_aim) _aim.addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; aiming=!aiming; _aim.classList.toggle('active', aiming); });
const _cr=$('btn-crouch'); if(_cr) _cr.addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; toggleCrouch(); });
const _rl=$('btn-reload'); if(_rl) _rl.addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; startReload(); });

// ---------- ПАМЯТЬ ИГРЫ (localStorage) ----------
const SAVE_KEY = 'standoff3d_save_v1';
const save = {
    gfx: { rs:1.0, sh:'high', fps:'60', sens:1.0, preset:'high', auto:true },
    hud: {},        // позиции кнопок в долях экрана {x,y}
    hudScale: 1,    // размер кнопок
    weapon: 4
};
function loadSave(){
    try{
        const raw = localStorage.getItem(SAVE_KEY);
        if(!raw) return;
        const d = JSON.parse(raw);
        if(!d || typeof d!=='object') return;
        Object.assign(save.gfx, d.gfx||{});
        save.hud = (d.hud && typeof d.hud==='object') ? d.hud : {};
        const hs = parseFloat(d.hudScale);
        save.hudScale = (hs>=0.7 && hs<=1.5) ? hs : 1;
        const w = parseInt(d.weapon,10);
        save.weapon = (w>=1 && w<=4) ? w : 1;
    }catch(e){}
}
function writeSave(){
    try{ localStorage.setItem(SAVE_KEY, JSON.stringify(save)); }catch(e){}
}

// ---------- HUD EDIT MODE ----------
let hudEdit=false;
const hudEls = { joy:$('joystick-container'), fire:$('btn-fire'), aim:$('btn-aim'), jump:$('btn-jump'), crouch:$('btn-crouch'), reload:$('btn-reload') };
const hudBase = {}, hudInit = {};
for(const k in hudEls){
    hudInit[k] = hudEls[k].style.cssText;
    hudBase[k] = k==='joy' ? 130 : (parseFloat(hudEls[k].style.width)||52);
}
function setHudEdit(on){
    hudEdit = on;
    wrapper.classList.toggle('hud-edit-mode', hudEdit);
    $('btn-hud-edit').classList.toggle('bg-orange-500', hudEdit);
    // отпускаем всё, что могло остаться зажатым
    fireHeld=false; keys['Space']=false; joy.id=null; joy.x=0; joy.y=0;
    stickEl.style.transform='translate(-50%,-50%)';
    if(hudEdit) showBanner('Перетаскивайте кнопки пальцем<br><span style="font-size:18px">Нажмите HUD ещё раз — сохранить</span>', 2600);
    else { writeSave(); showBanner('✔ Раскладка сохранена', 1200); }
}
$('btn-hud-edit').addEventListener('click', ()=>setHudEdit(!hudEdit));
$('btn-hud-move').addEventListener('click', ()=>{ $('graphics-modal').classList.add('hidden'); setHudEdit(true); });

function clampHud(el){
    const w=el.offsetWidth, h=el.offsetHeight;
    let l=parseFloat(el.style.left), t=parseFloat(el.style.top);
    if(isNaN(l)||isNaN(t)) return;
    el.style.left = Math.max(0, Math.min(innerWidth-w, l))+'px';
    el.style.top  = Math.max(0, Math.min(innerHeight-h, t))+'px';
}
function applyHudScale(){
    const sc = save.hudScale;
    for(const k in hudEls){
        if(k==='joy') continue;
        const px = Math.round(hudBase[k]*sc);
        hudEls[k].style.width = px+'px'; hudEls[k].style.height = px+'px';
    }
    $('hud-scale-val').textContent = sc.toFixed(2)+'x';
    $('setting-hud-scale').value = sc;
    for(const k in hudEls) clampHud(hudEls[k]);
}
function applyHudLayout(){
    for(const k in hudEls){
        const p = save.hud[k];
        if(!p || typeof p.x!=='number' || typeof p.y!=='number') continue;
        const el = hudEls[k];
        el.style.left = (p.x*innerWidth)+'px';
        el.style.top  = (p.y*innerHeight)+'px';
        el.style.right='auto'; el.style.bottom='auto';
        clampHud(el);
    }
}
let dragEl=null, dragOX=0, dragOY=0;
for(const k in hudEls){
    const el = hudEls[k];
    el.addEventListener('pointerdown', e=>{
        if(!hudEdit) return;
        e.preventDefault(); e.stopPropagation();
        dragEl=el; el.setPointerCapture(e.pointerId);
        const r=el.getBoundingClientRect();
        dragOX=e.clientX-r.left; dragOY=e.clientY-r.top;
        el.style.left=r.left+'px'; el.style.top=r.top+'px';
        el.style.right='auto'; el.style.bottom='auto';
    });
    el.addEventListener('pointermove', e=>{
        if(!hudEdit || dragEl!==el) return;
        el.style.left=(e.clientX-dragOX)+'px';
        el.style.top=(e.clientY-dragOY)+'px';
        clampHud(el);
    });
    const dragEnd = ()=>{
        if(dragEl!==el) return;
        dragEl=null;
        const r=el.getBoundingClientRect();
        save.hud[k] = { x:r.left/innerWidth, y:r.top/innerHeight };
        writeSave();
    };
    el.addEventListener('pointerup', dragEnd);
    el.addEventListener('pointercancel', dragEnd);
}
$('setting-hud-scale').addEventListener('input', e=>{
    save.hudScale = parseFloat(e.target.value);
    applyHudScale(); writeSave();
});
$('btn-hud-reset').addEventListener('click', ()=>{
    for(const k in hudEls) hudEls[k].style.cssText = hudInit[k];
    save.hud = {}; save.hudScale = 1;
    applyHudScale(); writeSave();
    showBanner('Раскладка сброшена', 1200);
});

// ---------- НАСТРОЙКИ ГРАФИКИ ----------
let fpsCap = 60, preset = 'high';
const rsInput=$('setting-render-scale'), shadowSel=$('setting-shadows'), fpsSel=$('setting-fps-cap'), sensInput=$('setting-sens'), autoChk=$('setting-auto');

function markPreset(p){
    document.querySelectorAll('.preset-btn').forEach(b=>{
        const on = b.dataset.preset===p;
        b.classList.toggle('border-orange-500', on);
        b.classList.toggle('text-orange-400', on);
        b.classList.toggle('border-slate-700', !on);
    });
}
function syncGfxUI(){
    const g = save.gfx;
    const rs = parseFloat(g.rs);
    rsInput.value = (rs>=0.5 && rs<=1.25) ? rs : 1.0;
    shadowSel.value = ['off','low','high','ultra'].includes(g.sh) ? g.sh : 'high';
    fpsSel.value = ['30','60','90','120','0'].includes(String(g.fps)) ? String(g.fps) : '60';
    const se = parseFloat(g.sens);
    sensInput.value = (se>=0.3 && se<=2.5) ? se : 1.0;
    autoChk.checked = g.auto!==false;
    preset = ['low','medium','high','ultra'].includes(g.preset) ? g.preset : null;
    markPreset(preset);
}

function applyGraphics(){
    const scale = parseFloat(rsInput.value);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2)*scale);
    renderer.setSize(innerWidth, innerHeight);
    $('render-scale-val').textContent = scale.toFixed(2)+'x';
    const sh = shadowSel.value;
    const shadowsOn = sh!=='off';
    renderer.shadowMap.enabled = shadowsOn;
    sun.castShadow = shadowsOn;
    if(shadowsOn){
        const size = sh==='low'?1024 : sh==='high'?2048 : 4096;
        if(sun.shadow.mapSize.x!==size){
            sun.shadow.mapSize.set(size,size);
            if(sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map=null; }
        }
    }
    scene.traverse(o=>{
        if(o.material){ (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.needsUpdate=true); }
    });
    fpsCap = parseInt(fpsSel.value,10);
    sensitivity = parseFloat(sensInput.value);
    $('sens-val').textContent = sensitivity.toFixed(1);
    save.gfx = { rs:scale, sh:sh, fps:fpsSel.value, sens:sensitivity, preset:preset, auto:autoChk.checked };
    writeSave();
}
function onManualGfx(){ preset=null; markPreset(null); applyGraphics(); }
[rsInput, shadowSel, fpsSel].forEach(el=>el.addEventListener('change', onManualGfx));
sensInput.addEventListener('input', applyGraphics);
autoChk.addEventListener('change', applyGraphics);

window.setGraphicPreset = function(p){
    const map = {
        low:    { rs:0.5,  sh:'off',  fps:'30'  },
        medium: { rs:0.75, sh:'low',  fps:'60'  },
        high:   { rs:1.0,  sh:'high', fps:'60'  },
        ultra:  { rs:1.25, sh:'ultra',fps:'120' }
    }[p];
    rsInput.value=map.rs; shadowSel.value=map.sh; fpsSel.value=map.fps;
    preset=p; markPreset(p);
    applyGraphics();
};

// Авто-качество: если FPS стабильно ниже цели (60), снижаем нагрузку по шагам
let aqLow=0, aqCool=performance.now()+4000;
function autoQuality(fps, now){
    if(!autoChk.checked || document.hidden || hudEdit || !$('graphics-modal').classList.contains('hidden') || now<aqCool){ aqLow=0; return; }
    const target = fpsCap>0 ? Math.min(fpsCap,60) : 60;
    if(fps >= target*0.88){ aqLow=0; return; }
    if(++aqLow<3) return;
    aqLow=0; aqCool=now+3000;
    const rs=parseFloat(rsInput.value), sh=shadowSel.value;
    if(sh==='ultra') shadowSel.value='high';
    else if(rs>0.75) rsInput.value=rs-0.25;
    else if(sh==='high') shadowSel.value='low';
    else if(rs>0.5) rsInput.value=rs-0.25;
    else if(sh==='low') shadowSel.value='off';
    else return;
    onManualGfx();
    showBanner('Авто-качество: снижена нагрузка для 60 FPS', 1500);
}

$('btn-graphics').addEventListener('click', ()=>$('graphics-modal').classList.remove('hidden'));
$('close-graphics-btn').addEventListener('click', ()=>$('graphics-modal').classList.add('hidden'));
$('btn-fullscreen').addEventListener('click', ()=>{
    if(document.fullscreenElement) document.exitFullscreen();
    else wrapper.requestFullscreen && wrapper.requestFullscreen();
});

// ---------- КОЛЛИЗИИ ----------
function resolveCollisions(p, r){
    for(const c of colliders){
        // Боковые столкновения работают только когда игрок по высоте пересекается с блоком.
        const feet = p.y || 0;
        const head = feet + (player.crouch ? 1.15 : 1.75);
        if(head <= (c.minY ?? 0) + 0.02 || feet >= (c.maxY ?? 5) - 0.02) continue;
        const cx = Math.max(c.minX, Math.min(p.x, c.maxX));
        const cz = Math.max(c.minZ, Math.min(p.z, c.maxZ));
        const dx = p.x-cx, dz = p.z-cz;
        const d2 = dx*dx+dz*dz;
        if(d2 < r*r){
            if(d2>1e-6){
                const d=Math.sqrt(d2), push=r-d;
                p.x += dx/d*push; p.z += dz/d*push;
            } else {
                // внутри бокса — выталкиваем по минимальной оси
                const ox = Math.min(p.x-c.minX+r, c.maxX+r-p.x);
                const oz = Math.min(p.z-c.minZ+r, c.maxZ+r-p.z);
                if(ox<oz) p.x = (p.x-c.minX < c.maxX-p.x) ? c.minX-r : c.maxX+r;
                else p.z = (p.z-c.minZ < c.maxZ-p.z) ? c.minZ-r : c.maxZ+r;
            }
        }
    }
    p.x = Math.max(-WORLD+1, Math.min(WORLD-1, p.x));
    p.z = Math.max(-WORLD+1, Math.min(WORLD-1, p.z));
}

// ---------- МИНИКАРТА ----------
function drawMinimap(){
    const S = minimap.width;
    mmCtx.clearRect(0,0,S,S);
    mmCtx.fillStyle='rgba(10,14,20,0.92)';
    mmCtx.beginPath(); mmCtx.arc(S/2,S/2,S/2,0,Math.PI*2); mmCtx.fill();
    const k = S/(WORLD*2);
    mmCtx.fillStyle='rgba(120,140,170,0.75)';
    for(const c of colliders){
        mmCtx.fillRect((c.minX+WORLD)*k, (c.minZ+WORLD)*k, (c.maxX-c.minX)*k, (c.maxZ-c.minZ)*k);
    }
    // боты: союзники синие, враги красные
    for(const b of bots){
        if(b.dead) continue;
        mmCtx.fillStyle = b.team==='ally' ? '#38bdf8' : '#ff5544';
        const bx=(b.grp.position.x+WORLD)*k, bz=(b.grp.position.z+WORLD)*k;
        mmCtx.beginPath(); mmCtx.arc(bx,bz,b.team==='ally'?2.2:1.8,0,Math.PI*2); mmCtx.fill();
    }
    // игрок (стрелка)
    const px=(player.pos.x+WORLD)*k, pz=(player.pos.z+WORLD)*k;
    mmCtx.save();
    mmCtx.translate(px,pz);
    mmCtx.rotate(-player.yaw);
    mmCtx.fillStyle='#38e8ff';
    mmCtx.beginPath(); mmCtx.moveTo(0,-3.5); mmCtx.lineTo(2.5,2.5); mmCtx.lineTo(-2.5,2.5); mmCtx.closePath(); mmCtx.fill();
    mmCtx.restore();
}

const tmpV = new THREE.Vector3();
// ---------- БОТ ИИ ----------
const aiRay = new THREE.Raycaster();
const aiFrom = new THREE.Vector3(), aiTo = new THREE.Vector3(), aiDir = new THREE.Vector3();
const posOf = t => t===player ? player.pos : t.grp.position;

function canSee(a, b){
    aiFrom.set(a.x, 1.5, a.z); aiTo.set(b.x, 1.5, b.z);
    aiDir.subVectors(aiTo, aiFrom); const d = aiDir.length(); if(d<0.01) return true;
    aiDir.divideScalar(d);
    aiRay.set(aiFrom, aiDir); aiRay.near = 0.1; aiRay.far = d;
    return aiRay.intersectObjects(wallMeshes,false).length===0;
}

function findEnemy(bot){
    const me = bot.grp.position;
    let best = null, bd = 42;
    const consider = t => {
        const p = posOf(t), d = Math.hypot(p.x-me.x, p.z-me.z);
        if(d<bd && canSee(me,p)){ bd=d; best=t; }
    };
    if(bot.team==='enemy'){
        if(player.alive) consider(player);
        for(const o of bots) if(o.team==='ally' && !o.dead) consider(o);
    } else {
        for(const o of bots) if(o.team==='enemy' && !o.dead) consider(o);
    }
    bot.enemy = best; bot.enemyDist = bd;
}

function randomPoint(){
    let nx, nz, t=0;
    do{ nx=(Math.random()*2-1)*(WORLD-3); nz=(Math.random()*2-1)*(WORLD-3); t++; }
    while(t<15 && pointInCollider(nx,nz,0.8));
    return [nx,nz];
}

function botShoot(bot, tgt, dist){
    const isP = tgt===player, tp = posOf(tgt);
    const base = bot.team==='ally' ? 0.5 : 0.4;
    const hit = Math.random() < Math.max(0.1, base - dist*0.008);
    const from = bot.grp.position.clone(); from.y = 1.35;
    const to = new THREE.Vector3(tp.x, isP ? player.eyeH*0.85 : 1.2, tp.z);
    if(!hit){ to.x += (Math.random()*2-1)*2.2; to.y += (Math.random()*2-1)*1.2; to.z += (Math.random()*2-1)*2.2; }
    spawnTracer(from, to, bot.team==='ally' ? 0x7ab8ff : 0xff8866);
    if(!hit) return;
    if(isP) applyDamage(7+Math.random()*7, bot);
    else damageBot(tgt, 22+Math.random()*14, Math.random()<0.15?'head':'body', bot);
}

function updateBot(bot, dt){
    const g = bot.grp;
    if(roundState==='buy') return;
    if(bot.dead){
        if(gameMode!==MODE.TDM) return;
        bot.respawnT -= dt;
        if(bot.respawnT<=0 && !matchOver) respawnBot(bot);
        return;
    }
    bot.checkT -= dt;
    if(bot.checkT<=0){ bot.checkT = 0.3 + Math.random()*0.15; findEnemy(bot); }
    // цель могла умереть
    if(bot.enemy && ((bot.enemy===player && !player.alive) || (bot.enemy!==player && bot.enemy.dead))) bot.enemy = null;

    let mvx=0, mvz=0;
    const speed = bot.team==='ally' ? 3.5 : 3.1;

    if(bot.enemy){
        const tp = posOf(bot.enemy);
        const ang = Math.atan2(tp.x-g.position.x, tp.z-g.position.z);
        g.rotation.y = ang;
        const dist = Math.hypot(tp.x-g.position.x, tp.z-g.position.z);
        bot.enemyDist = dist;
        bot.strafeT -= dt;
        if(bot.strafeT<=0){ bot.strafeT = 1+Math.random()*1.5; bot.strafe *= -1; }
        const ideal = 14;
        const toward = dist>ideal ? 1 : (dist<ideal-5 ? -1 : 0);
        mvx = Math.sin(ang)*toward + Math.cos(ang)*bot.strafe*0.8;
        mvz = Math.cos(ang)*toward - Math.sin(ang)*bot.strafe*0.8;
        bot.fireCd -= dt;
        if(bot.fireCd<=0){
            bot.fireCd = 0.7 + Math.random()*0.8;
            botShoot(bot, bot.enemy, dist);
        }
    } else {
        // нет цели: союзники держатся рядом с игроком, враги патрулируют и давят
        let gx, gz;
        if(bot.team==='ally' && player.alive){
            const a = bot.slot*1.05 + player.yaw*0 ;
            gx = player.pos.x + Math.cos(a)*4.5; gz = player.pos.z + Math.sin(a)*4.5;
            bot.target.set(gx,0,gz);
        } else {
            tmpV.set(bot.target.x-g.position.x, 0, bot.target.z-g.position.z);
            if(tmpV.length()<1.4){
                let p;
                if(bot.team==='enemy' && Math.random()<0.5){
                    const pool = [player.alive?player.pos:null].concat(bots.filter(o=>o.team==='ally'&&!o.dead).map(o=>o.grp.position)).filter(Boolean);
                    const t = pool.length ? pool[Math.floor(Math.random()*pool.length)] : null;
                    p = t ? [t.x+(Math.random()-0.5)*10, t.z+(Math.random()-0.5)*10] : randomPoint();
                    if(pointInCollider(p[0],p[1],0.8)) p = randomPoint();
                } else p = randomPoint();
                bot.target.set(Math.max(-WORLD+2,Math.min(WORLD-2,p[0])),0,Math.max(-WORLD+2,Math.min(WORLD-2,p[1])));
            }
        }
        tmpV.set(bot.target.x-g.position.x, 0, bot.target.z-g.position.z);
        const d = tmpV.length();
        if(d>(bot.team==='ally'?1.6:1.0)){
            tmpV.normalize(); mvx=tmpV.x; mvz=tmpV.z;
            g.rotation.y = Math.atan2(mvx, mvz);
            // застрял -> новая точка
            bot.stuckT += dt;
            if(bot.stuckT>0.6){
                if(Math.hypot(g.position.x-bot.lastX, g.position.z-bot.lastZ)<0.25){
                    const p = randomPoint(); bot.target.set(p[0],0,p[1]);
                    bot.strafe *= -1;
                }
                bot.stuckT = 0; bot.lastX = g.position.x; bot.lastZ = g.position.z;
            }
        }
    }
    const len = Math.hypot(mvx,mvz);
    if(len>0.01){
        const sp = (bot.enemy?0.85:1) * speed;
        g.position.x += mvx/len*sp*dt;
        g.position.z += mvz/len*sp*dt;
        resolveCollisions(g.position, 0.45);
    }
    // отталкивание от других ботов и игрока
    for(const o of bots){
        if(o===bot || o.dead) continue;
        const dx=g.position.x-o.grp.position.x, dz=g.position.z-o.grp.position.z;
        const d2=dx*dx+dz*dz;
        if(d2<0.81 && d2>1e-4){
            const d=Math.sqrt(d2), push=(0.9-d)*0.5;
            g.position.x+=dx/d*push; g.position.z+=dz/d*push;
        }
    }
    if(player.alive){
        const dx=g.position.x-player.pos.x, dz=g.position.z-player.pos.z, d2=dx*dx+dz*dz;
        if(d2<0.64 && d2>1e-4){ const d=Math.sqrt(d2), push=(0.8-d)*0.5; g.position.x+=dx/d*push; g.position.z+=dz/d*push; }
    }
    bot.body.position.y = 0.85 + Math.sin(performance.now()*0.008 + bot.id)*0.03;
}

// ---------- ОБНОВЛЕНИЕ ИГРОКА ----------
const chArms = { top:$('ch-top'), bottom:$('ch-bottom'), left:$('ch-left'), right:$('ch-right') };
[chArms.top,chArms.bottom,chArms.left,chArms.right].forEach(a=>{
    a.style.transform='translate(-50%,-50%)'; a.style.left='50%'; a.style.top='50%';
});

function updatePlayer(dt, now){
    // ввод
    let f = (keys['KeyW']?1:0)-(keys['KeyS']?1:0) + (-joy.y);
    let s = (keys['KeyD']?1:0)-(keys['KeyA']?1:0) + joy.x;
    const fl = Math.hypot(f,s);
    if(fl>1){ f/=fl; s/=fl; }
    const speed = player.crouch?2.6:5.4;
    const sinY=Math.sin(player.yaw), cosY=Math.cos(player.yaw);
    const mx = (-sinY*f + cosY*s)*speed;
    const mz = (-cosY*f - sinY*s)*speed;
    player.vel.x = mx; player.vel.z = mz;
    // Прыжки на блоки: приземлиться можно только на верхнюю поверхность,
    // если высоты прыжка хватает. Через высокие блоки пройти нельзя.
    const prevY = player.pos.y;
    player.vel.y -= 22*dt;
    if(keys['Space'] && player.onGround){ player.vel.y=7.5; player.onGround=false; }
    player.pos.x += player.vel.x*dt;
    player.pos.z += player.vel.z*dt;
    player.pos.y += player.vel.y*dt;
    let landedTop = 0;
    if(player.vel.y <= 0){
        for(const c of colliders){
            const top = c.maxY ?? 0;
            if(top <= 0.02 || prevY < top - 0.02 || player.pos.y > top) continue;
            if(player.pos.x >= c.minX-0.32 && player.pos.x <= c.maxX+0.32 &&
               player.pos.z >= c.minZ-0.32 && player.pos.z <= c.maxZ+0.32){
                if(top > landedTop) landedTop = top;
            }
        }
    }
    if(landedTop > 0){ player.pos.y=landedTop; player.vel.y=0; player.onGround=true; }
    else if(player.pos.y<=0){ player.pos.y=0; player.vel.y=0; player.onGround=true; }
    else { player.onGround=false; }
    resolveCollisions(player.pos, 0.4);

    // камера
    const targetEye = player.crouch?1.08:1.7;
    player.eyeH += (targetEye-player.eyeH)*Math.min(1, dt*10);
    camera.position.set(player.pos.x, player.pos.y+player.eyeH, player.pos.z);
    camera.rotation.y = player.yaw;
    camera.rotation.x = player.pitch;

    // авто-огонь
    if(fireHeld && WEAPONS[curWeapon].auto) tryFire(now);

    // fov / прицел
    const W = WEAPONS[curWeapon];
    const targetFov = aiming ? W.aimFov : 75;
    camera.fov += (targetFov-camera.fov)*Math.min(1, dt*12);
    camera.updateProjectionMatrix();
    const scoped = W.scoped && aiming;
    scopeEl.style.display = scoped ? 'block' : 'none';
    crosshairEl.style.opacity = scoped ? '0' : '1';
    gunGroup.visible = !scoped;

    // анимация оружия: откат, sway, bob
    gunKick.z += (0-gunKick.z)*Math.min(1,dt*9);
    gunKick.x += ((reloading?0.35:0)-gunKick.x)*Math.min(1,dt*7);
    gunKick.y += (0-gunKick.y)*Math.min(1,dt*8);
    const moving = Math.hypot(player.vel.x, player.vel.z)>0.4;
    gunBob += dt*(moving?10:2);
    const bobY=Math.sin(gunBob)*(moving?0.012:0.004);
    const bobX=Math.cos(gunBob*0.5)*(moving?0.008:0.003);
    gunSway += dt;
    gunGroup.position.set(0.28+bobX+Math.sin(gunSway*1.1)*0.006+gunKick.y, -0.24+bobY+Math.cos(gunSway*0.9)*0.004+gunKick.x*0.05, -0.42+gunKick.z);
    gunGroup.rotation.set(0.02+gunKick.x*0.15, 0.08+gunKick.y*0.5, 0.04-gunKick.z*0.2);

    // блум прицела
    bloom = Math.max(0, bloom - dt*1.6);
    const moveSpread = Math.min(8, Math.hypot(player.vel.x,player.vel.z)*1.1);
    const gap = 8 + bloom*14 + moveSpread;
    chArms.top.style.top = 'calc(50% - '+gap+'px)';
    chArms.bottom.style.top = 'calc(50% + '+gap+'px)';
    chArms.left.style.left = 'calc(50% - '+gap+'px)';
    chArms.right.style.left = 'calc(50% + '+gap+'px)';

    // дыхание
    if(player.alive && Math.hypot(player.vel.x,player.vel.z)>0.5 && player.onGround){
        camera.position.y += Math.sin(now*0.012)*0.02;
    }
}

// ---------- ВЫБОР КАРТЫ ----------
function resetLoadoutKeepSide(){
  scoreCT=scoreTR=0; roundNumber=1; playerMoney=800; nades=0; hasBomb=false;
  for(const k in owned){ if(+k!==4 && +k!==9) delete owned[k]; }
  owned[4]=true; owned[9]=true; curWeapon=4;
  for(const k in WEAPONS) wstate[k]={ammo:WEAPONS[k].mag, reserve:WEAPONS[k].reserve};
  refreshWeaponSwitcher(); buildGun(4); updateSideHUD(); startBuyPhase();
}
const _ms=$('mode-select'); if(_ms) _ms.addEventListener('change', e=>{ gameMode=e.target.value; resetLoadoutKeepSide(); });
const _ss=$('side-select'); if(_ss) _ss.addEventListener('change', e=>{ playerSide=e.target.value; resetLoadoutKeepSide(); });

$('map-select').addEventListener('change', e=>{
    const chosen=e.target.value;
    if(!['arena','dust','mirage'].includes(chosen)) return;
    currentMap=chosen;
    buildMap(currentMap);
    // Переставляем игроков в безопасные стартовые зоны, чтобы карта сразу была играбельной.
    player.pos.set(0,0,24); player.vel.set(0,0,0); player.onGround=true; player.yaw=0; player.pitch=0;
    for(const b of bots) respawnBot(b);
    showBanner('Карта: '+(chosen==='dust'?'Dust · пустынный маршрут':chosen==='mirage'?'Mirage · городская арена':'Арена'));
});

// ---------- FPS-МЕТР ----------
const frameTimes = [];
let fpsAccum=0, fpsFrames=0, lastFpsUpdate=performance.now();

function updateFps(dt, now){
    fpsAccum+=dt; fpsFrames++;
    frameTimes.push(dt*1000);
    if(frameTimes.length>55) frameTimes.shift();
    if(now-lastFpsUpdate>=500){
        const fps = Math.round(fpsFrames/fpsAccum);
        fpsVal.textContent = fps;
        autoQuality(fps, now);
        fpsVal.className = fps>=50?'text-green-400':(fps>=30?'text-amber-400':'text-red-400');
        frameTimeEl.textContent = (fpsAccum/fpsFrames*1000).toFixed(1);
        fpsAccum=0; fpsFrames=0; lastFpsUpdate=now;
        // график
        fgCtx.clearRect(0,0,110,30);
        const max=40;
        frameTimes.forEach((ms,i)=>{
            const h=Math.min(30, ms/max*30);
            fgCtx.fillStyle = ms<20?'#4ade80':(ms<33?'#fbbf24':'#f87171');
            fgCtx.fillRect(108-i*2, 30-h, 1.6, h);
        });
    }
}


// ---------- ROUND SYSTEM ----------
function startBuyPhase(){
    roundState='buy'; roundTimer=ROUND_BUY_TIME;
    bomb=null; defuseProgress=0;
    if(window._bombMesh){ scene.remove(window._bombMesh); window._bombMesh=null; }
    bots.forEach(respawnBot);
    respawnPlayer();
    placeSites();
    if(gameMode===MODE.PLANT && playerIsT()) hasBomb=true; else hasBomb=false;
    updateRoundHUD(); updateMoneyHUD(); updateSideHUD();
    openBuyMenu();
    showBanner('<span style="color:#4ade80">ФАЗА ПОКУПКИ — 10с</span>', 1800);
}
function startLivePhase(){
    roundState='live';
    roundTimer = gameMode===MODE.PLANT ? ROUND_TIME_PLANT : ROUND_TIME_TDM;
    closeBuyMenu();
    updateRoundHUD();
    showBanner('<span style="color:#ff8c00">РАУНД НАЧАЛСЯ</span>', 1400);
    if(gameMode===MODE.PLANT && playerIsCT()){
        const enemies=bots.filter(b=>b.team==='enemy'&&!b.dead);
        if(enemies.length) enemies[0]._bomber=true;
    }
    if(gameMode===MODE.PLANT && playerIsT()) hasBomb = true;
    plantProgress=0; defuseProgress=0;
}
function endRound(winner, reason){
    if(roundState==='end'||matchOver) return;
    roundState='end'; closeBuyMenu(); updatePrompt('');
    // winner: 'ct' | 't'
    const w = (winner==='ally'||winner==='ct') ? 'ct' : 't';
    if(w==='ct') scoreCT++; else scoreTR++;
    const playerWon = (w==='ct' && playerSide==='ct') || (w==='t' && playerSide==='t');
    if(playerWon) playerMoney=Math.min(16000, playerMoney + 3250 + (reason&&reason.indexOf('БОМБА')>=0?300:0));
    else playerMoney=Math.min(16000, playerMoney + 1400);
    updateMoneyHUD(); updateRoundHUD();
    const title = playerWon ? '<span style="color:#4ade80">РАУНД ВЫИГРАН</span>' : '<span style="color:#f87171">РАУНД ПРОИГРАН</span>';
    const sub = '<br><span style="font-size:15px;color:#94a3b8">'+(reason||'')+' · '+w.toUpperCase()+' · $'+playerMoney+'</span>';
    showBanner(title+sub, 3000);
    const es=$('end-round-screen');
    if(es){ es.classList.remove('hidden'); es.innerHTML='<div class="so2-panel p-4 rounded-xl text-center"><div class="text-2xl font-bold mb-1">'+(playerWon?'ПОБЕДА РАУНДА':'ПОРАЖЕНИЕ')+'</div><div class="text-slate-300 text-sm">'+(reason||'')+'</div><div class="text-emerald-400 mt-2">$'+playerMoney+'</div></div>'; setTimeout(()=>es.classList.add('hidden'), 3500); }

    if(scoreCT>=ROUNDS_TO_WIN||scoreTR>=ROUNDS_TO_WIN){
        matchOver=true;
        setTimeout(()=>{
            showBanner(scoreCT>=ROUNDS_TO_WIN?'<span style="color:#4ade80">ПОБЕДА В МАТЧЕ</span>':'<span style="color:#f87171">ПОРАЖЕНИЕ В МАТЧЕ</span>',4500);
            setTimeout(()=>{ matchOver=false; scoreCT=scoreTR=0; roundNumber=1; playerMoney=800;
                for(const k in owned){ if(+k!==4 && +k!==9) delete owned[k]; } owned[4]=true; owned[9]=true; curWeapon=4; nades=0;
                for(const k in WEAPONS) wstate[k]={ammo:WEAPONS[k].mag,reserve:WEAPONS[k].reserve};
                refreshWeaponSwitcher(); buildGun(4); startBuyPhase();
            }, 5000);
        }, 3000);
        return;
    }
    setTimeout(()=>{ roundNumber++; startBuyPhase(); }, 4000);
}
function checkRoundElim(){
    if(roundState!=='live'||matchOver) return;
    const a=countAlive('ally'), e=countAlive('enemy');
    // ally = player's team bots + player, enemy = opposite
    if(e===0 && !(bomb&&bomb.planted)) endRound(playerSide==='ct'?'ct':'t','ВРАГИ УНИЧТОЖЕНЫ');
    else if(a===0) endRound(playerSide==='ct'?'t':'ct','КОМАНДА УНИЧТОЖЕНА');
}
function plantBombAt(x,z,name){
    bomb={planted:true,timer:BOMB_FUSE,x,z,site:name};
    const mesh=new THREE.Mesh(new THREE.BoxGeometry(0.35,0.2,0.5), new THREE.MeshStandardMaterial({color:0x2a2a2a,emissive:0x331100,emissiveIntensity:0.4}));
    mesh.position.set(x,0.12,z); scene.add(mesh); window._bombMesh=mesh;
    showBanner('<span style="color:#ff8c00">БОМБА УСТАНОВЛЕНА НА '+name+'</span>',2200);
}
function updateBombLogic(dt){
    if(gameMode!==MODE.PLANT||roundState!=='live'){ updatePrompt(''); return; }
    const holding = keys['KeyE']||keys['KeyF']||window._useHeld;

    // Player PLANTS as T
    if(playerIsT() && hasBomb && !bomb && player.alive){
        const site = nearSite(player.pos);
        if(site && holding){
            plantProgress += dt;
            updatePrompt('[E] Установка '+site.name+' '+(Math.min(1,plantProgress/PLANT_TIME)*100|0)+'%');
            if(plantProgress >= PLANT_TIME){
                plantBombAt(site.x, site.z, site.name);
                hasBomb = false; plantProgress = 0;
                playerMoney = Math.min(16000, playerMoney+300); updateMoneyHUD();
            }
        } else {
            plantProgress = 0;
            if(site) updatePrompt('[E] Установить бомбу · '+site.name);
            else updatePrompt(hasBomb ? 'Неси бомбу на сайт A/B' : '');
        }
    }

    // Player DEFUSES as CT
    if(bomb && bomb.planted && player.alive && playerIsCT()){
        const d = Math.hypot(player.pos.x-bomb.x, player.pos.z-bomb.z);
        if(d<1.8){
            if(holding){
                defuseProgress += dt;
                updatePrompt('[E] Обезвредить '+(Math.min(1,defuseProgress/DEFUSE_TIME)*100|0)+'%');
                if(defuseProgress >= DEFUSE_TIME){
                    endRound('ct','БОМБА ОБЕЗВРЕЖЕНА');
                    bomb = null; defuseProgress = 0;
                    if(window._bombMesh){ scene.remove(window._bombMesh); window._bombMesh=null; }
                    playerMoney = Math.min(16000, playerMoney+300); updateMoneyHUD();
                }
            } else {
                defuseProgress = 0;
                updatePrompt('[E] Обезвредить бомбу');
            }
        } else {
            defuseProgress = 0;
            if(!(playerIsT() && hasBomb)) updatePrompt('');
        }
    }

    // Bomb fuse
    if(bomb && bomb.planted){
        bomb.timer -= dt;
        const bt=$('bomb-timer');
        if(bt){ bt.textContent='💣 '+Math.ceil(Math.max(0,bomb.timer))+'s'; bt.classList.remove('hidden'); }
        // soft beep via banner flash every second near end
        if(bomb.timer<=10 && bomb.timer>0 && Math.floor(bomb.timer*2)%2===0){
            // visual only
        }
        if(bomb.timer<=0){
            const bx=bomb.x, bz=bomb.z;
            if(player.alive && Math.hypot(player.pos.x-bx, player.pos.z-bz)<12) applyDamage(150);
            bots.forEach(b=>{
                if(!b.dead && Math.hypot(b.grp.position.x-bx, b.grp.position.z-bz)<12){
                    b.hp=0; killBot(b,{name:'BOMB',team: playerSide==='t'?'ally':'enemy'},false);
                }
            });
            if(window._bombMesh){ scene.remove(window._bombMesh); window._bombMesh=null; }
            bomb=null;
            endRound('t','БОМБА ВЗОРВАЛАСЬ');
        }
        return;
    } else {
        const bt2=$('bomb-timer'); if(bt2) bt2.classList.add('hidden');
    }

    // AI plant only when player is CT (enemies are T)
    if(playerIsCT()){
        bots.forEach(b=>{
            if(b.team!=='enemy'||b.dead||!b._bomber||(bomb&&bomb.planted)) return;
            const site=nearSite(b.grp.position);
            if(site){ b._plantT=(b._plantT||0)+dt; if(b._plantT>=PLANT_TIME){ plantBombAt(site.x,site.z,site.name); b._bomber=false; } }
            else { b._plantT=0; const s=(BOMB_SITES[currentMap]||BOMB_SITES.arena)[0]; b.target.set(s.x,0,s.z); }
        });
    }
    // AI defuse when player is T (enemies are CT)
    if(playerIsT() && bomb && bomb.planted){
        bots.forEach(b=>{
            if(b.team!=='enemy'||b.dead) return;
            const d=Math.hypot(b.grp.position.x-bomb.x, b.grp.position.z-bomb.z);
            if(d<2.0){
                b._defT=(b._defT||0)+dt;
                if(b._defT>=DEFUSE_TIME){
                    endRound('ct','БОМБА ОБЕЗВРЕЖЕНА ВРАГОМ');
                    bomb=null; if(window._bombMesh){scene.remove(window._bombMesh);window._bombMesh=null;}
                }
            } else {
                b._defT=0;
                b.target.set(bomb.x,0,bomb.z);
            }
        });
    }
}
function updateRound(dt){
    if(matchOver||roundState==='end') return;
    roundTimer-=dt;
    if(roundTimer<=0){
        if(roundState==='buy') startLivePhase();
        else if(roundState==='live'){
            if(gameMode===MODE.PLANT){
                if(bomb&&bomb.planted) roundTimer=0.1;
                else endRound('ct','ВРЕМЯ — БОМБА НЕ УСТАНОВЛЕНА');
            } else {
                const ca=countAlive('ally'), ce=countAlive('enemy');
                if(ca>ce) endRound(playerSide==='ct'?'ct':'t','ПО ЖИВЫМ');
                else if(ce>ca) endRound(playerSide==='ct'?'t':'ct','ПО ЖИВЫМ');
                else endRound(playerSide==='ct'?'ct':'t','НИЧЬЯ');
            }
        }
    }
    updateRoundHUD();
    updateBombLogic(dt);
}

// ---------- MAIN LOOP ----------
let lastRender = 0, prevFrame = 0;
function loop(now){
    requestAnimationFrame(loop);
    const interval = fpsCap>0 ? 1000/fpsCap : 0;
    const elapsed = now - lastRender;
    if(elapsed < interval - 1) return;           // ещё рано (допуск 1 мс на джиттер)
    // компенсация дрейфа: ровный ритм 60 кадров на экранах 60/90/120 Гц
    lastRender = (interval && elapsed < interval*4) ? now - (elapsed % interval) : now;
    let dt = (now - prevFrame)/1000;
    prevFrame = now;
    if(dt>0.05) dt=0.05;
    if(dt<=0) dt=0.001;

    updateRound(dt);
    if(player.alive) updatePlayer(dt, now);
    else { camera.rotation.y += dt*0.4; }

    for(let i=bots.length-1;i>=0;i--) updateBot(bots[i], dt);
    entityCount.textContent = countAlive('ally')+' / '+countAlive('enemy');

    // трассеры
    for(let i=tracers.length-1;i>=0;i--){
        const t=tracers[i];
        t.life-=dt;
        if(t.life<=0){ scene.remove(t.line); t.line.geometry.dispose(); t.line.material.dispose(); tracers.splice(i,1); }
        else t.line.material.opacity = t.life/0.07*0.9;
    }
    muzzleLight.intensity = Math.max(0, muzzleLight.intensity - dt*30);

    drawMinimap();
    updateFps(dt, now);
    renderer.render(scene, camera);
}

// ---------- RESIZE ----------
function onResize(){
    const w = Math.max(1, window.innerWidth);
    const h = Math.max(1, window.innerHeight);
    camera.aspect = w/h;
    camera.updateProjectionMatrix();
    const scale = (typeof renderScale==='number' && renderScale>0) ? renderScale : 1;
    renderer.setSize(Math.floor(w*scale), Math.floor(h*scale), false);
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';
    renderer.domElement.style.display = 'block';
    for(const k in hudEls) try{ clampHud(hudEls[k]); }catch(e){}
}
addEventListener('resize', onResize);

// ---------- INIT ----------
try {
  const dh = $('desktop-hint'); if(dh) dh.style.display = 'none';
} catch(e) {}
loadSave();
if(!owned[save.weapon]) save.weapon = 4;
try { syncGfxUI(); } catch(e) {}
onResize();
try { applyGraphics(); } catch(e) {}
try { applyHudScale(); } catch(e) {}
try { applyHudLayout(); } catch(e) {}
try { switchWeapon(save.weapon || 4); } catch(e) { try { switchWeapon(4); } catch(e2) {} }
try { createTeams(); } catch(e) { console.error('createTeams', e); }
updateAmmoHUD();
updateMoneyHUD();
try { refreshWeaponSwitcher(); } catch(e) {}
try { updateSideHUD(); } catch(e) {}
// touch bindings for use/nade
(function(){
  const u=$('btn-use');
  if(u){ u.addEventListener('pointerdown', e=>{ e.preventDefault(); e.stopPropagation(); window._useHeld=true; audio&&audio(); });
        ['pointerup','pointercancel','pointerleave'].forEach(ev=>u.addEventListener(ev, ()=>{ window._useHeld=false; })); }
  const n=$('btn-nade');
  if(n) n.addEventListener('pointerdown', e=>{ e.preventDefault(); e.stopPropagation(); if(typeof throwNade==='function') throwNade(); });
  const bc=$('buy-close'); if(bc) bc.onclick=()=>closeBuyMenu();
  const bb=$('btn-buy'); if(bb) bb.onclick=()=>{ if(roundState==='buy') openBuyMenu(); };
})();
try { startBuyPhase(); } catch(e) { console.error('startBuy', e); }
// ensure canvas visible
try {
  renderer.domElement.style.zIndex = '1';
  renderer.domElement.style.position = 'absolute';
  renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2));
  onResize();
} catch(e) {}
requestAnimationFrame(loop);


} catch(err) {
  console.error(err);
  try {
    var d=document.createElement("div");
    d.style.cssText="position:fixed;inset:0;z-index:99999;background:#111;color:#f66;padding:20px;font:14px monospace;overflow:auto";
    d.textContent="Ошибка игры: "+err+("\n"+err.stack);
    document.body.appendChild(d);
  } catch(e) {}
}
})();