/* Standoff 3D
   Добавлено:
   - меню выбора карты: Sandstone и Dust 2;
   - скрыт большой FPS-блок сверху;
   - более детализированные модели оружия;
   - анимация перезарядки;
   - затвор AWP щёлкает после выстрела. */
(function(){
'use strict';

const $=id=>document.getElementById(id);
const container=$('game-container');
const wrapper=$('game-wrapper');

const ammoCur=$('ammo-cur'),ammoMax=$('ammo-max'),hpVal=$('hp-val'),armorVal=$('armor-val');
const scoreCtEl=$('score-ct'),scoreTrEl=$('score-tr');
const killFeedEl=$('kill-feed'),vignette=$('damage-vignette'),scopeEl=$('sniper-scope');
const hitmarkerEl=$('hitmarker'),crosshairEl=$('crosshair');
const minimap=$('minimap'),mmCtx=minimap.getContext('2d');
const fpsVal=$('fps-val');

/* ================= МЕНЮ КАРТ ================= */

let selectedMap=localStorage.getItem('standoff3d_map_v2')||'sandstone';
let matchStarted=false;

const mapMenu=document.createElement('div');
mapMenu.id='map-menu';
mapMenu.innerHTML=`
  <div class="menu-card">
    <div class="menu-title">STANDOFF 3D</div>
    <div class="menu-sub">Выберите карту</div>
    <button class="map-btn sandstone" data-map="sandstone">
      <span>SANDSTONE</span><small>Песчаная арена</small>
    </button>
    <button class="map-btn dust2" data-map="dust2">
      <span>DUST 2</span><small>Классическая пыльная карта</small>
    </button>
  </div>`;
container.appendChild(mapMenu);

const menuStyle=document.createElement('style');
menuStyle.textContent=`
#map-menu{
  position:absolute;inset:0;z-index:100;
  display:flex;align-items:center;justify-content:center;
  background:radial-gradient(circle at 50% 30%,rgba(45,64,89,.92),rgba(4,7,12,.98));
  backdrop-filter:blur(6px)
}
.menu-card{
  width:min(92vw,430px);padding:28px 22px;
  border:1px solid rgba(255,140,0,.35);border-radius:22px;
  background:linear-gradient(180deg,rgba(15,23,42,.94),rgba(2,6,23,.97));
  box-shadow:0 20px 60px #000;text-align:center
}
.menu-title{font:900 34px Arial;letter-spacing:.12em;color:#fff}
.menu-sub{color:#94a3b8;margin:7px 0 22px}
.map-btn{
  display:block;width:100%;margin:12px 0;padding:18px 16px;
  border:1px solid rgba(255,255,255,.12);border-radius:14px;color:white;
  text-align:left;transition:.18s;cursor:pointer
}
.map-btn span{display:block;font:900 22px Arial;letter-spacing:.08em}
.map-btn small{display:block;margin-top:4px;color:#cbd5e1}
.map-btn.sandstone{background:linear-gradient(90deg,rgba(146,104,55,.78),rgba(80,58,34,.9))}
.map-btn.dust2{background:linear-gradient(90deg,rgba(176,124,64,.8),rgba(91,64,38,.94))}
.map-btn:hover{
  transform:translateY(-2px);border-color:#ff8c00;
  box-shadow:0 8px 28px rgba(255,140,0,.24)
}`;
document.head.appendChild(menuStyle);

mapMenu.addEventListener('click',e=>{
  const btn=e.target.closest('.map-btn');
  if(!btn)return;
  selectedMap=btn.dataset.map;
  localStorage.setItem('standoff3d_map_v2',selectedMap);
  mapMenu.style.display='none';
  matchStarted=true;
  audio();
  loadMap(selectedMap);
  startMatch();
});

/* Кнопка возврата в меню карт */
const mapButton=document.createElement('button');
mapButton.id='btn-map-menu';
mapButton.innerHTML='<i class="fa-solid fa-map"></i><span> КАРТЫ</span>';
mapButton.className='px-2.5 py-1 bg-slate-800/80 hover:bg-orange-500 border border-slate-600 rounded-lg text-xs font-sans font-semibold transition';
const graphicsButton=$('btn-graphics');
if(graphicsButton&&graphicsButton.parentElement)graphicsButton.parentElement.appendChild(mapButton);

mapButton.addEventListener('click',()=>{
  matchStarted=false;
  mapMenu.style.display='flex';
});

/* ================= ЗВУК ================= */

let AC=null;

function audio(){
  if(!AC){
    try{AC=new (window.AudioContext||window.webkitAudioContext)();}catch(e){}
  }
  if(AC&&AC.state==='suspended')AC.resume();
  return AC;
}

function noise(dur,vol,filterFreq,type){
  const ac=audio();if(!ac)return;
  const t=ac.currentTime;
  const len=Math.floor(ac.sampleRate*dur);
  const buf=ac.createBuffer(1,len,ac.sampleRate);
  const d=buf.getChannelData(0);

  for(let i=0;i<len;i++){
    d[i]=(Math.random()*2-1)*Math.pow(1-i/len,1.7);
  }

  const src=ac.createBufferSource();
  src.buffer=buf;

  const filter=ac.createBiquadFilter();
  filter.type=type||'lowpass';
  filter.frequency.value=filterFreq;

  const gain=ac.createGain();
  gain.gain.setValueAtTime(vol,t);
  gain.gain.exponentialRampToValueAtTime(.001,t+dur);

  src.connect(filter);
  filter.connect(gain);
  gain.connect(ac.destination);
  src.start(t);
}

function tone(freq,endFreq,dur,vol,type){
  const ac=audio();if(!ac)return;
  const t=ac.currentTime;

  const osc=ac.createOscillator();
  const gain=ac.createGain();

  osc.type=type||'square';
  osc.frequency.setValueAtTime(freq,t);
  osc.frequency.exponentialRampToValueAtTime(endFreq,t+dur);

  gain.gain.setValueAtTime(vol,t);
  gain.gain.exponentialRampToValueAtTime(.001,t+dur);

  osc.connect(gain);
  gain.connect(ac.destination);
  osc.start(t);
  osc.stop(t+dur+.03);
}

const sfxShot=p=>{
  noise(.12,.24,p);
  noise(.035,.11,5200,'highpass');
};
const sfxHit=()=>tone(900,300,.07,.12,'square');
const sfxDie=()=>tone(220,55,.4,.18,'sawtooth');
const sfxDry=()=>tone(1800,700,.04,.08,'square');

const sfxMagOut=()=>{
  noise(.06,.13,900);
  tone(160,70,.05,.08,'triangle');
};
const sfxMagIn=()=>{
  noise(.055,.16,750);
  tone(85,130,.05,.12,'triangle');
};
const sfxBoltPull=()=>{
  noise(.055,.20,2800,'highpass');
  tone(430,180,.045,.12,'square');
};
const sfxBoltPush=()=>{
  noise(.04,.22,3400,'highpass');
  tone(250,520,.035,.11,'square');
};

/* ================= THREE.JS ================= */

const scene=new THREE.Scene();
scene.background=new THREE.Color(0x0b0f16);
scene.fog=new THREE.Fog(0x0b0f16,45,125);

const camera=new THREE.PerspectiveCamera(75,innerWidth/innerHeight,.08,400);
camera.rotation.order='YXZ';
scene.add(camera);

const renderer=new THREE.WebGLRenderer({
  antialias:!('ontouchstart'in window),
  powerPreference:'high-performance'
});
renderer.shadowMap.enabled=true;
renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.domElement.style.cssText='position:absolute;inset:0;z-index:1';
container.insertBefore(renderer.domElement,container.firstChild);

const hemi=new THREE.HemisphereLight(0xaec7ff,0x3a2c1c,.68);
scene.add(hemi);

const sun=new THREE.DirectionalLight(0xffe3ae,1.2);
sun.position.set(35,55,25);
sun.castShadow=true;
sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left=-45;
sun.shadow.camera.right=45;
sun.shadow.camera.top=45;
sun.shadow.camera.bottom=-45;
sun.shadow.camera.far=140;
sun.shadow.camera.updateProjectionMatrix();
scene.add(sun);

const muzzleLight=new THREE.PointLight(0xffb347,0,9);
muzzleLight.position.set(.16,-.12,-1);
camera.add(muzzleLight);

/* ================= КАРТЫ ================= */

const WORLD=30;
let mapGroup=null;
const colliders=[];
const wallMeshes=[];

function clearMap(){
  if(mapGroup)scene.remove(mapGroup);
  mapGroup=new THREE.Group();
  scene.add(mapGroup);
  colliders.length=0;
  wallMeshes.length=0;
}

function addBox(x,z,w,h,d,color,opts){
  opts=opts||{};

  const mesh=new THREE.Mesh(
    new THREE.BoxGeometry(w,h,d),
    new THREE.MeshStandardMaterial({
      color:color,
      roughness:opts.rough!=null?opts.rough:.88,
      metalness:.05
    })
  );

  mesh.position.set(x,opts.y!=null?opts.y:h/2,z);
  mesh.castShadow=true;
  mesh.receiveShadow=true;
  mapGroup.add(mesh);

  colliders.push({
    minX:x-w/2,
    maxX:x+w/2,
    minZ:z-d/2,
    maxZ:z+d/2
  });
  wallMeshes.push(mesh);

  return mesh;
}

function loadMap(name){
  clearMap();

  if(name==='dust2'){
    scene.background.set(0xc59a62);
    scene.fog.color.set(0xc59a62);
    scene.fog.near=55;
    scene.fog.far=145;
    sun.color.set(0xffdfae);

    const sand=new THREE.Mesh(
      new THREE.PlaneGeometry(64,64),
      new THREE.MeshStandardMaterial({color:0xb9874f,roughness:1})
    );
    sand.rotation.x=-Math.PI/2;
    sand.receiveShadow=true;
    mapGroup.add(sand);

    addBox(0,-30.5,62,4,1,0xa97843);
    addBox(0,30.5,62,4,1,0xa97843);
    addBox(-30.5,0,1,4,62,0xa97843);
    addBox(30.5,0,1,4,62,0xa97843);

    addBox(0,0,14,4.2,1.2,0xc39a65);
    addBox(0,-9,4,3.8,7,0xcaa374);
    addBox(0,9,4,3.8,7,0xcaa374);

    addBox(-16,-12,8,2.3,1.3,0xbd8e58);
    addBox(16,-12,8,2.3,1.3,0xbd8e58);
    addBox(-12,13,9,2.4,1.4,0xbd8e58);
    addBox(12,13,9,2.4,1.4,0xbd8e58);

    addBox(-22,2,2,5.5,12,0x9e7142);
    addBox(22,-2,2,5.5,12,0x9e7142);
    addBox(-7,-21,5,3,3,0xa77a49);
    addBox(7,21,5,3,3,0xa77a49);

    addBox(-18,18,2,1.6,2,0x8f653d);
    addBox(18,-18,2,1.6,2,0x8f653d);
    addBox(-5,18,2.2,1.5,2.2,0x8f653d);
    addBox(5,-18,2.2,1.5,2.2,0x8f653d);
  }else{
    selectedMap='sandstone';

    scene.background.set(0xd1ad78);
    scene.fog.color.set(0xd1ad78);
    scene.fog.near=50;
    scene.fog.far=135;
    sun.color.set(0xffedc8);

    const ground=new THREE.Mesh(
      new THREE.PlaneGeometry(64,64),
      new THREE.MeshStandardMaterial({color:0xc79c63,roughness:1})
    );
    ground.rotation.x=-Math.PI/2;
    ground.receiveShadow=true;
    mapGroup.add(ground);

    addBox(0,-30.5,62,4,1,0xb48655);
    addBox(0,30.5,62,4,1,0xb48655);
    addBox(-30.5,0,1,4,62,0xb48655);
    addBox(30.5,0,1,4,62,0xb48655);

    addBox(0,0,10,2.7,1.2,0xb98d58);
    addBox(-12,-10,2,2.2,2,0x8f653d);
    addBox(-9.2,-10.5,1.6,1.4,1.6,0xa57948);
    addBox(12,-12,2,2.2,2,0x8f653d);
    addBox(9,12,2.4,2.2,2.4,0x8f653d);
    addBox(-11,11,2,2.2,2,0x8f653d);

    addBox(0,-18,6,2.4,1,0xa98a62);
    addBox(0,18,6,2.4,1,0xa98a62);
    addBox(-20,0,1,2.6,8,0xb58d61);
    addBox(20,2,1,2.6,8,0xb58d61);

    addBox(16,-4,3,1.6,3,0x996b3e);
    addBox(-16,5,3,1.6,3,0x996b3e);
    addBox(23,-18,2,4,8,0xb18452);
    addBox(-23,18,2,4,8,0xb18452);
  }
}

loadMap(selectedMap);

/* ================= ИГРОК ================= */

const player={
  pos:new THREE.Vector3(0,0,24),
  vel:new THREE.Vector3(),
  yaw:0,
  pitch:0,
  hp:100,
  armor:100,
  crouch:false,
  onGround:true,
  alive:true,
  eyeH:1.7,
  name:'Вы'
};

const WEAPONS={
  1:{name:'AK-47',dmg:34,rpm:600,mag:30,reserve:90,auto:true,reloadTime:2100,aimFov:55,spread:.014,recoil:.014,scoped:false,snd:1800},
  2:{name:'M4A1',dmg:31,rpm:680,mag:30,reserve:90,auto:true,reloadTime:2000,aimFov:55,spread:.011,recoil:.011,scoped:false,snd:2200},
  3:{name:'AWP',dmg:115,rpm:45,mag:5,reserve:15,auto:false,reloadTime:3200,aimFov:20,spread:.0015,recoil:.05,scoped:true,snd:900},
  4:{name:'GLOCK',dmg:25,rpm:380,mag:20,reserve:120,auto:false,reloadTime:1500,aimFov:62,spread:.016,recoil:.009,scoped:false,snd:2600}
};

const wstate={};
for(const key in WEAPONS){
  wstate[key]={ammo:WEAPONS[key].mag,reserve:WEAPONS[key].reserve};
}

let savedWeapon=parseInt(localStorage.getItem('standoff3d_weapon_v2')||'1',10);
let curWeapon=savedWeapon>=1&&savedWeapon<=4?savedWeapon:1;

let lastShot=0;
let reloading=false;
let reloadStart=0;
let reloadApplied=false;
let reloadSounds=0;

let aiming=false;
let fireHeld=false;
let bloom=0;
let sensitivity=1;

let boltT=-1;
let boltStage=0;
let switchT=1;
let walkT=0;

/* ================= ДЕТАЛИЗИРОВАННОЕ ОРУЖИЕ ================= */

const gunGroup=new THREE.Group();
camera.add(gunGroup);
const gunParts={};

function makeMat(color,metal,rough){
  return new THREE.MeshStandardMaterial({
    color:color,
    metalness:metal,
    roughness:rough
  });
}

function addPart(geo,material,x,y,z,name){
  const mesh=new THREE.Mesh(geo,material);
  mesh.position.set(x,y,z);
  mesh.castShadow=true;
  gunGroup.add(mesh);
  if(name)gunParts[name]=mesh;
  return mesh;
}

function buildGun(slot){
  while(gunGroup.children.length){
    gunGroup.remove(gunGroup.children[0]);
  }

  for(const key in gunParts)delete gunParts[key];

  const dark=makeMat(0x171c24,.55,.42);
  const black=makeMat(0x080a0e,.6,.35);
  const wood=makeMat(0x7a431f,.1,.68);
  const polymer=makeMat(0x252c36,.25,.58);
  const accent=makeMat(0xff8c00,.15,.35);

  if(slot===3){
    /* AWP */
    addPart(new THREE.BoxGeometry(.075,.105,.82),dark,0,0,-.53,'body');
    addPart(new THREE.CylinderGeometry(.021,.021,.78,12),black,0,.014,-1.1).rotation.x=Math.PI/2;
    addPart(new THREE.CylinderGeometry(.029,.029,.12,12),black,0,.014,-1.49).rotation.x=Math.PI/2;

    addPart(new THREE.BoxGeometry(.068,.09,.34),wood,0,-.018,-.08,'stock');
    addPart(new THREE.BoxGeometry(.018,.11,.34),wood,-.036,-.09,-.09);
    addPart(new THREE.BoxGeometry(.018,.11,.34),wood,.036,-.09,-.09);

    addPart(new THREE.BoxGeometry(.05,.1,.12),polymer,0,-.115,-.42,'mag');
    addPart(new THREE.BoxGeometry(.04,.04,.09),dark,0,-.02,-.52);

    const scope=addPart(
      new THREE.CylinderGeometry(.043,.043,.34,16),
      black,
      0,.105,-.54,
      'scope'
    );
    scope.rotation.x=Math.PI/2;

    addPart(new THREE.CylinderGeometry(.052,.052,.055,16),black,0,.105,-.72).rotation.x=Math.PI/2;

    addPart(new THREE.BoxGeometry(.025,.07,.025),dark,-.035,.055,-.32);
    addPart(new THREE.BoxGeometry(.025,.07,.025),dark,.035,.055,-.32);
    addPart(new THREE.BoxGeometry(.12,.025,.09),dark,0,.065,-.32);
    addPart(new THREE.BoxGeometry(.025,.025,.025),accent,0,.075,-.32);

    const bolt=addPart(
      new THREE.CylinderGeometry(.012,.012,.16,10),
      black,
      .062,.045,-.43,
      'bolt'
    );
    bolt.rotation.z=Math.PI/2;
  }
  else if(slot===4){
    /* GLOCK */
    addPart(new THREE.BoxGeometry(.065,.095,.34),dark,0,0,-.24,'slide');
    addPart(new THREE.BoxGeometry(.058,.14,.085),polymer,0,-.1,-.12,'frame');
    addPart(new THREE.BoxGeometry(.055,.125,.065),black,0,-.095,-.22,'mag');
    addPart(new THREE.BoxGeometry(.015,.025,.025),accent,0,.06,-.38);
    addPart(new THREE.BoxGeometry(.014,.035,.09),dark,0,.065,-.27);
    addPart(new THREE.BoxGeometry(.014,.028,.055),dark,0,.061,-.12);
  }
  else{
    /* AK-47 / M4A1 */
    const isAK=slot===1;
    const stockMat=isAK?wood:polymer;

    addPart(new THREE.BoxGeometry(.075,.105,.68),dark,0,0,-.43,'body');
    addPart(new THREE.CylinderGeometry(.019,.019,.43,12),black,0,.018,-.91).rotation.x=Math.PI/2;
    addPart(new THREE.CylinderGeometry(.026,.026,.09,12),black,0,.018,-1.15).rotation.x=Math.PI/2;

    addPart(new THREE.BoxGeometry(.074,.09,.23),stockMat,0,-.008,-.045,'stock');
    addPart(new THREE.BoxGeometry(.025,.12,.25),stockMat,-.041,-.065,-.05);
    addPart(new THREE.BoxGeometry(.025,.12,.25),stockMat,.041,-.065,-.05);

    addPart(new THREE.BoxGeometry(.054,.17,.092),dark,0,-.13,-.27,'mag');
    addPart(new THREE.BoxGeometry(.06,.035,.08),dark,0,-.064,-.29);

    addPart(new THREE.BoxGeometry(.018,.065,.035),dark,0,-.095,-.15);
    addPart(new THREE.BoxGeometry(.05,.012,.07),dark,0,-.06,-.15);

    addPart(new THREE.BoxGeometry(.022,.036,.12),accent,0,.078,-.62);
    addPart(new THREE.BoxGeometry(.055,.018,.06),dark,0,.09,-.27);
    addPart(new THREE.BoxGeometry(.018,.035,.018),dark,-.028,.078,-.27);
    addPart(new THREE.BoxGeometry(.018,.035,.018),dark,.028,.078,-.27);

    if(!isAK){
      addPart(new THREE.BoxGeometry(.048,.018,.36),black,0,.072,-.62);
    }
  }

  gunGroup.position.set(.26,-.23,-.39);
  gunGroup.rotation.set(0,0,0);
  gunGroup.visible=true;
}

buildGun(curWeapon);

/* ================= БОТЫ ================= */

const ALLY_NAMES=['Alex','Bravo','Cobra','Delta'];
const ENEMY_NAMES=['Viper','Wolf','Ghost','Hawk','Rex'];

const TEAMS={
  ally:{body:0x2f6df0,head:0xd9a066,tag:'#38bdf8'},
  enemy:{body:0xb3401e,head:0xd9a066,tag:'#f87171'}
};

const SPAWNS={
  ally:[[-6,26],[-2,27],[2,27],[6,26]],
  enemy:[[-6,-26],[-2,-27],[2,-27],[6,-26],[8,-25]]
};

const bots=[];
let botIdSeq=0;
let scoreCT=0;
let scoreTR=0;
let matchOver=false;

function pointInCollider(x,z,r){
  return colliders.some(c=>
    x>c.minX-r&&
    x<c.maxX+r&&
    z>c.minZ-r&&
    z<c.maxZ+r
  );
}

function makeTag(name,color){
  const canvas=document.createElement('canvas');
  canvas.width=128;
  canvas.height=48;

  const context=canvas.getContext('2d');
  context.font='bold 22px sans-serif';
  context.textAlign='center';
  context.lineWidth=4;
  context.strokeStyle='rgba(0,0,0,.85)';
  context.strokeText(name,64,22);
  context.fillStyle=color;
  context.fillText(name,64,22);
  context.beginPath();
  context.moveTo(54,30);
  context.lineTo(74,30);
  context.lineTo(64,44);
  context.closePath();
  context.fill();

  const sprite=new THREE.Sprite(
    new THREE.SpriteMaterial({
      map:new THREE.CanvasTexture(canvas),
      depthTest:false,
      transparent:true
    })
  );

  sprite.scale.set(1.3,.49,1);
  sprite.position.y=2.35;
  return sprite;
}

function spawnBot(team,name){
  const id=++botIdSeq;
  const teamInfo=TEAMS[team];
  const group=new THREE.Group();

  const body=new THREE.Mesh(
    new THREE.CylinderGeometry(.34,.42,1.05,10),
    new THREE.MeshStandardMaterial({color:teamInfo.body,roughness:.7})
  );
  body.position.y=.85;
  body.castShadow=true;
  body.userData={part:'body'};

  const head=new THREE.Mesh(
    new THREE.SphereGeometry(.23,12,10),
    new THREE.MeshStandardMaterial({color:teamInfo.head})
  );
  head.position.y=1.62;
  head.castShadow=true;
  head.userData={part:'head'};

  const visor=new THREE.Mesh(
    new THREE.BoxGeometry(.3,.08,.1),
    makeMat(0x11151c,.5,.4)
  );
  visor.position.set(0,1.64,.16);

  const botGun=new THREE.Mesh(
    new THREE.BoxGeometry(.07,.08,.55),
    makeMat(0x151a22,.5,.5)
  );
  botGun.position.set(.3,1.05,.3);

  group.add(body,head,visor,botGun);

  if(team==='ally')group.add(makeTag(name,teamInfo.tag));

  scene.add(group);

  const bot={
    id:id,
    name:name,
    team:team,
    grp:group,
    body:body,
    head:head,
    hp:100,
    dead:false,
    respawnT:0,
    target:new THREE.Vector3(),
    fireCd:1+Math.random(),
    strafe:Math.random()<.5?1:-1,
    strafeT:0,
    checkT:Math.random()*.4,
    enemy:null,
    enemyDist:99,
    slot:id%6
  };

  body.userData.bot=bot;
  head.userData.bot=bot;

  bots.push(bot);
  respawnBot(bot);
}

function respawnBot(bot){
  const list=SPAWNS[bot.team];
  const spawn=list[Math.floor(Math.random()*list.length)];

  bot.grp.position.set(
    spawn[0]+(Math.random()-.5),
    0,
    spawn[1]
  );

  bot.grp.rotation.y=bot.team==='ally'?Math.PI:0;
  bot.hp=100;
  bot.dead=false;
  bot.enemy=null;
  bot.grp.visible=true;
}

function createTeams(){
  bots.forEach(bot=>scene.remove(bot.grp));
  bots.length=0;

  ALLY_NAMES.forEach(name=>spawnBot('ally',name));
  ENEMY_NAMES.forEach(name=>spawnBot('enemy',name));
}

function countAlive(team){
  let count=0;
  for(const bot of bots){
    if(bot.team===team&&!bot.dead)count++;
  }
  return count;
}

function enemyMeshes(){
  const result=[];
  for(const bot of bots){
    if(bot.team==='enemy'&&!bot.dead){
      result.push(bot.body,bot.head);
    }
  }
  return result;
}

function startMatch(){
  createTeams();
  resetMatch();
  showBanner(
    selectedMap==='dust2'?'DUST 2':'SANDSTONE',
    1800
  );
}

/* ================= HUD / СЧЁТ ================= */

const raycaster=new THREE.Raycaster();
raycaster.far=300;

const tracers=[];

function spawnTracer(from,to,color){
  const line=new THREE.Line(
    new THREE.BufferGeometry().setFromPoints([from,to]),
    new THREE.LineBasicMaterial({
      color:color||0xffd27a,
      transparent:true,
      opacity:.9
    })
  );
  scene.add(line);
  tracers.push({line:line,life:.07});
}

function updateAmmoHUD(){
  const state=wstate[curWeapon];
  ammoCur.textContent=state.ammo;
  ammoMax.textContent=state.reserve;
  ammoCur.style.color=state.ammo===0?'#ff3b3b':(state.ammo<=5?'#ff8c00':'#fff');
}

function flashHitmarker(){
  hitmarkerEl.style.opacity='1';
  clearTimeout(flashHitmarker._timer);
  flashHitmarker._timer=setTimeout(()=>{
    hitmarkerEl.style.opacity='0';
  },70);
}

function showBanner(html,time){
  let element=$('team-banner');

  if(!element){
    element=document.createElement('div');
    element.id='team-banner';
    element.style.cssText=`
      position:absolute;
      left:50%;
      top:30%;
      transform:translate(-50%,-50%);
      z-index:60;
      pointer-events:none;
      text-align:center;
      font:900 34px sans-serif;
      letter-spacing:.12em;
      color:#fff;
      text-shadow:0 2px 12px #000;
      display:none`;
    container.appendChild(element);
  }

  element.innerHTML=html;
  element.style.display='block';

  clearTimeout(showBanner._timer);
  showBanner._timer=setTimeout(()=>{
    element.style.display='none';
  },time||2500);
}

function addKillFeed(a,b,playerIsKiller,headshot,aTeam,bTeam){
  const color=team=>team==='ally'?'text-cyan-300':'text-amber-400';

  const item=document.createElement('div');
  item.className='kill-item so2-panel px-2 py-0.5 rounded text-[10px] font-sans';

  item.innerHTML=
    '<span class="'+color(aTeam||'ally')+'">'+a+'</span>'+
    ' <i class="fa-solid '+(headshot?'fa-crosshairs':'fa-skull')+' text-slate-400 mx-1"></i> '+
    '<span class="'+color(bTeam||'enemy')+'">'+b+'</span>';

  killFeedEl.prepend(item);

  while(killFeedEl.children.length>5){
    killFeedEl.lastChild.remove();
  }

  setTimeout(()=>{
    if(item.parentNode)item.remove();
  },4500);
}

function addScore(team){
  if(team==='ally'){
    scoreCT++;
    scoreCtEl.textContent=scoreCT;
  }else{
    scoreTR++;
    scoreTrEl.textContent=scoreTR;
  }

  if(!matchOver&&(scoreCT>=30||scoreTR>=30)){
    matchOver=true;
    showBanner(
      scoreCT>=30
        ?'<span style="color:#4ade80">ПОБЕДА</span>'
        :'<span style="color:#f87171">ПОРАЖЕНИЕ</span>',
      4500
    );
    setTimeout(resetMatch,5000);
  }
}

function resetMatch(){
  scoreCT=0;
  scoreTR=0;
  scoreCtEl.textContent=0;
  scoreTrEl.textContent=0;

  bots.forEach(respawnBot);
  respawnPlayer();
  matchOver=false;
}

function killBot(bot,attacker,headshot){
  bot.dead=true;
  bot.grp.visible=false;
  bot.respawnT=4+Math.random()*2;

  const attackerTeam=attacker===player?'ally':attacker.team;
  addScore(attackerTeam);
  addKillFeed(
    attacker.name,
    bot.name,
    attacker===player,
    headshot,
    attackerTeam,
    bot.team
  );

  if(attacker===player)sfxDie();
}

function damageBot(bot,damage,part,attacker){
  if(bot.dead)return;

  bot.hp-=damage;

  if(attacker===player){
    flashHitmarker();
    sfxHit();
  }

  if(bot.hp<=0){
    killBot(bot,attacker,part==='head');
  }
}

function applyDamage(damage,attacker){
  if(!player.alive)return;

  const absorbed=Math.min(player.armor,damage*.55);
  player.armor=Math.max(0,player.armor-absorbed);
  player.hp=Math.max(0,player.hp-(damage-absorbed));

  hpVal.textContent=Math.ceil(player.hp);
  armorVal.textContent=Math.ceil(player.armor);

  vignette.style.boxShadow='inset 0 0 120px rgba(255,0,0,.65)';

  clearTimeout(applyDamage._timer);
  applyDamage._timer=setTimeout(()=>{
    vignette.style.boxShadow='inset 0 0 100px rgba(255,0,0,0)';
  },130);

  if(player.hp<=0)playerDie(attacker);
}

function respawnPlayer(){
  const spawn=SPAWNS.ally[Math.floor(Math.random()*SPAWNS.ally.length)];

  player.pos.set(spawn[0],0,spawn[1]);
  player.vel.set(0,0,0);
  player.yaw=0;
  player.pitch=0;
  player.hp=100;
  player.armor=100;
  player.alive=true;

  for(const key in WEAPONS){
    wstate[key].ammo=WEAPONS[key].mag;
    wstate[key].reserve=WEAPONS[key].reserve;
  }

  reloading=false;
  boltT=-1;

  hpVal.textContent=100;
  armorVal.textContent=100;
  bloom=0;

  updateAmmoHUD();
  $('death-overlay').style.display='none';
}

function playerDie(attacker){
  player.alive=false;
  addScore('enemy');
  addKillFeed(
    attacker?attacker.name:'?',
    'Вы',
    false,
    false,
    'enemy',
    'ally'
  );

  $('death-overlay').style.display='flex';

  setTimeout(()=>{
    if(!player.alive)respawnPlayer();
  },3000);
}

/* ================= ПЕРЕЗАРЯДКА ================= */

function startReload(){
  const weapon=WEAPONS[curWeapon];
  const state=wstate[curWeapon];

  if(reloading||state.ammo===weapon.mag||state.reserve<=0)return;

  reloading=true;
  reloadStart=performance.now();
  reloadApplied=false;
  reloadSounds=0;

  $('btn-reload').classList.add('active');
}

function applyReloadAmmo(){
  if(reloadApplied)return;

  const weapon=WEAPONS[curWeapon];
  const state=wstate[curWeapon];

  const need=weapon.mag-state.ammo;
  const take=Math.min(need,state.reserve);

  state.ammo+=take;
  state.reserve-=take;
  reloadApplied=true;

  updateAmmoHUD();
}

function updateReload(now){
  if(!reloading)return;

  const weapon=WEAPONS[curWeapon];
  const progress=Math.min(1,(now-reloadStart)/weapon.reloadTime);

  const soundMarks=[
    [.18,sfxMagOut],
    [.56,sfxMagIn],
    [.78,curWeapon===3?sfxBoltPull:sfxBoltPush]
  ];

  for(let i=reloadSounds;i<soundMarks.length;i++){
    if(progress>=soundMarks[i][0]){
      soundMarks[i][1]();
      reloadSounds=i+1;
    }
  }

  if(progress>=.68){
    applyReloadAmmo();
  }

  if(progress>=1){
    reloading=false;
    $('btn-reload').classList.remove('active');
  }
}

/* ================= ВЫСТРЕЛ ================= */

function tryFire(now){
  if(!player.alive||reloading)return;

  const weapon=WEAPONS[curWeapon];
  const state=wstate[curWeapon];

  if(now-lastShot<60000/weapon.rpm)return;

  if(state.ammo<=0){
    sfxDry();
    startReload();
    return;
  }

  lastShot=now;
  state.ammo--;
  updateAmmoHUD();
  sfxShot(weapon.snd);

  const moveFactor=Math.min(1,player.vel.length()/5);
  const spread=(weapon.spread+bloom*.02+moveFactor*.02)*(aiming?.45:1);

  const direction=new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
  direction.x+=(Math.random()*2-1)*spread;
  direction.y+=(Math.random()*2-1)*spread;
  direction.z+=(Math.random()*2-1)*spread;
  direction.normalize();

  raycaster.set(camera.position.clone(),direction);

  const botHits=raycaster.intersectObjects(enemyMeshes(),false);
  const wallHits=raycaster.intersectObjects(wallMeshes,false);
  const wallDistance=wallHits.length?wallHits[0].distance:Infinity;

  let endPoint=camera.position.clone().add(
    direction.clone().multiplyScalar(80)
  );

  if(botHits.length&&botHits[0].distance<wallDistance){
    endPoint=botHits[0].point;

    const part=botHits[0].object.userData.part;
    const bot=botHits[0].object.userData.bot;

    damageBot(
      bot,
      weapon.dmg*(part==='head'?2:1),
      part,
      player
    );
  }else if(wallHits.length){
    endPoint=wallHits[0].point;
  }

  const tracerStart=camera.position.clone().add(
    new THREE.Vector3(.22,-.2,-.6).applyQuaternion(camera.quaternion)
  );

  spawnTracer(tracerStart,endPoint);

  muzzleLight.intensity=2.4;
  player.pitch+=weapon.recoil*(aiming?.6:1);
  player.yaw+=(Math.random()*2-1)*weapon.recoil*.4;
  bloom=Math.min(1,bloom+(curWeapon===3?.6:.25));
  gunGroup.position.z=-.27;

  /* После выстрела из AWP запускаем щелчок затвора */
  if(curWeapon===3){
    boltT=now;
    boltStage=0;
  }
}

/* ================= СМЕНА ОРУЖИЯ ================= */

window.switchWeapon=function(slot){
  if(slot===curWeapon)return;

  curWeapon=slot;
  localStorage.setItem('standoff3d_weapon_v2',slot);

  reloading=false;
  reloadApplied=false;
  boltT=-1;
  aiming=false;
  switchT=0;

  for(let i=1;i<=4;i++){
    const button=$('wslot-'+i);
    const active=i===slot;

    button.classList.toggle('bg-white/20',active);
    button.classList.toggle('border-orange-500',active);
    button.classList.toggle('bg-black/40',!active);
    button.classList.toggle('border-white/10',!active);
    button.classList.toggle('opacity-60',!active);
  }

  buildGun(slot);
  updateAmmoHUD();
};

/* ================= КЛАВИАТУРА / МЫШЬ ================= */

const keys={};

addEventListener('keydown',event=>{
  keys[event.code]=true;

  if(event.code==='KeyR')startReload();
  if(event.code==='KeyC')toggleCrouch();
  if(event.code==='Digit1')switchWeapon(1);
  if(event.code==='Digit2')switchWeapon(2);
  if(event.code==='Digit3')switchWeapon(3);
  if(event.code==='Digit4')switchWeapon(4);
});

addEventListener('keyup',event=>{
  keys[event.code]=false;
});

const canvas=renderer.domElement;

canvas.addEventListener('click',()=>{
  audio();

  if(!('ontouchstart'in window)&&document.pointerLockElement!==canvas){
    canvas.requestPointerLock&&canvas.requestPointerLock();
  }
});

addEventListener('mousemove',event=>{
  if(document.pointerLockElement===canvas){
    const sens=.0022*sensitivity*(aiming?(WEAPONS[curWeapon].scoped?.35:.6):1);
    player.yaw-=event.movementX*sens;
    player.pitch-=event.movementY*sens;
    player.pitch=Math.max(-1.45,Math.min(1.45,player.pitch));
  }
});

addEventListener('mousedown',event=>{
  audio();

  if(document.pointerLockElement!==canvas)return;

  if(event.button===0){
    fireHeld=true;
    tryFire(performance.now());
  }

  if(event.button===2){
    aiming=true;
  }
});

addEventListener('mouseup',event=>{
  if(event.button===0)fireHeld=false;
  if(event.button===2)aiming=false;
});

addEventListener('contextmenu',event=>event.preventDefault());

function toggleCrouch(){
  player.crouch=!player.crouch;
  $('btn-crouch').classList.toggle('active',player.crouch);
}

/* ================= ТАЧ-УПРАВЛЕНИЕ ================= */

const joy={x:0,y:0,id:null};
const joyEl=$('joystick-container');
const stickEl=$('joystick-stick');
const JOY_RADIUS=46;

joyEl.addEventListener('pointerdown',event=>{
  joy.id=event.pointerId;
  joyEl.setPointerCapture(event.pointerId);
});

joyEl.addEventListener('pointermove',event=>{
  if(event.pointerId!==joy.id)return;

  const rect=joyEl.getBoundingClientRect();
  let dx=event.clientX-(rect.left+rect.width/2);
  let dy=event.clientY-(rect.top+rect.height/2);

  const length=Math.hypot(dx,dy);
  if(length>JOY_RADIUS){
    dx=dx/length*JOY_RADIUS;
    dy=dy/length*JOY_RADIUS;
  }

  stickEl.style.transform=
    'translate(calc(-50% + '+dx+'px), calc(-50% + '+dy+'px))';

  joy.x=dx/JOY_RADIUS;
  joy.y=dy/JOY_RADIUS;
});

function joystickEnd(event){
  if(event.pointerId!==joy.id)return;

  joy.id=null;
  joy.x=0;
  joy.y=0;
  stickEl.style.transform='translate(-50%,-50%)';
}

joyEl.addEventListener('pointerup',joystickEnd);
joyEl.addEventListener('pointercancel',joystickEnd);

const cameraArea=$('touch-camera-area');
let lookId=null;
let lookX=0;
let lookY=0;

function applyLook(dx,dy){
  const sens=.0042*sensitivity*(aiming?(WEAPONS[curWeapon].scoped?.35:.6):1);
  player.yaw-=dx*sens;
  player.pitch-=dy*sens;
  player.pitch=Math.max(-1.45,Math.min(1.45,player.pitch));
}

cameraArea.addEventListener('pointerdown',event=>{
  audio();
  if(lookId!==null)return;

  lookId=event.pointerId;
  lookX=event.clientX;
  lookY=event.clientY;
  cameraArea.setPointerCapture(event.pointerId);
});

cameraArea.addEventListener('pointermove',event=>{
  if(event.pointerId!==lookId)return;

  applyLook(event.clientX-lookX,event.clientY-lookY);
  lookX=event.clientX;
  lookY=event.clientY;
});

function lookEnd(event){
  if(event.pointerId===lookId)lookId=null;
}

cameraArea.addEventListener('pointerup',lookEnd);
cameraArea.addEventListener('pointercancel',lookEnd);

function bindHold(element,down,up){
  let pointerId=null;

  element.addEventListener('pointerdown',event=>{
    event.preventDefault();
    audio();

    pointerId=event.pointerId;
    element.setPointerCapture(event.pointerId);
    down();
  });

  const end=event=>{
    if(event.pointerId!==pointerId)return;
    pointerId=null;
    if(up)up();
  };

  ['pointerup','pointercancel','lostpointercapture'].forEach(type=>{
    element.addEventListener(type,end);
  });
}

bindHold(
  $('btn-fire'),
  ()=>{
    fireHeld=true;
    tryFire(performance.now());
  },
  ()=>{
    fireHeld=false;
  }
);

bindHold(
  $('btn-jump'),
  ()=>keys['Space']=true,
  ()=>keys['Space']=false
);

$('btn-aim').addEventListener('pointerdown',event=>{
  event.preventDefault();
  aiming=!aiming;
  $('btn-aim').classList.toggle('active',aiming);
});

$('btn-crouch').addEventListener('pointerdown',event=>{
  event.preventDefault();
  toggleCrouch();
});

$('btn-reload').addEventListener('pointerdown',event=>{
  event.preventDefault();
  startReload();
});

/* ================= НАСТРОЙКИ ГРАФИКИ ================= */

let fpsCap=60;

const renderScaleInput=$('setting-render-scale');
const shadowSelect=$('setting-shadows');
const fpsSelect=$('setting-fps-cap');
const sensitivityInput=$('setting-sens');
const autoQualityCheckbox=$('setting-auto');

function applyGraphics(){
  const scale=parseFloat(renderScaleInput.value);

  renderer.setPixelRatio(Math.min(devicePixelRatio||1,2)*scale);
  renderer.setSize(innerWidth,innerHeight);

  $('render-scale-val').textContent=scale.toFixed(2)+'x';

  const shadows=shadowSelect.value;
  const shadowsEnabled=shadows!=='off';

  renderer.shadowMap.enabled=shadowsEnabled;
  sun.castShadow=shadowsEnabled;

  if(shadowsEnabled){
    const size=shadows==='low'?1024:shadows==='high'?2048:4096;
    sun.shadow.mapSize.set(size,size);

    if(sun.shadow.map){
      sun.shadow.map.dispose();
      sun.shadow.map=null;
    }
  }

  fpsCap=parseInt(fpsSelect.value,10);
  sensitivity=parseFloat(sensitivityInput.value);
  $('sens-val').textContent=sensitivity.toFixed(1);
}

[
  renderScaleInput,
  shadowSelect,
  fpsSelect
].forEach(element=>{
  element.addEventListener('change',applyGraphics);
});

sensitivityInput.addEventListener('input',applyGraphics);
autoQualityCheckbox.addEventListener('change',applyGraphics);

window.setGraphicPreset=function(preset){
  const presets={
    low:{rs:.5,sh:'off',fps:'30'},
    medium:{rs:.75,sh:'low',fps:'60'},
    high:{rs:1,sh:'high',fps:'60'},
    ultra:{rs:1.25,sh:'ultra',fps:'120'}
  };

  const value=presets[preset];
  if(!value)return;

  renderScaleInput.value=value.rs;
  shadowSelect.value=value.sh;
  fpsSelect.value=value.fps;

  applyGraphics();
};

$('btn-graphics').addEventListener('click',()=>{
  $('graphics-modal').classList.remove('hidden');
});

$('close-graphics-btn').addEventListener('click',()=>{
  $('graphics-modal').classList.add('hidden');
});

$('btn-fullscreen').addEventListener('click',()=>{
  if(document.fullscreenElement){
    document.exitFullscreen();
  }else if(wrapper.requestFullscreen){
    wrapper.requestFullscreen();
  }
});

/* Скрываем верхний FPS-блок, чтобы он не занимал место на экране */
const telemetryPanel=fpsVal.closest('.so2-panel');
if(telemetryPanel){
  telemetryPanel.style.display='none';
}

/* ================= КОЛЛИЗИИ ================= */

function resolveCollisions(position,radius){
  for(const collider of colliders){
    const closestX=Math.max(collider.minX,Math.min(position.x,collider.maxX));
    const closestZ=Math.max(collider.minZ,Math.min(position.z,collider.maxZ));

    const dx=position.x-closestX;
    const dz=position.z-closestZ;
    const distanceSquared=dx*dx+dz*dz;

    if(distanceSquared<radius*radius){
      if(distanceSquared>1e-6){
        const distance=Math.sqrt(distanceSquared);
        const push=radius-distance;
        position.x+=dx/distance*push;
        position.z+=dz/distance*push;
      }else{
        const pushX=Math.min(
          position.x-collider.minX+radius,
          collider.maxX+radius-position.x
        );
        const pushZ=Math.min(
          position.z-collider.minZ+radius,
          collider.maxZ+radius-position.z
        );

        if(pushX<pushZ){
          position.x=
            position.x-collider.minX<collider.maxX-position.x
              ?collider.minX-radius
              :collider.maxX+radius;
        }else{
          position.z=
            position.z-collider.minZ<collider.maxZ-position.z
              ?collider.minZ-radius
              :collider.maxZ+radius;
        }
      }
    }
  }

  position.x=Math.max(-WORLD+1,Math.min(WORLD-1,position.x));
  position.z=Math.max(-WORLD+1,Math.min(WORLD-1,position.z));
}

/* ================= МИНИКАРТА ================= */

function drawMinimap(){
  const size=minimap.width;
  const scale=size/(WORLD*2);

  mmCtx.clearRect(0,0,size,size);
  mmCtx.fillStyle='rgba(10,14,20,.92)';
  mmCtx.beginPath();
  mmCtx.arc(size/2,size/2,size/2,0,Math.PI*2);
  mmCtx.fill();

  mmCtx.fillStyle='rgba(185,142,88,.85)';

  for(const collider of colliders){
    mmCtx.fillRect(
      (collider.minX+WORLD)*scale,
      (collider.minZ+WORLD)*scale,
      (collider.maxX-collider.minX)*scale,
      (collider.maxZ-collider.minZ)*scale
    );
  }

  for(const bot of bots){
    if(bot.dead)continue;

    mmCtx.fillStyle=bot.team==='ally'?'#38bdf8':'#ff5544';
    mmCtx.beginPath();
    mmCtx.arc(
      (bot.grp.position.x+WORLD)*scale,
      (bot.grp.position.z+WORLD)*scale,
      bot.team==='ally'?2.2:1.8,
      0,
      Math.PI*2
    );
    mmCtx.fill();
  }

  const playerX=(player.pos.x+WORLD)*scale;
  const playerZ=(player.pos.z+WORLD)*scale;

  mmCtx.save();
  mmCtx.translate(playerX,playerZ);
  mmCtx.rotate(-player.yaw);
  mmCtx.fillStyle='#38e8ff';
  mmCtx.beginPath();
  mmCtx.moveTo(0,-3.5);
  mmCtx.lineTo(2.5,2.5);
  mmCtx.lineTo(-2.5,2.5);
  mmCtx.closePath();
  mmCtx.fill();
  mmCtx.restore();
}

/* ================= ИИ БОТОВ ================= */

const aiRay=new THREE.Raycaster();
const aiFrom=new THREE.Vector3();
const aiTo=new THREE.Vector3();
const aiDirection=new THREE.Vector3();
const tempVector=new THREE.Vector3();

function getTargetPosition(target){
  return target===player?player.pos:target.grp.position;
}

function canSee(a,b){
  aiFrom.set(a.x,1.5,a.z);
  aiTo.set(b.x,1.5,b.z);

  aiDirection.subVectors(aiTo,aiFrom);

  const distance=aiDirection.length();
  if(distance<.01)return true;

  aiDirection.divideScalar(distance);
  aiRay.set(aiFrom,aiDirection);
  aiRay.near=.1;
  aiRay.far=distance;

  return aiRay.intersectObjects(wallMeshes,false).length===0;
}

function findEnemy(bot){
  const position=bot.grp.position;
  let best=null;
  let bestDistance=42;

  const consider=target=>{
    const targetPosition=getTargetPosition(target);
    const distance=Math.hypot(
      targetPosition.x-position.x,
      targetPosition.z-position.z
    );

    if(distance<bestDistance&&canSee(position,targetPosition)){
      bestDistance=distance;
      best=target;
    }
  };

  if(bot.team==='enemy'){
    if(player.alive)consider(player);

    for(const other of bots){
      if(other.team==='ally'&&!other.dead){
        consider(other);
      }
    }
  }else{
    for(const other of bots){
      if(other.team==='enemy'&&!other.dead){
        consider(other);
      }
    }
  }

  bot.enemy=best;
  bot.enemyDist=bestDistance;
}

function randomPoint(){
  let x;
  let z;
  let tries=0;

  do{
    x=(Math.random()*2-1)*(WORLD-3);
    z=(Math.random()*2-1)*(WORLD-3);
    tries++;
  }while(tries<15&&pointInCollider(x,z,.8));

  return[x,z];
}

function botShoot(bot,target,distance){
  const targetIsPlayer=target===player;
  const targetPosition=getTargetPosition(target);

  const base=bot.team==='ally'?.5:.4;
  const hit=Math.random()<Math.max(.1,base-distance*.008);

  const from=bot.grp.position.clone();
  from.y=1.35;

  const to=new THREE.Vector3(
    targetPosition.x,
    targetIsPlayer?player.eyeH*.85:1.2,
    targetPosition.z
  );

  if(!hit){
    to.x+=(Math.random()*2-1)*2.2;
    to.y+=(Math.random()*2-1)*1.2;
    to.z+=(Math.random()*2-1)*2.2;
  }

  spawnTracer(
    from,
    to,
    bot.team==='ally'?0x7ab8ff:0xff8866
  );

  if(!hit)return;

  if(targetIsPlayer){
    applyDamage(7+Math.random()*7,bot);
  }else{
    damageBot(
      target,
      22+Math.random()*14,
      Math.random()<.15?'head':'body',
      bot
    );
  }
}

function updateBot(bot,dt){
  const group=bot.grp;

  if(bot.dead){
    bot.respawnT-=dt;

    if(bot.respawnT<=0&&!matchOver){
      respawnBot(bot);
    }

    return;
  }

  bot.checkT-=dt;

  if(bot.checkT<=0){
    bot.checkT=.3+Math.random()*.15;
    findEnemy(bot);
  }

  if(
    bot.enemy&&
    (
      (bot.enemy===player&&!player.alive)||
      (bot.enemy!==player&&bot.enemy.dead)
    )
  ){
    bot.enemy=null;
  }

  let moveX=0;
  let moveZ=0;
  const speed=bot.team==='ally'?3.5:3.1;

  if(bot.enemy){
    const targetPosition=getTargetPosition(bot.enemy);

    const angle=Math.atan2(
      targetPosition.x-group.position.x,
      targetPosition.z-group.position.z
    );

    group.rotation.y=angle;

    const distance=Math.hypot(
      targetPosition.x-group.position.x,
      targetPosition.z-group.position.z
    );

    bot.enemyDist=distance;

    bot.strafeT-=dt;
    if(bot.strafeT<=0){
      bot.strafeT=1+Math.random()*1.5;
      bot.strafe*=-1;
    }

    const toward=distance>14?1:(distance<9?-1:0);

    moveX=Math.sin(angle)*toward+Math.cos(angle)*bot.strafe*.8;
    moveZ=Math.cos(angle)*toward-Math.sin(angle)*bot.strafe*.8;

    bot.fireCd-=dt;

    if(bot.fireCd<=0){
      bot.fireCd=.7+Math.random()*.8;
      botShoot(bot,bot.enemy,distance);
    }
  }else{
    if(bot.team==='ally'&&player.alive){
      const angle=bot.slot*1.05;
      bot.target.set(
        player.pos.x+Math.cos(angle)*4.5,
        0,
        player.pos.z+Math.sin(angle)*4.5
      );
    }else{
      const dx=bot.target.x-group.position.x;
      const dz=bot.target.z-group.position.z;

      if(Math.hypot(dx,dz)<1.4){
        const point=randomPoint();
        bot.target.set(point[0],0,point[1]);
      }
    }
  }

  tempVector.set(
    bot.target.x-group.position.x,
    0,
    bot.target.z-group.position.z
  );

  if(tempVector.length()>1.4){
    tempVector.normalize();
    moveX=tempVector.x;
    moveZ=tempVector.z;
    group.rotation.y=Math.atan2(moveX,moveZ);
  }

  const length=Math.hypot(moveX,moveZ);

  if(length>.01){
    const currentSpeed=(bot.enemy?.85:1)*speed;

    group.position.x+=moveX/length*currentSpeed*dt;
    group.position.z+=moveZ/length*currentSpeed*dt;

    resolveCollisions(group.position,.45);
  }

  bot.body.position.y=
    .85+Math.sin(performance.now()*.008+bot.id)*.03;
}

/* ================= АНИМАЦИИ ОРУЖИЯ ================= */

const crosshairParts={
  top:$('ch-top'),
  bottom:$('ch-bottom'),
  left:$('ch-left'),
  right:$('ch-right')
};

[
  crosshairParts.top,
  crosshairParts.bottom,
  crosshairParts.left,
  crosshairParts.right
].forEach(part=>{
  part.style.transform='translate(-50%,-50%)';
  part.style.left='50%';
  part.style.top='50%';
});

function updateBolt(now){
  if(boltT<0)return;

  const elapsed=now-boltT;

  if(boltStage===0&&elapsed>240){
    sfxBoltPull();
    boltStage=1;
  }

  if(boltStage===1&&elapsed>520){
    sfxBoltPush();
    boltStage=2;
  }

  if(elapsed>760){
    boltT=-1;
    boltStage=0;
  }
}

function updateWeaponAnimation(dt,now){
  switchT=Math.min(1,switchT+dt*3.2);
  walkT+=dt*Math.hypot(player.vel.x,player.vel.z);

  let x=.26+Math.sin(walkT*1.7)*.006;
  let y=-.23+Math.abs(Math.cos(walkT*1.7))*.008;
  let z=-.39;

  let rotationX=0;
  let rotationY=0;
  let rotationZ=0;

  /* Анимация затвора пистолета после выстрела */
  if(curWeapon===4&&gunParts.slide){
    const slideBack=Math.max(0,1-(now-lastShot)/90);
    gunParts.slide.position.z=-.24+slideBack*.055;
  }

  /* Анимация перезарядки */
  if(reloading){
    const weapon=WEAPONS[curWeapon];
    const progress=Math.min(1,(now-reloadStart)/weapon.reloadTime);

    const wave=Math.sin(progress*Math.PI);

    rotationX+=.34*wave;
    y-=.10*wave;
    x-=.08*wave;

    if(gunParts.mag){
      const baseY=
        curWeapon===3?-.115:
        curWeapon===4?-.095:
        -.13;

      gunParts.mag.position.y=
        baseY-Math.sin(Math.min(1,progress/.45)*Math.PI)*.16;
    }

    if(curWeapon===3&&gunParts.bolt){
      const bolt=
        progress<.72
          ?Math.min(1,progress/.58)
          :(1-(progress-.72)/.28);

      gunParts.bolt.position.x=.062+bolt*.065;
    }
  }

  /* Анимация затвора AWP после выстрела */
  if(curWeapon===3&&boltT>=0){
    const amount=Math.sin(
      Math.min(1,(now-boltT)/720)*Math.PI
    );

    x+=amount*.025;
    rotationX-=amount*.08;

    if(gunParts.bolt){
      gunParts.bolt.position.x=.062+amount*.075;
    }
  }

  /* Анимация доставания оружия */
  const draw=1-switchT;
  y-=draw*.22;
  rotationX+=draw*.7;

  gunGroup.position.x=x;
  gunGroup.position.y=y;
  gunGroup.position.z=z;
  gunGroup.rotation.set(rotationX,rotationY,rotationZ);
}

function updatePlayer(dt,now){
  let forward=
    (keys['KeyW']?1:0)-
    (keys['KeyS']?1:0)-
    joy.y;

  let side=
    (keys['KeyD']?1:0)-
    (keys['KeyA']?1:0)+
    joy.x;

  const inputLength=Math.hypot(forward,side);

  if(inputLength>1){
    forward/=inputLength;
    side/=inputLength;
  }

  const speed=player.crouch?2.6:5.4;
  const sinYaw=Math.sin(player.yaw);
  const cosYaw=Math.cos(player.yaw);

  player.vel.x=(-sinYaw*forward+cosYaw*side)*speed;
  player.vel.z=(-cosYaw*forward-sinYaw*side)*speed;

  player.vel.y-=22*dt;

  if(keys['Space']&&player.onGround){
    player.vel.y=7.5;
    player.onGround=false;
  }

  player.pos.x+=player.vel.x*dt;
  player.pos.z+=player.vel.z*dt;
  player.pos.y+=player.vel.y*dt;

  if(player.pos.y<=0){
    player.pos.y=0;
    player.vel.y=0;
    player.onGround=true;
  }

  resolveCollisions(player.pos,.4);

  const targetEye=player.crouch?1.08:1.7;
  player.eyeH+=(targetEye-player.eyeH)*Math.min(1,dt*10);

  camera.position.set(
    player.pos.x,
    player.pos.y+player.eyeH,
    player.pos.z
  );

  camera.rotation.y=player.yaw;
  camera.rotation.x=player.pitch;

  if(fireHeld&&WEAPONS[curWeapon].auto){
    tryFire(now);
  }

  const weapon=WEAPONS[curWeapon];
  const targetFov=aiming?weapon.aimFov:75;

  camera.fov+=(targetFov-camera.fov)*Math.min(1,dt*12);
  camera.updateProjectionMatrix();

  const scoped=weapon.scoped&&aiming;

  scopeEl.style.display=scoped?'block':'none';
  crosshairEl.style.opacity=scoped?'0':'1';
  gunGroup.visible=!scoped;

  gunGroup.position.z+=
    (-.39-gunGroup.position.z)*Math.min(1,dt*8);

  updateReload(now);
  updateBolt(now);
  updateWeaponAnimation(dt,now);

  bloom=Math.max(0,bloom-dt*1.6);

  const moveSpread=Math.min(
    8,
    Math.hypot(player.vel.x,player.vel.z)*1.1
  );

  const gap=8+bloom*14+moveSpread;

  crosshairParts.top.style.top='calc(50% - '+gap+'px)';
  crosshairParts.bottom.style.top='calc(50% + '+gap+'px)';
  crosshairParts.left.style.left='calc(50% - '+gap+'px)';
  crosshairParts.right.style.left='calc(50% + '+gap+'px)';

  if(
    player.alive&&
    Math.hypot(player.vel.x,player.vel.z)>.5&&
    player.onGround
  ){
    camera.position.y+=Math.sin(now*.012)*.02;
  }
}

/* ================= ГЛАВНЫЙ ЦИКЛ ================= */

let lastRender=0;
let previousFrame=0;

function loop(now){
  requestAnimationFrame(loop);

  const interval=fpsCap>0?1000/fpsCap:0;
  const elapsed=now-lastRender;

  if(elapsed<interval-1)return;

  lastRender=
    interval&&elapsed<interval*4
      ?now-(elapsed%interval)
      :now;

  let dt=(now-previousFrame)/1000;
  previousFrame=now;

  if(dt>.05)dt=.05;
  if(dt<=0)dt=.001;

  if(matchStarted){
    if(player.alive){
      updatePlayer(dt,now);
    }else{
      camera.rotation.y+=dt*.4;
    }

    for(let i=bots.length-1;i>=0;i--){
      updateBot(bots[i],dt);
    }

    for(let i=tracers.length-1;i>=0;i--){
      const tracer=tracers[i];
      tracer.life-=dt;

      if(tracer.life<=0){
        scene.remove(tracer.line);
        tracer.line.geometry.dispose();
        tracer.line.material.dispose();
        tracers.splice(i,1);
      }else{
        tracer.line.material.opacity=tracer.life/.07*.9;
      }
    }

    muzzleLight.intensity=Math.max(
      0,
      muzzleLight.intensity-dt*30
    );

    drawMinimap();
  }

  renderer.render(scene,camera);
}

function resize(){
  camera.aspect=innerWidth/innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
}

addEventListener('resize',resize);

if('ontouchstart'in window){
  $('desktop-hint').style.display='none';
}

applyGraphics();
buildGun(curWeapon);
updateAmmoHUD();
resize();
requestAnimationFrame(loop);

})();
