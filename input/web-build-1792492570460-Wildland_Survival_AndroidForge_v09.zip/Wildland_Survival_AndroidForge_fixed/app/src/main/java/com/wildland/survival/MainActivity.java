package com.wildland.survival;

import org.godotengine.godot.GodotActivity;

/**
 * Hosts the embedded Godot project from app/src/main/assets.
 * project.godot must be at the root of assets/.
 */
public class MainActivity extends GodotActivity {
}
