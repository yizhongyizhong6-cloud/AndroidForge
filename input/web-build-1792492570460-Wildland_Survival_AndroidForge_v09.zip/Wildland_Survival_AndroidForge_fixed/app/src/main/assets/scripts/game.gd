extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const CAR_SCRIPT = preload("res://scripts/car.gd")

var player: CharacterBody3D
var car: CharacterBody3D
var inventory := {"Дерево": 0, "Камень": 0, "Волокно": 0, "Скрап": 0, "Инструменты": 0, "Бур": 0, "Оружие": 0}
var trees: Array[Node3D] = []
var stones: Array[Node3D] = []
var loot_containers: Array[Node3D] = []
var nearby: Node3D
var in_car := false

var ui: CanvasLayer
var hud: Control
var main_menu: PanelContainer
var settings_menu: PanelContainer
var inventory_label: Label
var hint_label: Label
var message_label: Label
var action_button: Button
var waiting_action := ""
var sensitivity := 0.008
var button_scale := 1.0
var touch_move := Vector2.ZERO

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    randomize()
    _create_world()
    _create_player()
    _create_car()
    _create_ui()
    _show_main_menu()

func _process(_delta: float) -> void:
    if player and not in_car:
        _find_nearby()
    elif in_car:
        nearby = car
        hint_label.text = "Ты за рулём. Нажми «Действие», чтобы выйти."
        action_button.text = "Выйти"
    if player and not in_car and nearby:
        action_button.text = "Сесть" if nearby == car else "Собрать"
        hint_label.text = "Рядом: машина" if nearby == car else "Рядом: " + str(nearby.get_meta("kind"))
    elif player and not in_car:
        action_button.text = "Действие"
        hint_label.text = "Исследуй остров, собирай ресурсы и строй базу."

func _create_world() -> void:
    # Освещение как на референсах: яркое небо, жёсткое солнце
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.55, 0.72, 0.90)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.75, 0.80, 0.88)
    env.ambient_light_energy = 0.95
    env_node.environment = env
    add_child(env_node)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -35, 0)
    sun.light_energy = 1.35
    sun.shadow_enabled = false
    add_child(sun)

    # Основная земля — сухая трава / степь
    var ground := StaticBody3D.new()
    var ground_mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(420, 420)
    ground_mesh.mesh = plane
    var grass := StandardMaterial3D.new()
    grass.albedo_color = Color(0.42, 0.48, 0.28)
    grass.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    ground_mesh.material_override = grass
    ground.add_child(ground_mesh)
    var ground_collision := CollisionShape3D.new()
    var ground_shape := BoxShape3D.new()
    ground_shape.size = Vector3(420, 1, 420)
    ground_collision.shape = ground_shape
    ground_collision.position.y = -0.5
    ground.add_child(ground_collision)
    add_child(ground)

    # Пятна более зелёной травы и песка (как на референсах)
    for i in range(40):
        var patch := MeshInstance3D.new()
        var pmesh := PlaneMesh.new()
        pmesh.size = Vector2(randf_range(12, 28), randf_range(12, 28))
        patch.mesh = pmesh
        patch.position = Vector3(randf_range(-160, 160), 0.02, randf_range(-160, 160))
        var pm := StandardMaterial3D.new()
        if randf() > 0.45:
            pm.albedo_color = Color(0.28, 0.46, 0.22)
        else:
            pm.albedo_color = Color(0.62, 0.55, 0.38)
        pm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        patch.material_override = pm
        add_child(patch)

    # Простые «холмы» / скалы по краям — силуэт каньона
    for i in range(18):
        _make_hill(Vector3(randf_range(-180, 180), 0, randf_range(-180, 180)))

    _make_road(Vector3(0, 0.03, 0), Vector2(9, 360))
    _make_road(Vector3(0, 0.035, 0), Vector2(360, 9))
    _make_road(Vector3(38, 0.04, 35), Vector2(7, 110))
    _make_road(Vector3(-70, 0.04, -30), Vector2(110, 7))
    _make_road(Vector3(105, 0.04, 100), Vector2(7, 120))
    _make_road(Vector3(105, 0.04, 150), Vector2(110, 7))
    # Извилистая «дубль»-дорога
    _make_road(Vector3(55, 0.045, -80), Vector2(6, 80))
    _make_road(Vector3(-90, 0.045, 70), Vector2(80, 6))

    _create_gas_station()
    _create_water_treatment_plant()
    _spawn_roadside_loot()
    _create_dome_landmark()

    for i in range(90):
        var pos := Vector3(randf_range(-170, 170), 0, randf_range(-170, 170))
        if absf(pos.x) < 10 or absf(pos.z) < 10:
            continue
        _make_tree(pos)
    for i in range(55):
        var pos := Vector3(randf_range(-170, 170), 0, randf_range(-170, 170))
        if absf(pos.x) < 8 or absf(pos.z) < 8:
            continue
        _make_stone(pos)
    # Кластеры камней у «скал»
    for i in range(25):
        var pos := Vector3(randf_range(-170, 170), 0, randf_range(-170, 170))
        _make_stone(pos)
        _make_stone(pos + Vector3(randf_range(-2, 2), 0, randf_range(-2, 2)))


func _make_hill(pos: Vector3) -> void:
    if absf(pos.x) < 25 and absf(pos.z) < 25:
        return
    var body := StaticBody3D.new()
    body.position = pos
    var h := randf_range(4.0, 14.0)
    var w := randf_range(8.0, 22.0)
    var mesh_node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(w, h, w * randf_range(0.7, 1.2))
    mesh_node.mesh = box
    mesh_node.position.y = h * 0.5
    mesh_node.rotation_degrees.y = randf_range(0, 360)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.48, 0.45, 0.40)
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    mesh_node.material_override = mat
    body.add_child(mesh_node)
    # Верх «скалы» чуть светлее
    var cap := MeshInstance3D.new()
    var cap_mesh := BoxMesh.new()
    cap_mesh.size = Vector3(w * 0.7, h * 0.25, w * 0.6)
    cap.mesh = cap_mesh
    cap.position.y = h * 0.85
    var cap_mat := StandardMaterial3D.new()
    cap_mat.albedo_color = Color(0.55, 0.52, 0.48)
    cap_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    cap.material_override = cap_mat
    body.add_child(cap)
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = box.size
    cs.shape = shape
    cs.position.y = h * 0.5
    body.add_child(cs)
    add_child(body)

func _create_dome_landmark() -> void:
    # Ржавый купол как на референсе — ориентир на карте
    var root := Node3D.new()
    root.name = "DomeLandmark"
    root.position = Vector3(-95, 0, 110)
    add_child(root)
    var rust := Color(0.55, 0.28, 0.16)
    var base := MeshInstance3D.new()
    var base_mesh := CylinderMesh.new()
    base_mesh.top_radius = 14.0
    base_mesh.bottom_radius = 15.0
    base_mesh.height = 3.0
    base.mesh = base_mesh
    base.position.y = 1.5
    var bm := StandardMaterial3D.new()
    bm.albedo_color = rust
    bm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    base.material_override = bm
    root.add_child(base)
    var dome := MeshInstance3D.new()
    var dome_mesh := SphereMesh.new()
    dome_mesh.radius = 16.0
    dome_mesh.height = 20.0
    dome.mesh = dome_mesh
    dome.position.y = 12.0
    dome.scale = Vector3(1.0, 0.72, 1.0)
    var dm := StandardMaterial3D.new()
    dm.albedo_color = Color(0.62, 0.32, 0.18)
    dm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    dome.material_override = dm
    root.add_child(dome)
    for i in range(8):
        var a := i * TAU / 8.0
        var pillar := MeshInstance3D.new()
        var pm := CylinderMesh.new()
        pm.top_radius = 0.6
        pm.bottom_radius = 0.8
        pm.height = 9.0
        pillar.mesh = pm
        pillar.position = Vector3(cos(a) * 12.0, 4.5, sin(a) * 12.0)
        pillar.material_override = bm
        root.add_child(pillar)

func _make_box(parent: Node3D, pos: Vector3, size: Vector3, color: Color, collision := true) -> MeshInstance3D:
    var mesh_node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh_node.mesh = box
    mesh_node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.88
    mesh_node.material_override = mat
    parent.add_child(mesh_node)
    if collision:
        var body := StaticBody3D.new()
        body.position = pos
        var visual := MeshInstance3D.new()
        visual.mesh = box
        visual.visible = false
        body.add_child(visual)
        var cs := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = size
        cs.shape = shape
        body.add_child(cs)
        parent.add_child(body)
    return mesh_node

func _make_structure_body(parent: Node3D, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
    var body := StaticBody3D.new()
    body.position = pos
    var mesh_node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh_node.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.92
    mesh_node.material_override = mat
    body.add_child(mesh_node)
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    cs.shape = shape
    body.add_child(cs)
    parent.add_child(body)
    return body

func _create_gas_station() -> void:
    # Заправка стоит рядом с центральной дорогой; крыша доступна по наклонному пандусу.
    var station := Node3D.new()
    station.name = "Заправка"
    station.position = Vector3(23, 0, 20)
    add_child(station)
    var concrete := Color(0.48, 0.48, 0.43)
    var wall := Color(0.68, 0.65, 0.55)
    _make_structure_body(station, Vector3(0, 1.8, 0), Vector3(12, 3.6, 9), wall)
    _make_box(station, Vector3(0, 3.72, 0), Vector3(12.8, 0.35, 9.8), Color(0.72, 0.12, 0.08), false)
    _make_box(station, Vector3(0, 2.3, -4.56), Vector3(3.2, 1.2, 0.08), Color(0.15, 0.48, 0.60), false)
    # Навес и топливные колонки перед зданием.
    _make_structure_body(station, Vector3(0, 3.4, 7.0), Vector3(13, 0.35, 5), Color(0.76, 0.12, 0.08))
    for x in [-5.4, 5.4]:
        _make_structure_body(station, Vector3(x, 1.65, 7.0), Vector3(0.35, 3.3, 0.35), Color(0.7, 0.7, 0.65))
    for x in [-3.2, 0.0, 3.2]:
        _make_structure_body(station, Vector3(x, 0.8, 7.0), Vector3(0.75, 1.6, 0.65), Color(0.82, 0.82, 0.76))
        _make_box(station, Vector3(x, 1.35, 7.34), Vector3(0.38, 0.28, 0.08), Color(0.1, 0.24, 0.25), false)
    # Пандус-коробка под небольшим углом позволяет подняться на крышу пешком.
    var ramp := _make_structure_body(station, Vector3(0, 2.0, -9.0), Vector3(3.2, 0.28, 9.2), concrete)
    ramp.rotation.x = 0.43
    # На крыше ровная поверхность и два больших ящика.
    _spawn_loot_container(station, Vector3(-3.0, 4.35, -1.0), "большой ящик")
    _spawn_loot_container(station, Vector3(3.0, 4.35, 1.0), "большой ящик")
    # У наружных стен стоят два красных и два больших ящика.
    _spawn_loot_container(station, Vector3(-7.2, 0.65, 3.2), "красный ящик")
    _spawn_loot_container(station, Vector3(7.2, 0.65, 3.2), "красный ящик")
    _spawn_loot_container(station, Vector3(-7.2, 0.65, -2.5), "большой ящик")
    _spawn_loot_container(station, Vector3(7.2, 0.65, -2.5), "большой ящик")
    _make_box(station, Vector3(0, 0.06, 0), Vector3(17, 0.12, 22), Color(0.36, 0.36, 0.32), false)

func _create_water_treatment_plant() -> void:
    var plant := Node3D.new()
    plant.name = "Водоочистительная станция"
    plant.position = Vector3(112, 0, 126)
    add_child(plant)
    var building_color := Color(0.54, 0.60, 0.59)
    _make_structure_body(plant, Vector3(0, 2.0, 0), Vector3(18, 4, 12), building_color)
    _make_box(plant, Vector3(0, 4.1, 0), Vector3(18.8, 0.35, 12.8), Color(0.22, 0.30, 0.31), false)
    # Большие фильтрационные баки.
    for x in [-8.0, -2.8, 2.8, 8.0]:
        var tank := MeshInstance3D.new()
        var cylinder := CylinderMesh.new()
        cylinder.top_radius = 2.0
        cylinder.bottom_radius = 2.0
        cylinder.height = 4.8
        tank.mesh = cylinder
        tank.position = Vector3(x, 2.4, 9.5)
        var tank_mat := StandardMaterial3D.new()
        tank_mat.albedo_color = Color(0.38, 0.47, 0.48)
        tank.material_override = tank_mat
        plant.add_child(tank)
        var tank_body := StaticBody3D.new()
        tank_body.position = tank.position
        var tank_cs := CollisionShape3D.new()
        var tank_shape := CylinderShape3D.new()
        tank_shape.radius = 2.0
        tank_shape.height = 4.8
        tank_cs.shape = tank_shape
        tank_body.add_child(tank_cs)
        plant.add_child(tank_body)
    # Промышленный лут: ящики и бочки вокруг станции.
    _spawn_loot_container(plant, Vector3(-8, 0.65, -8), "красный ящик")
    _spawn_loot_container(plant, Vector3(8, 0.65, -8), "красный ящик")
    _spawn_loot_container(plant, Vector3(-10, 0.65, 4), "большой ящик")
    _spawn_loot_container(plant, Vector3(10, 0.65, 4), "большой ящик")
    _spawn_loot_container(plant, Vector3(-12, 0.65, 10), "бочка")
    _spawn_loot_container(plant, Vector3(12, 0.65, 10), "бочка")
    _spawn_loot_container(plant, Vector3(-14, 0.65, -2), "бочка")
    _spawn_loot_container(plant, Vector3(14, 0.65, -2), "бочка")
    # Невысокий забор по периметру промышленной площадки.
    for x in range(-18, 19, 6):
        _make_structure_body(plant, Vector3(x, 0.65, -15), Vector3(0.18, 1.3, 0.18), Color(0.35, 0.37, 0.35))
        _make_structure_body(plant, Vector3(x, 0.65, 15), Vector3(0.18, 1.3, 0.18), Color(0.35, 0.37, 0.35))

func _spawn_roadside_loot() -> void:
    # Ящики появляются вдоль дорог, но не стоят через каждые несколько метров.
    for z in [-145, -100, -55, 48, 92, 140]:
        _spawn_loot_container(self, Vector3(7.5, 0.65, float(z)), "большой ящик")
    for x in [-145, -95, -45, 70, 145]:
        _spawn_loot_container(self, Vector3(float(x), 0.65, 7.5), "маленький ящик")
    _spawn_loot_container(self, Vector3(-6.5, 0.65, -72), "красный ящик")
    _spawn_loot_container(self, Vector3(6.5, 0.65, 115), "красный ящик")

func _spawn_loot_container(parent: Node3D, pos: Vector3, container_kind: String) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.set_meta("kind", container_kind)
    body.set_meta("loot_container", true)
    var size := Vector3(1.25, 1.2, 0.9)
    var color := Color(0.44, 0.29, 0.13)
    if container_kind == "маленький ящик":
        size = Vector3(0.75, 0.65, 0.6)
        color = Color(0.38, 0.25, 0.12)
    elif container_kind == "красный ящик":
        size = Vector3(1.3, 1.25, 0.95)
        color = Color(0.72, 0.07, 0.045)
    elif container_kind == "бочка":
        var barrel := MeshInstance3D.new()
        var cylinder := CylinderMesh.new()
        cylinder.top_radius = 0.43
        cylinder.bottom_radius = 0.43
        cylinder.height = 1.2
        barrel.mesh = cylinder
        var barrel_mat := StandardMaterial3D.new()
        barrel_mat.albedo_color = Color(0.28, 0.36, 0.38)
        barrel.material_override = barrel_mat
        body.add_child(barrel)
        var barrel_shape := CollisionShape3D.new()
        var cylinder_shape := CylinderShape3D.new()
        cylinder_shape.radius = 0.43
        cylinder_shape.height = 1.2
        barrel_shape.shape = cylinder_shape
        body.add_child(barrel_shape)
        parent.add_child(body)
        loot_containers.append(body)
        return
    var mesh_node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh_node.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.86
    mesh_node.material_override = mat
    body.add_child(mesh_node)
    # Крышка/полосы делают тип ящика различимым с расстояния.
    var lid := MeshInstance3D.new()
    var lid_mesh := BoxMesh.new()
    lid_mesh.size = Vector3(size.x * 1.03, 0.08, size.z * 1.03)
    lid.mesh = lid_mesh
    lid.position.y = size.y * 0.48
    var lid_mat := StandardMaterial3D.new()
    lid_mat.albedo_color = Color(0.82, 0.78, 0.62) if container_kind != "красный ящик" else Color(0.95, 0.35, 0.22)
    lid.material_override = lid_mat
    body.add_child(lid)
    var cs := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    cs.shape = shape
    body.add_child(cs)
    parent.add_child(body)
    loot_containers.append(body)

func _loot_container(container: Node3D) -> void:
    var kind := str(container.get_meta("kind", "маленький ящик"))
    var roll := randf()
    var result := "Скрап"
    if kind == "маленький ящик":
        if roll < 0.62:
            inventory["Скрап"] += randi_range(3, 12)
            result = "Скрап"
        elif roll < 0.83:
            inventory["Дерево"] += randi_range(3, 8)
            result = "Дерево"
        elif roll < 0.94:
            inventory["Инструменты"] += 1
            result = "Редкий инструмент"
        elif roll < 0.985:
            inventory["Оружие"] += 1
            result = "Лук или арбалет"
        else:
            inventory["Бур"] += 1
            result = "Редкий бур"
    elif kind == "красный ящик":
        if roll < 0.45:
            inventory["Скрап"] += randi_range(12, 35)
            result = "Скрап"
        elif roll < 0.68:
            inventory["Инструменты"] += 1
            result = "Инструмент"
        elif roll < 0.84:
            inventory["Оружие"] += 1
            result = "Револьвер или другое оружие"
        elif roll < 0.96:
            inventory["Дерево"] += randi_range(8, 18)
            result = "Материалы"
        else:
            inventory["Бур"] += 1
            result = "Редкий бур"
    elif kind == "большой ящик":
        if roll < 0.50:
            inventory["Скрап"] += randi_range(10, 28)
            result = "Скрап"
        elif roll < 0.72:
            inventory["Дерево"] += randi_range(8, 20)
            result = "Материалы"
        elif roll < 0.88:
            inventory["Инструменты"] += 1
            result = "Инструмент"
        elif roll < 0.975:
            inventory["Оружие"] += 1
            result = "Лук, арбалет или револьвер"
        else:
            inventory["Бур"] += 1
            result = "Редкий бур"
    else: # бочка
        if roll < 0.72:
            inventory["Скрап"] += randi_range(4, 16)
            result = "Скрап"
        elif roll < 0.9:
            inventory["Дерево"] += randi_range(3, 9)
            result = "Материалы"
        else:
            inventory["Инструменты"] += 1
            result = "Инструмент"
    loot_containers.erase(container)
    container.queue_free()
    nearby = null
    _refresh_inventory()
    _say("Найдено: " + result)

func _make_road(pos: Vector3, size: Vector2) -> void:
    var road := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = size
    road.mesh = mesh
    road.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.16, 0.17, 0.16)
    mat.roughness = 1.0
    road.material_override = mat
    add_child(road)
    # Road markings
    if size.x > size.y:
        for z in range(-int(size.y / 2) + 5, int(size.y / 2), 10):
            var mark := MeshInstance3D.new()
            var mark_mesh := BoxMesh.new()
            mark_mesh.size = Vector3(0.22, 0.025, 4.0)
            mark.mesh = mark_mesh
            mark.position = pos + Vector3(0, 0.025, z)
            var mark_mat := StandardMaterial3D.new()
            mark_mat.albedo_color = Color(0.86, 0.82, 0.58)
            mark.material_override = mark_mat
            add_child(mark)
    else:
        for x in range(-int(size.x / 2) + 5, int(size.x / 2), 10):
            var mark := MeshInstance3D.new()
            var mark_mesh := BoxMesh.new()
            mark_mesh.size = Vector3(4.0, 0.025, 0.22)
            mark.mesh = mark_mesh
            mark.position = pos + Vector3(x, 0.025, 0)
            var mark_mat := StandardMaterial3D.new()
            mark_mat.albedo_color = Color(0.86, 0.82, 0.58)
            mark.material_override = mark_mat
            add_child(mark)

func _make_tree(pos: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.set_meta("kind", "дерево")
    var h := randf_range(7.0, 14.0)
    var trunk_r := randf_range(0.22, 0.38)
    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = trunk_r * 0.55
    trunk_mesh.bottom_radius = trunk_r
    trunk_mesh.height = h * 0.55
    trunk.mesh = trunk_mesh
    trunk.position.y = h * 0.275
    var trunk_mat := StandardMaterial3D.new()
    trunk_mat.albedo_color = Color(0.35, 0.22, 0.12)
    trunk_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    trunk.material_override = trunk_mat
    body.add_child(trunk)
    # Сосна: ярусы конусов (как на референсе)
    var green := Color(0.08, 0.28 + randf() * 0.1, 0.10)
    var layers := randi_range(4, 6)
    for i in range(layers):
        var t := float(i) / float(layers)
        var cone := MeshInstance3D.new()
        var cm := CylinderMesh.new()
        var r := lerpf(2.6, 0.35, t)
        cm.top_radius = r * 0.15
        cm.bottom_radius = r
        cm.height = h * 0.14
        cone.mesh = cm
        cone.position.y = h * 0.42 + i * (h * 0.10)
        var cm_mat := StandardMaterial3D.new()
        cm_mat.albedo_color = green.darkened(t * 0.15)
        cm_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
        cone.material_override = cm_mat
        body.add_child(cone)
    var cs := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = trunk_r + 0.35
    shape.height = h * 0.75
    cs.shape = shape
    cs.position.y = h * 0.35
    body.add_child(cs)
    add_child(body)
    trees.append(body)


func _make_stone(pos: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.set_meta("kind", "камень")
    var base_col := Color(0.45 + randf() * 0.12, 0.44 + randf() * 0.08, 0.42 + randf() * 0.06)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = base_col
    mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    var max_r := 0.35
    # Объёмный валун из нескольких «глыб» (референс: один крупный камень)
    for i in range(randi_range(3, 6)):
        var rock := MeshInstance3D.new()
        var mesh := SphereMesh.new()
        var r := randf_range(0.5, 1.35)
        max_r = maxf(max_r, r)
        mesh.radius = r
        mesh.height = r * randf_range(1.1, 1.7)
        rock.mesh = mesh
        rock.position = Vector3(randf_range(-0.55, 0.55), r * 0.4 + randf() * 0.25, randf_range(-0.55, 0.55))
        rock.scale = Vector3(randf_range(0.85, 1.35), randf_range(0.55, 0.95), randf_range(0.85, 1.35))
        rock.rotation_degrees = Vector3(randf_range(-20, 20), randf_range(0, 360), randf_range(-15, 15))
        var m2 := mat.duplicate()
        m2.albedo_color = base_col.lightened(randf_range(-0.08, 0.08))
        rock.material_override = m2
        body.add_child(rock)
    var cs := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = max_r * 1.1
    cs.shape = shape
    cs.position.y = max_r * 0.4
    body.add_child(cs)
    add_child(body)
    stones.append(body)


func _create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PLAYER_SCRIPT)
    player.position = Vector3(3, 2.0, 3)
    add_child(player)
    player.game = self
    if player.has_method("set_sensitivity"):
        player.set_sensitivity(sensitivity)
    # Fallback camera if player script did not attach a current camera
    call_deferred("_ensure_camera")


func _ensure_camera() -> void:
    var cam := get_viewport().get_camera_3d()
    if cam != null:
        return
    # Player script failed or camera missing — create emergency camera
    var emergency := Camera3D.new()
    emergency.name = "EmergencyCamera"
    emergency.current = true
    if player:
        emergency.position = player.global_position + Vector3(0, 3, 8)
        add_child(emergency)
        emergency.look_at(player.global_position + Vector3(0, 1, 0), Vector3.UP)
    else:
        emergency.position = Vector3(0, 8, 12)
        add_child(emergency)
        emergency.look_at(Vector3.ZERO, Vector3.UP)
    _say("Камера: аварийный режим (проверь scripts/player.gd)")

func _create_car() -> void:
    car = CharacterBody3D.new()
    car.name = "RustStyleCar"
    car.set_script(CAR_SCRIPT)
    # На большой карте оставлена только одна машина, в случайной точке дороги.
    car.position = Vector3(0, 0.0, randf_range(-155, 155))
    add_child(car)

func _create_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    hud = Control.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(hud)

    var top := PanelContainer.new()
    top.position = Vector2(16, 16)
    top.custom_minimum_size = Vector2(360, 112)
    hud.add_child(top)
    var top_box := VBoxContainer.new()
    top.add_child(top_box)
    var title := Label.new()
    title.text = "WILDLAND: SURVIVAL"
    title.add_theme_font_size_override("font_size", 22)
    top_box.add_child(title)
    inventory_label = Label.new()
    top_box.add_child(inventory_label)
    hint_label = Label.new()
    top_box.add_child(hint_label)

    message_label = Label.new()
    message_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    message_label.position = Vector2(-250, 145)
    message_label.size = Vector2(500, 48)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 21)
    hud.add_child(message_label)

    action_button = Button.new()
    action_button.text = "Действие"
    action_button.size = Vector2(180, 88) * button_scale
    action_button.anchor_left = 1
    action_button.anchor_right = 1
    action_button.anchor_top = 1
    action_button.anchor_bottom = 1
    action_button.position = Vector2(-175, -100)
    action_button.pressed.connect(_on_action)
    action_button.mouse_filter = Control.MOUSE_FILTER_STOP
    action_button.focus_mode = Control.FOCUS_NONE
    hud.add_child(action_button)

    var craft_button := Button.new()
    craft_button.text = "Крафт"
    craft_button.size = Vector2(150, 78) * button_scale
    craft_button.anchor_left = 1
    craft_button.anchor_right = 1
    craft_button.anchor_top = 1
    craft_button.anchor_bottom = 1
    craft_button.position = Vector2(-315, -95)
    craft_button.pressed.connect(_craft)
    hud.add_child(craft_button)

    var build_button := Button.new()
    build_button.text = "Строить"
    build_button.size = Vector2(150, 78) * button_scale
    build_button.anchor_left = 1
    build_button.anchor_right = 1
    build_button.anchor_top = 1
    build_button.anchor_bottom = 1
    build_button.position = Vector2(-455, -95)
    build_button.pressed.connect(_build_wall)
    hud.add_child(build_button)

    var menu_button := Button.new()
    menu_button.text = "☰"
    menu_button.size = Vector2(64, 56)
    menu_button.anchor_left = 1
    menu_button.anchor_right = 1
    menu_button.position = Vector2(-82, 18)
    menu_button.pressed.connect(_show_pause_menu)
    menu_button.mouse_filter = Control.MOUSE_FILTER_STOP
    hud.add_child(menu_button)
    _create_dpad(hud)

    _refresh_inventory()
    _create_main_menu()
    _create_settings_menu()

func _create_main_menu() -> void:
    main_menu = PanelContainer.new()
    main_menu.set_anchors_preset(Control.PRESET_CENTER)
    main_menu.position = Vector2(-210, -210)
    main_menu.size = Vector2(420, 420)
    ui.add_child(main_menu)
    var box := VBoxContainer.new()
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    main_menu.add_child(box)
    var heading := Label.new()
    heading.text = "WILDLAND: SURVIVAL"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 28)
    box.add_child(heading)
    var sub := Label.new()
    sub.text = "Остров. Ресурсы. Строительство. Выживание."
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(sub)
    _menu_button(box, "Играть", _start_game)
    _menu_button(box, "Настройки", _open_settings)
    _menu_button(box, "Выйти", _exit_game)

func _create_settings_menu() -> void:
    settings_menu = PanelContainer.new()
    settings_menu.set_anchors_preset(Control.PRESET_CENTER)
    settings_menu.position = Vector2(-250, -260)
    settings_menu.size = Vector2(500, 520)
    ui.add_child(settings_menu)
    var box := VBoxContainer.new()
    settings_menu.add_child(box)
    var heading := Label.new()
    heading.text = "НАСТРОЙКИ УПРАВЛЕНИЯ"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 24)
    box.add_child(heading)

    var sens_label := Label.new()
    sens_label.text = "Чувствительность камеры: %.3f" % sensitivity
    box.add_child(sens_label)
    var sens_slider := HSlider.new()
    sens_slider.min_value = 0.002
    sens_slider.max_value = 0.025
    sens_slider.step = 0.001
    sens_slider.value = sensitivity
    sens_slider.value_changed.connect(func(value: float):
        sensitivity = value
        sens_label.text = "Чувствительность камеры: %.3f" % sensitivity
        player.set_sensitivity(sensitivity)
    )
    box.add_child(sens_slider)

    var size_label := Label.new()
    size_label.text = "Размер кнопок: %.1f×" % button_scale
    box.add_child(size_label)
    var size_slider := HSlider.new()
    size_slider.min_value = 0.75
    size_slider.max_value = 1.5
    size_slider.step = 0.05
    size_slider.value = button_scale
    size_slider.value_changed.connect(func(value: float):
        button_scale = value
        size_label.text = "Размер кнопок: %.1f×" % button_scale
        _resize_hud_buttons()
    )
    box.add_child(size_slider)

    var controls_title := Label.new()
    controls_title.text = "Клавиатура (для теста на ПК)"
    box.add_child(controls_title)
    _add_rebind_button(box, "Вперёд", "move_forward")
    _add_rebind_button(box, "Назад", "move_back")
    _add_rebind_button(box, "Влево", "move_left")
    _add_rebind_button(box, "Вправо", "move_right")
    var note := Label.new()
    note.text = "На телефоне: слева движение, справа поворот камеры."
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(note)
    _menu_button(box, "Назад", _close_settings)

func _menu_button(parent: VBoxContainer, caption: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(0, 54)
    button.pressed.connect(callback)
    parent.add_child(button)

func _add_rebind_button(parent: VBoxContainer, caption: String, action: String) -> void:
    var button := Button.new()
    button.text = caption + ": " + _get_action_key(action)
    button.custom_minimum_size.y = 42
    button.pressed.connect(func():
        waiting_action = action
        button.text = caption + ": нажми клавишу..."
    )
    parent.add_child(button)
    button.set_meta("action_name", action)
    button.set_meta("caption", caption)

func _get_action_key(action: String) -> String:
    if not InputMap.has_action(action):
        return "не назначено"
    var events := InputMap.action_get_events(action)
    if events.size() > 0 and events[0] is InputEventKey:
        return OS.get_keycode_string(events[0].physical_keycode)
    return "не назначено"

func _input(event: InputEvent) -> void:
    if waiting_action != "" and event is InputEventKey and event.pressed and not event.echo:
        InputMap.action_erase_events(waiting_action)
        InputMap.action_add_event(waiting_action, event)
        waiting_action = ""
        _refresh_rebind_labels()
        get_viewport().set_input_as_handled()

func _refresh_rebind_labels() -> void:
    _refresh_settings_buttons(settings_menu)

func _refresh_settings_buttons(node: Node) -> void:
    for child in node.get_children():
        if child is Button and child.has_meta("action_name"):
            child.text = str(child.get_meta("caption")) + ": " + _get_action_key(str(child.get_meta("action_name")))
        _refresh_settings_buttons(child)

func _resize_hud_buttons() -> void:
    for child in hud.get_children():
        if child is Button and child != action_button and child.text != "☰":
            child.size = Vector2(125, 62) * button_scale
    action_button.size = Vector2(180, 88) * button_scale


func _create_dpad(parent: Control) -> void:
    var root := Control.new()
    root.name = "DPad"
    root.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
    root.position = Vector2(24, -280)
    root.size = Vector2(220, 220)
    root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(root)
    var dirs = {
        "U": [Vector2(70, 0), Vector2(0, -1)],
        "D": [Vector2(70, 140), Vector2(0, 1)],
        "L": [Vector2(0, 70), Vector2(-1, 0)],
        "R": [Vector2(140, 70), Vector2(1, 0)],
    }
    for key in dirs:
        var b := Button.new()
        b.text = key
        b.position = dirs[key][0]
        b.size = Vector2(70, 70)
        b.focus_mode = Control.FOCUS_NONE
        b.mouse_filter = Control.MOUSE_FILTER_STOP
        var dir: Vector2 = dirs[key][1]
        b.button_down.connect(func(): _dpad_pressed(dir))
        b.button_up.connect(func(): _dpad_released(dir))
        root.add_child(b)

func _dpad_pressed(dir: Vector2) -> void:
    if player and player.has_method("add_dpad"):
        player.add_dpad(dir)

func _dpad_released(dir: Vector2) -> void:
    if player and player.has_method("remove_dpad"):
        player.remove_dpad(dir)

func _show_main_menu() -> void:
    main_menu.visible = true
    settings_menu.visible = false
    hud.visible = false
    get_tree().paused = true

func _show_pause_menu() -> void:
    main_menu.visible = true
    settings_menu.visible = false
    hud.visible = false
    get_tree().paused = true

func _start_game() -> void:
    main_menu.visible = false
    settings_menu.visible = false
    hud.visible = true
    get_tree().paused = false

func _open_settings() -> void:
    main_menu.visible = false
    settings_menu.visible = true
    hud.visible = false

func _close_settings() -> void:
    settings_menu.visible = false
    main_menu.visible = true

func _exit_game() -> void:
    get_tree().quit()

func _find_nearby() -> void:
    nearby = null
    var best := 5.5
    for item in trees + stones + loot_containers:
        if not is_instance_valid(item):
            continue
        var distance := player.global_position.distance_to(item.global_position)
        if distance < best:
            best = distance
            nearby = item
    if car and player.global_position.distance_to(car.global_position) < best:
        nearby = car

func _on_action() -> void:
    if in_car:
        _exit_car()
        return
    if not nearby or not is_instance_valid(nearby):
        _say("Подойди ближе к ресурсу или машине.")
        return
    if nearby == car:
        _enter_car()
        return
    if nearby in loot_containers:
        _loot_container(nearby)
        return
    if nearby.get_meta("kind") == "дерево":
        inventory["Дерево"] += randi_range(3, 6)
        trees.erase(nearby)
    else:
        inventory["Камень"] += randi_range(2, 5)
        stones.erase(nearby)
    var kind := str(nearby.get_meta("kind"))
    nearby.queue_free()
    nearby = null
    _refresh_inventory()
    _say("Собрано: %s. Смотри инвентарь сверху." % kind)

func _enter_car() -> void:
    in_car = true
    player.visible = false
    player.set_physics_process(false)
    player.global_position = car.global_position
    car.set_driver(player)
    player.set_vehicle_camera(true, car)
    _say("Ты сел в машину. Используй левый стик для езды.")

func _exit_car() -> void:
    in_car = false
    car.clear_driver()
    player.visible = true
    player.set_physics_process(true)
    player.global_position = car.global_position + car.global_transform.basis.x * 2.2 + Vector3.UP
    player.set_vehicle_camera(false, car)
    _say("Ты вышел из машины.")

func _craft() -> void:
    if inventory["Дерево"] >= 5 and inventory["Камень"] >= 3:
        inventory["Дерево"] -= 5
        inventory["Камень"] -= 3
        inventory["Инструменты"] += 1
        inventory["Волокно"] += 1
        _refresh_inventory()
        _say("Скрафчен инструмент (+1). Можно строить и собирать быстрее.")
    else:
        _say("Крафт: нужно 5 дерева и 3 камня. Сейчас: %d / %d" % [inventory["Дерево"], inventory["Камень"]])

func _build_wall() -> void:
    if inventory["Дерево"] < 12:
        _say("Для стены нужно 12 дерева.")
        return
    inventory["Дерево"] -= 12
    var wall := StaticBody3D.new()
    wall.position = player.global_position - player.global_transform.basis.z * 3
    wall.position.y = 1.2
    wall.rotation.y = player.rotation.y
    var mesh := MeshInstance3D.new()
    var cube := BoxMesh.new()
    cube.size = Vector3(3, 2.4, 0.35)
    mesh.mesh = cube
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.4, 0.25, 0.13)
    mesh.material_override = mat
    wall.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = cube.size
    collision.shape = shape
    wall.add_child(collision)
    add_child(wall)
    _refresh_inventory()
    _say("Стена построена перед тобой. Осталось дерева: %d" % inventory["Дерево"])

func _refresh_inventory() -> void:
    if inventory_label:
        inventory_label.text = "ИНВЕНТАРЬ\nДерево: %d | Камень: %d | Волокно: %d\nСкрап: %d | Инстр: %d | Бур: %d | Оружие: %d\nКрафт: 5 дерева + 3 камня → инструмент\nСтена: 12 дерева" % [inventory["Дерево"], inventory["Камень"], inventory["Волокно"], inventory["Скрап"], inventory["Инструменты"], inventory["Бур"], inventory["Оружие"]]

func _say(text: String) -> void:
    message_label.text = text
    get_tree().create_timer(2.5).timeout.connect(func(): message_label.text = "")
