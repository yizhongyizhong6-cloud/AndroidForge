extends CharacterBody3D

var game: Node
@export var move_speed := 8.0
var look_sensitivity := 0.012
var gravity := 28.0
var yaw := 0.0
var pitch := -0.2
var touch_look_id := -1
var previous_touch := Vector2.ZERO
var move_input := Vector2.ZERO
var dpad_input := Vector2.ZERO
var joystick_origin := Vector2.ZERO
var joystick_touch_id := -1
var joystick_radius := 100.0
var camera: Camera3D
var vehicle_camera := false
var target_car: Node3D

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	floor_snap_length = 0.5
	floor_max_angle = deg_to_rad(55.0)

	for action in ["move_forward", "move_back", "move_left", "move_right"]:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
	_add_default_key("move_forward", KEY_W)
	_add_default_key("move_back", KEY_S)
	_add_default_key("move_left", KEY_A)
	_add_default_key("move_right", KEY_D)

	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.4
	capsule.height = 1.7
	collision.shape = capsule
	collision.position.y = 0.95
	add_child(collision)

	var body_vis := MeshInstance3D.new()
	var body_mesh := CapsuleMesh.new()
	body_mesh.radius = 0.4
	body_mesh.height = 1.7
	body_vis.mesh = body_mesh
	body_vis.position.y = 0.95
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.2, 0.55, 0.95)
	body_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	body_vis.material_override = body_mat
	add_child(body_vis)

	var head := MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.3
	head_mesh.height = 0.6
	head.mesh = head_mesh
	head.position.y = 2.1
	var head_mat := StandardMaterial3D.new()
	head_mat.albedo_color = Color(0.95, 0.8, 0.6)
	head_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	head.material_override = head_mat
	add_child(head)

	camera = Camera3D.new()
	camera.name = "PlayerCamera"
	camera.position = Vector3(0, 2.6, 7.0)
	camera.rotation.x = -0.25
	camera.current = true
	camera.far = 600.0
	camera.near = 0.05
	add_child(camera)

func _add_default_key(action: String, keycode: Key) -> void:
	for e in InputMap.action_get_events(action):
		if e is InputEventKey and e.physical_keycode == keycode:
			return
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)

func set_sensitivity(value: float) -> void:
	look_sensitivity = clampf(value, 0.002, 0.05)

func set_vehicle_camera(enabled: bool, vehicle: Node3D) -> void:
	vehicle_camera = enabled
	target_car = vehicle if enabled else null

func add_dpad(dir: Vector2) -> void:
	dpad_input += dir
	dpad_input.x = clampf(dpad_input.x, -1.0, 1.0)
	dpad_input.y = clampf(dpad_input.y, -1.0, 1.0)

func remove_dpad(dir: Vector2) -> void:
	dpad_input -= dir
	if absf(dpad_input.x) < 0.1:
		dpad_input.x = 0.0
	if absf(dpad_input.y) < 0.1:
		dpad_input.y = 0.0

func get_move_input() -> Vector2:
	if dpad_input.length() > 0.1:
		return dpad_input
	var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if keyboard.length() > 0.1:
		return keyboard
	return move_input

func _physics_process(delta: float) -> void:
	if vehicle_camera and is_instance_valid(target_car):
		camera.global_position = target_car.global_position + target_car.global_transform.basis.z * 9.0 + Vector3(0, 4.0, 0)
		camera.look_at(target_car.global_position + Vector3(0, 1.2, 0), Vector3.UP)
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = 0.0

	var input_dir := get_move_input()
	var forward := -global_transform.basis.z
	var right := global_transform.basis.x
	var direction := right * input_dir.x + forward * -input_dir.y
	if direction.length() > 0.05:
		direction = direction.normalized()
		velocity.x = direction.x * move_speed
		velocity.z = direction.z * move_speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, move_speed * 10.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, move_speed * 10.0 * delta)

	move_and_slide()

func _input(event: InputEvent) -> void:
	# Use _input so touches work even if something is in the tree; ignore if over D-pad handled by buttons
	if event is InputEventScreenTouch:
		if event.pressed:
			var vp := get_viewport().get_visible_rect().size
			# Left half = walk stick, but skip bottom-left D-pad zone
			var in_dpad_zone := event.position.x < 260 and event.position.y > vp.y - 300
			if event.position.x < vp.x * 0.45 and not in_dpad_zone and joystick_touch_id == -1:
				joystick_touch_id = event.index
				joystick_origin = event.position
				_update_stick(event.position)
			elif event.position.x >= vp.x * 0.45:
				touch_look_id = event.index
				previous_touch = event.position
		else:
			if event.index == joystick_touch_id:
				joystick_touch_id = -1
				move_input = Vector2.ZERO
			if event.index == touch_look_id:
				touch_look_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joystick_touch_id:
			_update_stick(event.position)
		elif event.index == touch_look_id:
			var d := event.position - previous_touch
			yaw -= d.x * look_sensitivity
			pitch = clampf(pitch - d.y * look_sensitivity, -0.9, 0.4)
			rotation.y = yaw
			if camera:
				camera.rotation.x = pitch
			previous_touch = event.position

func _update_stick(pos: Vector2) -> void:
	var delta := pos - joystick_origin
	if delta.length() > joystick_radius:
		delta = delta.normalized() * joystick_radius
	move_input = Vector2(delta.x, delta.y) / joystick_radius
