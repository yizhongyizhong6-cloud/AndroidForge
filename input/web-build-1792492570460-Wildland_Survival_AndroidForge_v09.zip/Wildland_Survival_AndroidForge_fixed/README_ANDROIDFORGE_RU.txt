Wildland: Survival v0.5 — AndroidForge

Исправления синего экрана после «Играть»:
- noCompress для .gd / .tscn (сжатые скрипты часто не грузятся)
- материал земли и игрока UNSHADED (лучше видно на GLES)
- игрок спавнится выше (y=2), не в земле
- аварийная камера, если player.gd не создал Camera3D

Сборка: debug APK через AndroidForge.
