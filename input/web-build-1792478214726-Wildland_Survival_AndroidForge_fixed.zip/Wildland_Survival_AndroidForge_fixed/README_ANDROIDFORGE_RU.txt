Wildland: Survival v0.4 — пакет для AndroidForge (исправленный)

Что исправлено относительно предыдущей версии:
- добавлен aaptOptions (Godot hidden assets не отбрасываются)
- манифест: OpenGL ES 3, landscape, hardwareAccelerated, extractNativeLibs
- тема AppCompat fullscreen
- иконка приложения (vector drawable)
- strings/themes
- gradle-wrapper (скрипты + properties; jar если скачался)
- убраны лишние файлы из assets (export_presets, README) — в assets только Godot-проект

Структура:
  settings.gradle, build.gradle, gradle.properties
  app/build.gradle  → org.godotengine:godot:4.3.0.stable
  app/src/main/assets/project.godot + scenes + scripts
  MainActivity extends GodotActivity

Загрузка в AndroidForge:
1. Залей этот ZIP целиком
2. Собери debug (assembleDebug)
3. Скачай APK

Если сборка упадёт на wrapper — AndroidForge обычно сам ставит Gradle.
Если упадёт на зависимости — проверь лог по org.godotengine:godot:4.3.0.stable.

Скрипты игры (game.gd, player.gd, car.gd) не менялись.
