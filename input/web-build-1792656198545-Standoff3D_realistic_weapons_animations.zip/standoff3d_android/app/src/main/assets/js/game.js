/* ============================================================
   STANDOFF 3D — движок (Three.js r128)
   ============================================================ */
(function(){
'use strict';

// ---------- DOM ----------
const wrapper = document.getElementById('game-wrapper');
const container = document.getElementById('game-container');
const $ = id => document.getElementById(id);
const fpsVal=$('fps-val'), frameTimeEl=$('frame-time'), entityCount=$('entity-count');
const hpVal=$('hp-val'), armorVal=$('armor-val'), ammoCur=$('ammo-cur'), ammoMax=$('ammo-max');
const scoreCtEl=$('score-ct'), scoreTrEl=$('score-tr');
const killFeedEl=$('kill-feed'), vignette=$('damage-vignette'), scopeEl=$('sniper-scope');
const hitmarkerEl=$('hitmarker'), crosshairEl=$('crosshair');
const minimap=$('minimap'), mmCtx=minimap.getContext('2d');
const fpsGraph=$('fps-graph'), fgCtx=fpsGraph.getContext('2d');

// ---------- AUDIO (синтез, без ассетов) ----------
let AC=null;
function audio(){ if(!AC){ try{ AC=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } if(AC && AC.state==='suspended') AC.resume(); return AC; }
function sfxShot(pitch){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime, len=Math.floor(ac.sampleRate*0.11);
    const buf=ac.createBuffer(1,len,ac.sampleRate), d=buf.getChannelData(0);
    for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/len,2);
    const src=ac.createBufferSource(); src.buffer=buf;
    const f=ac.createBiquadFilter(); f.type='lowpass'; f.frequency.value=pitch;
    const g=ac.createGain(); g.gain.setValueAtTime(0.22,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.12);
    src.connect(f); f.connect(g); g.connect(ac.destination); src.start(t);
}
function sfxHit(){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime;
    const o=ac.createOscillator(), g=ac.createGain();
    o.type='square'; o.frequency.setValueAtTime(900,t); o.frequency.exponentialRampToValueAtTime(300,t+0.06);
    g.gain.setValueAtTime(0.12,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.07);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t+0.08);
}
function sfxDie(){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime;
    const o=ac.createOscillator(), g=ac.createGain();
    o.type='sawtooth'; o.frequency.setValueAtTime(220,t); o.frequency.exponentialRampToValueAtTime(60,t+0.35);
    g.gain.setValueAtTime(0.18,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.4);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t+0.45);
}

// ---------- THREE: сцена ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0f16);
scene.fog = new THREE.Fog(0x0b0f16, 45, 120);

const camera = new THREE.PerspectiveCamera(75, innerWidth/innerHeight, 0.08, 400);
camera.rotation.order='YXZ';
scene.add(camera);

const renderer = new THREE.WebGLRenderer({ antialias: !('ontouchstart' in window), powerPreference:'high-performance' });
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
// Улучшенная цветопередача и контраст материалов (сохраняем совместимость с Three.js r128).
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.domElement.style.position='absolute';
renderer.domElement.style.inset='0';
renderer.domElement.style.zIndex='1';
container.insertBefore(renderer.domElement, container.firstChild);

const hemi = new THREE.HemisphereLight(0x9db8e8, 0x2a241c, 0.6);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe9c4, 1.05);
sun.position.set(35, 55, 25);
sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left=-45; sun.shadow.camera.right=45;
sun.shadow.camera.top=45; sun.shadow.camera.bottom=-45;
sun.shadow.camera.far=140;
scene.add(sun);

// ---------- КАРТА ----------
const WORLD = 30; // полуразмер арены
const colliders = [];   // {minX,maxX,minZ,maxZ,minY,maxY}
const wallMeshes = [];  // для рейкастов
const mapObjects = [];  // геометрия текущей карты

// Процедурные текстуры: создаются локально, без скачивания картинок и без тяжёлых ассетов.
const surfaceTextures = {};
function makeSurfaceTexture(kind){
    if(surfaceTextures[kind]) return surfaceTextures[kind];
    const cv=document.createElement('canvas'); cv.width=512; cv.height=512;
    const cx=cv.getContext('2d');
    if(kind==='concrete'){
        cx.fillStyle='#77766e'; cx.fillRect(0,0,512,512);
        for(let i=0;i<9000;i++){ const x=Math.random()*512,y=Math.random()*512,a=0.025+Math.random()*0.12; cx.fillStyle=Math.random()>.5?`rgba(235,230,210,${a})`:`rgba(20,24,26,${a})`; cx.fillRect(x,y,1+Math.random()*3,1+Math.random()*2); }
        cx.strokeStyle='rgba(25,29,30,.22)'; cx.lineWidth=2;
        for(let y=0;y<512;y+=128){cx.beginPath();cx.moveTo(0,y);cx.lineTo(512,y);cx.stroke();}
        for(let x=0;x<512;x+=128){cx.beginPath();cx.moveTo(x,0);cx.lineTo(x,512);cx.stroke();}
    } else if(kind==='crate'){
        cx.fillStyle='#98784b'; cx.fillRect(0,0,512,512);
        for(let y=12;y<512;y+=58){cx.fillStyle='rgba(43,29,15,.16)';cx.fillRect(0,y,512,4);cx.fillStyle='rgba(235,196,129,.13)';cx.fillRect(0,y+5,512,2);}
        for(let i=0;i<2600;i++){cx.fillStyle=Math.random()>.5?'rgba(30,22,13,.10)':'rgba(255,225,170,.09)';cx.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*8,1+Math.random()*2);}
        cx.strokeStyle='rgba(35,25,14,.55)';cx.lineWidth=8;cx.strokeRect(8,8,496,496);cx.lineWidth=3;cx.strokeRect(20,20,472,472);
    } else {
        cx.fillStyle='#85847d';cx.fillRect(0,0,512,512);
        for(let i=0;i<6500;i++){let a=.02+Math.random()*.10;cx.fillStyle=Math.random()>.5?`rgba(255,255,255,${a})`:`rgba(10,12,14,${a})`;cx.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*2,1+Math.random()*2);}
        cx.strokeStyle='rgba(20,24,28,.12)';cx.lineWidth=2;for(let y=64;y<512;y+=64){cx.beginPath();cx.moveTo(0,y);cx.lineTo(512,y);cx.stroke();}
    }
    const tex=new THREE.CanvasTexture(cv); tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.anisotropy= Math.min(8, renderer.capabilities.getMaxAnisotropy()); tex.encoding=THREE.sRGBEncoding; tex.needsUpdate=true;
    surfaceTextures[kind]=tex; return tex;
}
function addBox(x, z, w, h, d, color, opts){
    opts = opts || {};
    const isCrate = color===0x6b5432 || color===0x77603a || color===0x5c4a2e;
    const tex=makeSurfaceTexture(isCrate?'crate':'concrete');
    const m = new THREE.Mesh(
        new THREE.BoxGeometry(w,h,d),
        new THREE.MeshStandardMaterial({ color: color, map:tex, roughness: opts.rough!=null?opts.rough:0.88, metalness:0.03 })
    );
    m.position.set(x, opts.y!=null?opts.y:h/2, z);
    m.castShadow = true; m.receiveShadow = true;
    scene.add(m); mapObjects.push(m);
    colliders.push({ minX:x-w/2, maxX:x+w/2, minZ:z-d/2, maxZ:z+d/2, minY:(opts.y!=null?opts.y:h/2)-h/2, maxY:(opts.y!=null?opts.y:h/2)+h/2 });
    wallMeshes.push(m);
    return m;
}

function buildMap(mapName){
    // Удаляем геометрию прошлой карты, не трогая игроков, оружие и эффекты.
    for(const obj of mapObjects){
        scene.remove(obj);
        if(obj.geometry) obj.geometry.dispose();
        if(obj.material){
            const mats=Array.isArray(obj.material)?obj.material:[obj.material];
            mats.forEach(m=>m.dispose());
        }
    }
    mapObjects.length=0; colliders.length=0; wallMeshes.length=0;

    const floorColors={arena:0x8d918e,dust:0xc2a77b,mirage:0xb6a58a};
    const groundTex=makeSurfaceTexture('floor');
    groundTex.repeat.set(12,12);
    const ground = new THREE.Mesh(
        new THREE.PlaneGeometry(WORLD*2+4, WORLD*2+4),
        new THREE.MeshStandardMaterial({ color:floorColors[mapName]||floorColors.arena, map:groundTex, roughness:0.96, metalness:0.01 })
    );
    ground.rotation.x=-Math.PI/2; ground.receiveShadow=true; scene.add(ground); mapObjects.push(ground);
    const grid = new THREE.GridHelper(WORLD*2, WORLD, 0x3d4a5c, 0x2c3542);
    grid.position.y=0.01; scene.add(grid); mapObjects.push(grid);

    const wallColor=mapName==='dust'?0x9a835f:(mapName==='mirage'?0xb0a18b:0x39424f);
    addBox(0, -WORLD-0.5, WORLD*2+4, 5, 1, wallColor);
    addBox(0,  WORLD+0.5, WORLD*2+4, 5, 1, wallColor);
    addBox(-WORLD-0.5, 0, 1, 5, WORLD*2+4, wallColor);
    addBox( WORLD+0.5, 0, 1, 5, WORLD*2+4, wallColor);

    if(mapName==='dust'){
        // Карта в духе классических пустынных соревновательных арен: длинный мид,
        // две открытые площадки и обходные проходы. Геометрия сделана заново.
        const stone=0xb7a078, dark=0x8b7455, crate=0x6b5432;
        addBox(0,0,2.0,3.2,25,stone);                 // длинная центральная линия
        addBox(-11,-15,12,3.4,2.0,stone); addBox(-11,-6,2.0,3.4,16,stone);
        addBox(-19,-2,8,3.4,2.0,dark); addBox(-22,5,2.0,3.4,13,stone);
        addBox(11,15,12,3.4,2.0,stone); addBox(11,6,2.0,3.4,16,stone);
        addBox(19,2,8,3.4,2.0,dark); addBox(22,-5,2.0,3.4,13,stone);
        addBox(-8,22,9,2.2,1.5,crate); addBox(8,-22,9,2.2,1.5,crate);
        addBox(-15,20,3,1.4,3,crate); addBox(15,-20,3,1.4,3,crate);
        addBox(0,-12,5,1.6,2,crate); addBox(0,12,5,1.6,2,crate);
        addBox(-4,4,2,2.0,2,crate); addBox(4,-4,2,2.0,2,crate);
    } else if(mapName==='mirage'){
        // Оригинальная компактная карта с центральной площадью, арками и боковыми маршрутами,
        // вдохновлённая городской пустынной эстетикой, без копирования игровых ассетов.
        const plaster=0xc1ad8f, shade=0x82745f, crate=0x6b5432;
        addBox(-12,0,2.2,4.2,26,plaster); addBox(12,0,2.2,4.2,26,plaster);
        addBox(0,-12,22,3.6,2.2,plaster); addBox(0,12,22,3.6,2.2,plaster);
        addBox(-5,0,2.0,2.4,8,shade); addBox(5,0,2.0,2.4,8,shade);
        addBox(0,-4,7,2.0,1.5,crate); addBox(0,4,7,2.0,1.5,crate);
        addBox(-19,-17,10,3.2,2.0,plaster); addBox(-23,-10,2.0,3.2,14,plaster);
        addBox(19,17,10,3.2,2.0,plaster); addBox(23,10,2.0,3.2,14,plaster);
        addBox(-17,10,4,1.7,3,crate); addBox(17,-10,4,1.7,3,crate);
        addBox(-7,21,5,1.4,2,crate); addBox(7,-21,5,1.4,2,crate);
        addBox(-20,0,3,2.2,3,crate); addBox(20,0,3,2.2,3,crate);
    } else {
        // Исходная арена.
        addBox(0, 0, 10, 2.6, 1.2, 0x4a4038);
        addBox(-12, -10, 2, 2.2, 2, 0x6b5432);
        addBox(-9.2, -10.5, 1.6, 1.4, 1.6, 0x77603a);
        addBox(12, -12, 2, 2.2, 2, 0x6b5432);
        addBox(9, 12, 2.4, 2.2, 2.4, 0x6b5432);
        addBox(-11, 11, 2, 2.2, 2, 0x6b5432);
        addBox(-13, 13.2, 1.5, 1.3, 1.5, 0x77603a);
        addBox(0, -18, 6, 2.4, 1, 0x4a5568);
        addBox(0, 18, 6, 2.4, 1, 0x4a5568);
        addBox(-20, 0, 1, 2.6, 8, 0x4a5568);
        addBox(20, 2, 1, 2.6, 8, 0x4a5568);
        addBox(16, -4, 3, 1.6, 3, 0x5c4a2e);
        addBox(-16, 5, 3, 1.6, 3, 0x5c4a2e);
    }
    // Small visual accents; decorative meshes are tracked so switching maps cleans them up.
    const stripMat = new THREE.MeshBasicMaterial({ color:mapName==='dust'?0xffc16c:(mapName==='mirage'?0xf0d5a1:0xff8c00) });
    const accents = mapName==='arena' ? [[0,-0.72,10.4,0.06],[0,0.72,10.4,0.06]] : [[-7,0,0.08,12],[7,0,0.08,12]];
    accents.forEach(a=>{
        const st=new THREE.Mesh(new THREE.BoxGeometry(a[2],0.06,a[3]||0.06), stripMat);
        st.position.set(a[0], mapName==='arena'?2.65:0.035, a[1]); scene.add(st); mapObjects.push(st);
    });
}
let currentMap='arena';
buildMap(currentMap);

// ---------- ИГРОК ----------
const player = {
    pos: new THREE.Vector3(0, 0, 24),
    vel: new THREE.Vector3(),
    yaw: 0, pitch: 0,
    hp: 100, armor: 100,
    crouch: false, onGround: true,
    alive: true, eyeH: 1.7
};

// ---------- ОРУЖИЕ ----------
const WEAPONS = {
    // --- PISTOLS ---
    4:  { name:'Glock-18',   cat:'pistol',  price:0,    dmg:26, rpm:400, mag:20, reserve:120, auto:false, reloadTime:1500, aimFov:62, spread:0.016, recoil:0.009, scoped:false, snd:2600 },
    5:  { name:'USP-S',      cat:'pistol',  price:200,  dmg:33, rpm:352, mag:12, reserve:24,  auto:false, reloadTime:1600, aimFov:62, spread:0.012, recoil:0.008, scoped:false, snd:2400 },
    6:  { name:'P250',       cat:'pistol',  price:300,  dmg:35, rpm:400, mag:13, reserve:26,  auto:false, reloadTime:1500, aimFov:62, spread:0.014, recoil:0.011, scoped:false, snd:2500 },
    7:  { name:'Five-SeveN', cat:'pistol',  price:500,  dmg:31, rpm:400, mag:20, reserve:100, auto:false, reloadTime:1600, aimFov:62, spread:0.013, recoil:0.009, scoped:false, snd:2550 },
    8:  { name:'Tec-9',      cat:'pistol',  price:500,  dmg:30, rpm:500, mag:18, reserve:90,  auto:false, reloadTime:1700, aimFov:62, spread:0.018, recoil:0.012, scoped:false, snd:2300 },
    9:  { name:'CZ75-Auto',  cat:'pistol',  price:500,  dmg:31, rpm:600, mag:12, reserve:12,  auto:true,  reloadTime:1800, aimFov:62, spread:0.017, recoil:0.014, scoped:false, snd:2450 },
    10: { name:'Dualies',    cat:'pistol',  price:300,  dmg:36, rpm:500, mag:30, reserve:120, auto:false, reloadTime:2800, aimFov:62, spread:0.022, recoil:0.013, scoped:false, snd:2500 },
    11: { name:'Deagle',     cat:'pistol',  price:700,  dmg:63, rpm:267, mag:7,  reserve:35,  auto:false, reloadTime:2000, aimFov:58, spread:0.012, recoil:0.028, scoped:false, snd:1100 },
    12: { name:'R8 Revolver',cat:'pistol',  price:600,  dmg:80, rpm:150, mag:8,  reserve:8,   auto:false, reloadTime:2200, aimFov:58, spread:0.010, recoil:0.040, scoped:false, snd:900  },
    // --- SMG ---
    20: { name:'MAC-10',     cat:'smg',     price:1050, dmg:28, rpm:800, mag:30, reserve:100, auto:true,  reloadTime:1800, aimFov:60, spread:0.022, recoil:0.010, scoped:false, snd:2400 },
    21: { name:'MP9',        cat:'smg',     price:1250, dmg:26, rpm:857, mag:30, reserve:120, auto:true,  reloadTime:1700, aimFov:60, spread:0.018, recoil:0.008, scoped:false, snd:2500 },
    22: { name:'MP7',        cat:'smg',     price:1500, dmg:28, rpm:750, mag:30, reserve:120, auto:true,  reloadTime:1900, aimFov:60, spread:0.016, recoil:0.009, scoped:false, snd:2450 },
    23: { name:'UMP-45',     cat:'smg',     price:1200, dmg:33, rpm:666, mag:25, reserve:100, auto:true,  reloadTime:2000, aimFov:60, spread:0.017, recoil:0.011, scoped:false, snd:2200 },
    24: { name:'P90',        cat:'smg',     price:2350, dmg:25, rpm:857, mag:50, reserve:100, auto:true,  reloadTime:2300, aimFov:58, spread:0.015, recoil:0.008, scoped:false, snd:2550 },
    25: { name:'PP-Bizon',   cat:'smg',     price:1400, dmg:26, rpm:700, mag:64, reserve:120, auto:true,  reloadTime:2100, aimFov:60, spread:0.019, recoil:0.009, scoped:false, snd:2300 },
    26: { name:'MP5-SD',     cat:'smg',     price:1500, dmg:26, rpm:750, mag:30, reserve:120, auto:true,  reloadTime:2000, aimFov:60, spread:0.015, recoil:0.008, scoped:false, snd:1800 },
    // --- RIFLES ---
    1:  { name:'AK-47',      cat:'rifle',   price:2700, dmg:36, rpm:600, mag:30, reserve:90,  auto:true,  reloadTime:2200, aimFov:55, spread:0.013, recoil:0.015, scoped:false, snd:1750 },
    2:  { name:'M4A4',       cat:'rifle',   price:3100, dmg:33, rpm:666, mag:30, reserve:90,  auto:true,  reloadTime:2100, aimFov:55, spread:0.011, recoil:0.012, scoped:false, snd:2200 },
    30: { name:'M4A1-S',     cat:'rifle',   price:2900, dmg:33, rpm:600, mag:20, reserve:80,  auto:true,  reloadTime:2100, aimFov:55, spread:0.010, recoil:0.010, scoped:false, snd:1900 },
    31: { name:'FAMAS',      cat:'rifle',   price:2050, dmg:30, rpm:666, mag:25, reserve:90,  auto:true,  reloadTime:2200, aimFov:56, spread:0.013, recoil:0.012, scoped:false, snd:2100 },
    32: { name:'Galil AR',   cat:'rifle',   price:1800, dmg:30, rpm:666, mag:35, reserve:90,  auto:true,  reloadTime:2200, aimFov:56, spread:0.014, recoil:0.013, scoped:false, snd:2000 },
    33: { name:'AUG',        cat:'rifle',   price:3300, dmg:33, rpm:600, mag:30, reserve:90,  auto:true,  reloadTime:2300, aimFov:40, spread:0.009, recoil:0.010, scoped:true,  snd:2150 },
    34: { name:'SG 553',     cat:'rifle',   price:3000, dmg:35, rpm:545, mag:30, reserve:90,  auto:true,  reloadTime:2300, aimFov:40, spread:0.010, recoil:0.013, scoped:true,  snd:1950 },
    // --- SNIPERS ---
    3:  { name:'AWP',        cat:'sniper',  price:4750, dmg:115,rpm:41,  mag:5,  reserve:30,  auto:false, reloadTime:3200, aimFov:18, spread:0.001, recoil:0.055, scoped:true,  snd:900  },
    40: { name:'SSG 08',     cat:'sniper',  price:1700, dmg:88, rpm:48,  mag:10, reserve:90,  auto:false, reloadTime:2800, aimFov:22, spread:0.002, recoil:0.035, scoped:true,  snd:1200 },
    41: { name:'SCAR-20',    cat:'sniper',  price:5000, dmg:80, rpm:240, mag:20, reserve:90,  auto:true,  reloadTime:3000, aimFov:20, spread:0.004, recoil:0.025, scoped:true,  snd:1600 },
    42: { name:'G3SG1',      cat:'sniper',  price:5000, dmg:80, rpm:240, mag:20, reserve:90,  auto:true,  reloadTime:3200, aimFov:20, spread:0.004, recoil:0.026, scoped:true,  snd:1500 },
    // --- SHOTGUNS ---
    50: { name:'Nova',       cat:'shotgun', price:1050, dmg:22, rpm:68,  mag:8,  reserve:32,  auto:false, reloadTime:3000, aimFov:60, spread:0.045, recoil:0.035, scoped:false, snd:1400, pellets:8 },
    51: { name:'XM1014',     cat:'shotgun', price:2000, dmg:20, rpm:171, mag:7,  reserve:32,  auto:true,  reloadTime:2800, aimFov:60, spread:0.050, recoil:0.030, scoped:false, snd:1500, pellets:6 },
    52: { name:'MAG-7',      cat:'shotgun', price:1300, dmg:28, rpm:71,  mag:5,  reserve:32,  auto:false, reloadTime:2400, aimFov:60, spread:0.040, recoil:0.038, scoped:false, snd:1350, pellets:9 },
    53: { name:'Sawed-Off',  cat:'shotgun', price:1100, dmg:30, rpm:71,  mag:7,  reserve:32,  auto:false, reloadTime:2800, aimFov:60, spread:0.055, recoil:0.040, scoped:false, snd:1300, pellets:8 },
    // --- LMG ---
    60: { name:'M249',       cat:'lmg',     price:5200, dmg:32, rpm:750, mag:100,reserve:200, auto:true,  reloadTime:4500, aimFov:55, spread:0.018, recoil:0.016, scoped:false, snd:2000 },
    61: { name:'Negev',      cat:'lmg',     price:1700, dmg:35, rpm:800, mag:150,reserve:300, auto:true,  reloadTime:5000, aimFov:55, spread:0.022, recoil:0.018, scoped:false, snd:1900 },
    // --- MELEE ---
    70: { name:'Knife',      cat:'melee',   price:0,    dmg:55, rpm:120, mag:1,  reserve:0,   auto:false, reloadTime:0,    aimFov:70, spread:0,    recoil:0,    scoped:false, snd:800,  melee:true }
};
const wstate = {};
for (const k in WEAPONS){ wstate[k]={ ammo:WEAPONS[k].mag, reserve:WEAPONS[k].reserve }; }
let owned = { 4:true, 70:true }; // Glock + Knife
let playerMoney = 800;
let curWeapon = 4, lastShot = 0, reloading = false, reloadTimer = null;

let aiming = false, fireHeld = false, bloom = 0;
let sensitivity = 1.0;

// viewmodel оружия (примитивы)
const gunGroup = new THREE.Group();
camera.add(gunGroup);
const muzzleLight = new THREE.PointLight(0xffb347, 0, 9);
muzzleLight.position.set(0.15,-0.1,-1.0);
camera.add(muzzleLight);

// Анимация оружия: отдача, затвор, магазин и перезарядка.
let gunKick = { x:0, y:0, z:0 }, gunBob = 0, gunSway = 0;
let weaponAnim = { bolt:null, magazine:null, magazineBaseY:0, slide:null, pump:null };
let reloadStartedAt = 0, reloadDuration = 0;
function buildGun(slot){
    while(gunGroup.children.length){
        const child=gunGroup.children[0]; gunGroup.remove(child);
        child.traverse(o=>{ if(o.geometry) o.geometry.dispose(); });
    }
    weaponAnim = { bolt:null, magazine:null, magazineBaseY:0, slide:null, pump:null };
    const W = WEAPONS[slot] || WEAPONS[4];
    const metal = new THREE.MeshStandardMaterial({color:0x343b43, roughness:0.28, metalness:0.88});
    const dark = new THREE.MeshStandardMaterial({color:0x151a20, roughness:0.48, metalness:0.55});
    const polymer = new THREE.MeshStandardMaterial({color:0x242a30, roughness:0.82, metalness:0.12});
    const rubber = new THREE.MeshStandardMaterial({color:0x111519, roughness:0.98, metalness:0.02});
    const wood = new THREE.MeshStandardMaterial({color:0x704321, roughness:0.72, metalness:0.04});
    const accent = new THREE.MeshStandardMaterial({color:0x8d9aa5, roughness:0.3, metalness:0.9});
    const brass = new THREE.MeshStandardMaterial({color:0xb48a42, roughness:0.3, metalness:0.8});
    const g=gunGroup, cat=W.cat||'rifle';
    const box=(parent, size, mat, x,y,z, rx=0,ry=0,rz=0)=>{
        const m=new THREE.Mesh(new THREE.BoxGeometry(size[0],size[1],size[2]),mat);
        m.position.set(x,y,z); m.rotation.set(rx,ry,rz); m.castShadow=true; m.receiveShadow=true; parent.add(m); return m;
    };
    const cyl=(parent, r1,r2,len,mat,x,y,z,segments=12)=>{
        const m=new THREE.Mesh(new THREE.CylinderGeometry(r1,r2,len,segments),mat);
        m.position.set(x,y,z); m.rotation.x=Math.PI/2; m.castShadow=true; parent.add(m); return m;
    };
    const partGroup=(parent,x=0,y=0,z=0)=>{const q=new THREE.Group();q.position.set(x,y,z);parent.add(q);return q;};
    const detailScrew=(x,y,z)=>{
        const m=new THREE.Mesh(new THREE.CylinderGeometry(0.006,0.006,0.004,8),accent);
        m.position.set(x,y,z);m.rotation.x=Math.PI/2;g.add(m);
    };
    if(cat==='melee'){
        box(g,[0.035,0.018,0.25],metal,0.02,-0.015,-0.28);
        box(g,[0.028,0.04,0.085],rubber,0.02,-0.025,-0.12);
        box(g,[0.032,0.006,0.12],accent,0.02,-0.005,-0.36);
        box(g,[0.05,0.015,0.025],dark,0.02,-0.015,-0.14);
    } else if(cat==='pistol'){
        // Затвор, рамка, спусковая скоба, рукоять и сменный магазин.
        const slide=partGroup(g,0,0,0); weaponAnim.slide=slide; weaponAnim.bolt=slide;
        box(slide,[0.055,0.07,0.255],metal,0.02,0.025,-0.245);
        box(slide,[0.047,0.024,0.19],dark,0.02,0.069,-0.25);
        box(slide,[0.04,0.018,0.12],accent,0.02,0.076,-0.25);
        cyl(g,0.014,0.014,0.12,dark,0.02,0.025,-0.405,12);
        cyl(g,0.019,0.019,0.018,metal,0.02,0.025,-0.47,16);
        box(g,[0.045,0.12,0.075],polymer,0.02,-0.075,-0.13,0.18);
        box(g,[0.048,0.07,0.012],rubber,0.02,-0.075,-0.17,0.18);
        const mag=partGroup(g,0,-0.105,-0.17); weaponAnim.magazine=mag; weaponAnim.magazineBaseY=mag.position.y;
        box(mag,[0.033,0.085,0.045],dark,0,0.0,0.005,0.12);
        box(mag,[0.035,0.009,0.05],metal,0,-0.044,0.005,0.12);
        // Спуск и скоба
        box(g,[0.012,0.032,0.025],accent,0.02,-0.015,-0.205,0.2);
        box(g,[0.045,0.008,0.055],metal,0.02,-0.025,-0.205);
        box(g,[0.014,0.035,0.012],metal,0.02,0.08,-0.17);
        box(g,[0.014,0.035,0.012],metal,0.02,0.08,-0.335);
        detailScrew(0.049,0.025,-0.22); detailScrew(0.049,-0.05,-0.14);
        if(slot===11 || slot===12){
            box(g,[0.064,0.055,0.09],metal,0.02,0.022,-0.34);
            cyl(g,0.017,0.017,0.12,dark,0.02,0.022,-0.44,12);
        }
    } else {
        const sniper=cat==='sniper', shotgun=cat==='shotgun', smg=cat==='smg', lmg=cat==='lmg';
        const long=sniper?0.72:(shotgun?0.55:(lmg?0.64:(smg?0.42:0.52)));
        // Центральный ресивер и верхняя крышка
        box(g,[sniper?0.075:0.065, sniper?0.09:0.075, long],metal,0.02,0.012,-(sniper?0.49:(shotgun?0.38:0.39)));
        box(g,[0.052,0.022,long*0.78],dark,0.02,0.064,-(sniper?0.48:0.38));
        // Передняя часть, ствол и дульный тормоз
        const barrelLen=sniper?0.57:(shotgun?0.38:(lmg?0.42:0.36));
        cyl(g,sniper?0.019:0.014,sniper?0.021:0.016,barrelLen,metal,0.02,0.022,-(sniper?1.02:(shotgun?0.73:(lmg?0.89:0.82))),12);
        cyl(g,0.021,0.021,0.045,dark,0.02,0.022,-(sniper?1.32:(shotgun?0.94:(lmg?1.12:1.00))),16);
        cyl(g,0.015,0.015,0.008,accent,0.02,0.022,-(sniper?1.345:(shotgun?0.965:(lmg?1.145:1.025))),16);
        // Цевьё с вентиляционными прорезями
        box(g,[0.072,0.065,sniper?0.30:0.24],polymer,0.02,0.006,-(sniper?0.80:(shotgun?0.59:0.66)));
        for(let i=0;i<5;i++) box(g,[0.074,0.006,0.018],dark,0.02,0.015-i*0.002,-(sniper?0.69:0.58)+i*0.035);
        // Рукоять, спусковая скоба
        box(g,[0.047,0.135,0.07],rubber,0.02,-0.095,-0.24,0.16);
        box(g,[0.012,0.045,0.025],metal,0.02,-0.025,-0.285,0.18);
        box(g,[0.045,0.008,0.055],metal,0.02,-0.043,-0.28);
        // Магазин / короб / барабан
        const mag=partGroup(g,0,0,0); weaponAnim.magazine=mag; weaponAnim.magazineBaseY=mag.position.y;
        if(lmg){
            cyl(mag,0.052,0.06,0.12,dark,0.02,-0.07,-0.40,16);
            cyl(mag,0.046,0.052,0.012,metal,0.02,-0.07,-0.40,16);
        } else if(shotgun){
            cyl(g,0.022,0.022,0.34,metal,0.02,-0.035,-0.58,12);
            box(g,[0.06,0.05,0.16],wood,0.02,-0.01,-0.17);
            weaponAnim.pump=box(g,[0.055,0.05,0.13],wood,0.02,-0.025,-0.49);
        } else {
            const magLen=sniper?0.12:(smg?0.17:0.19);
            box(mag,[0.043,magLen,0.075],dark,0.02,-0.085,-0.34,0.12);
            box(mag,[0.045,0.012,0.078],metal,0.02,-0.085-magLen/2,-0.34,0.12);
            box(mag,[0.032,0.012,0.008],accent,0.02,-0.08,-0.30);
        }
        // Верхняя планка, целик и мушка
        box(g,[0.025,0.012,sniper?0.52:0.34],dark,0.02,0.078,-0.52);
        box(g,[0.045,0.026,0.025],metal,0.02,0.09,-0.27);
        box(g,[0.024,0.035,0.018],metal,0.02,0.095,-(sniper?0.91:0.77));
        box(g,[0.008,0.012,0.012],accent,0.02,0.114,-(sniper?0.91:0.77));
        // Прицел для снайперок
        if(sniper){
            const scope=partGroup(g,0.02,0.105,-0.53);
            cyl(scope,0.037,0.037,0.17,dark,0,0,0,16);
            cyl(scope,0.044,0.044,0.018,metal,0,0,-0.075,16);
            cyl(scope,0.044,0.044,0.018,metal,0,0,0.075,16);
            box(g,[0.045,0.015,0.16],dark,0.02,0.067,-0.53);
        }
        // Приклад, профиль зависит от семейства оружия
        if(!smg && !shotgun){
            const stockMat=slot===1?wood:polymer;
            box(g,[0.055,0.075,0.23],stockMat,0.02,-0.005,-0.105,0.04);
            box(g,[0.06,0.09,0.035],rubber,0.02,-0.005,0.005);
        } else if(smg){
            box(g,[0.045,0.045,0.16],polymer,0.02,0.005,-0.10);
        }
        // Болт/затвор на отдельной группе, чтобы двигался при выстреле
        const bolt=partGroup(g,0,0,0); weaponAnim.bolt=bolt;
        box(bolt,[0.018,0.018,0.09],accent,0.054,0.045,-0.36);
        box(bolt,[0.028,0.018,0.035],dark,0.054,0.045,-0.31);
        // Небольшие крепёжные элементы по бокам
        detailScrew(0.055,0.018,-0.28); detailScrew(0.055,0.018,-0.42);
        if(slot===1){
            box(g,[0.045,0.065,0.12],wood,0.02,-0.015,-0.12,0.06);
        }
        weaponAnim.slide=weaponAnim.bolt;
    }
    g.position.set(0.28,-0.24,-0.42);
    g.rotation.set(0.04,0.08,0.02);
    g.visible=true;
}
buildGun(4);

// ---------- КОМАНДЫ И БОТЫ ----------
const ALLY_COUNT = 4, ENEMY_COUNT = 5, KILL_LIMIT = 30;
const ALLY_NAMES  = ['Alex','Bravo','Cobra','Delta','Echo','Fox'];
const ENEMY_NAMES = ['Viper','Wolf','Ghost','Hawk','Rex','Nova','Jet','Lynx'];
// Режим и сторона игрока
const MODE = { TDM:'tdm', PLANT:'plant' };
let gameMode = MODE.TDM;
let playerSide = 'ct'; // ct = спецназ, t = террористы

function getTeamStyle(team){
    // ally = твоя сторона, enemy = противник
    const isT = playerSide === 't';
    if(team === 'ally'){
        return isT
            ? { body:0xb3401e, head:0xd9a066, tag:'#ff9966' }  // T
            : { body:0x2f6df0, head:0xd9a066, tag:'#38bdf8' }; // CT
    }
    return isT
        ? { body:0x2f6df0, head:0xd9a066, tag:'#7ec8ff' }  // враги CT
        : { body:0xb3401e, head:0xd9a066, tag:'#f87171' }; // враги T
}
const TEAMS = {
    get ally(){ return getTeamStyle('ally'); },
    get enemy(){ return getTeamStyle('enemy'); }
};
const SPAWNS = {
    ally:  [[-6,26],[-2,27],[2,27],[6,26],[10,25],[-10,25]],
    enemy: [[-6,-26],[-2,-27],[2,-27],[6,-26],[10,-25],[-10,-25],[14,-24],[-14,-24]]
};
function spawnListFor(team){
    // союзники на стороне игрока
    if(playerSide === 't') return team === 'ally' ? SPAWNS.enemy : SPAWNS.ally;
    return SPAWNS[team];
}
const BOMB_SITES = {
    arena:[{x:0,z:-12,r:3.5,name:'A'},{x:12,z:10,r:3.2,name:'B'}],
    dust:[{x:-15,z:-8,r:3.5,name:'A'},{x:15,z:8,r:3.5,name:'B'}],
    mirage:[{x:-10,z:10,r:3.2,name:'A'},{x:12,z:-8,r:3.2,name:'B'}]
};
let siteMarkers = [];
function clearSites(){
    siteMarkers.forEach(m=>{ try{ scene.remove(m); if(m.geometry) m.geometry.dispose(); }catch(e){} });
    siteMarkers = [];
}
function placeSites(){
    clearSites();
    if(gameMode !== MODE.PLANT) return;
    const sites = BOMB_SITES[currentMap] || BOMB_SITES.arena;
    sites.forEach(s=>{
        const ring = new THREE.Mesh(
            new THREE.RingGeometry(s.r*0.85, s.r, 32),
            new THREE.MeshBasicMaterial({ color:0xff8c00, transparent:true, opacity:0.35, side:THREE.DoubleSide })
        );
        ring.rotation.x = -Math.PI/2;
        ring.position.set(s.x, 0.05, s.z);
        scene.add(ring);
        siteMarkers.push(ring);
    });
}
player.name = 'Вы';
const bots = [];
let botIdSeq = 0, scoreCT = 0, scoreTR = 0, matchOver = false;

function pointInCollider(x,z,r){
    for(const c of colliders){
        if(x>c.minX-r && x<c.maxX+r && z>c.minZ-r && z<c.maxZ+r) return true;
    }
    return false;
}

function makeTag(name, color){
    const cv = document.createElement('canvas'); cv.width = 128; cv.height = 48;
    const g = cv.getContext('2d');
    g.font = 'bold 22px sans-serif'; g.textAlign = 'center';
    g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.85)'; g.strokeText(name, 64, 22);
    g.fillStyle = color; g.fillText(name, 64, 22);
    g.beginPath(); g.moveTo(54,30); g.lineTo(74,30); g.lineTo(64,44); g.closePath(); g.fill();
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map:new THREE.CanvasTexture(cv), depthTest:false, transparent:true }));
    spr.scale.set(1.3, 0.49, 1); spr.position.y = 2.35; spr.renderOrder = 10;
    return spr;
}

function spawnBot(team, name){
    const id = ++botIdSeq, T = TEAMS[team];
    const grp = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.34,0.42,1.05,10), new THREE.MeshStandardMaterial({ color:T.body, roughness:0.7 }));
    body.position.y = 0.85; body.castShadow = true;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23,12,10), new THREE.MeshStandardMaterial({ color:T.head, roughness:0.6 }));
    head.position.y = 1.62; head.castShadow = true;
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.3,0.08,0.1), new THREE.MeshStandardMaterial({ color:0x14181f }));
    visor.position.set(0,1.64,0.16);
    const gun = new THREE.Mesh(new THREE.BoxGeometry(0.07,0.08,0.55), new THREE.MeshStandardMaterial({ color:0x1c2129 }));
    gun.position.set(0.3,1.05,0.3);
    grp.add(body, head, visor, gun);
    if(team==='ally') grp.add(makeTag(name, T.tag));
    scene.add(grp);
    const bot = { id, name, team, grp, body, head, hp:100, dead:false, respawnT:0,
        target:new THREE.Vector3(), fireCd:1+Math.random(), strafe:Math.random()<0.5?1:-1, strafeT:0,
        checkT:Math.random()*0.4, enemy:null, enemyDist:99, stuckT:0, lastX:0, lastZ:0, slot:botIdSeq%6 };
    body.userData.bot = bot; body.userData.part = 'body';
    head.userData.bot = bot; head.userData.part = 'head';
    bots.push(bot);
    respawnBot(bot);
    return bot;
}

function respawnBot(bot){
    const list = spawnListFor(bot.team);
    let sp, tries = 0;
    do { sp = list[Math.floor(Math.random()*list.length)]; tries++; }
    while(tries<10 && bots.some(o=>o!==bot && !o.dead && Math.hypot(o.grp.position.x-sp[0], o.grp.position.z-sp[1])<1.4));
    bot.grp.position.set(sp[0]+(Math.random()-0.5), 0, sp[1]);
    bot.grp.rotation.y = (bot.team==='ally')
        ? (playerSide==='t' ? 0 : Math.PI)
        : (playerSide==='t' ? Math.PI : 0);
    bot.hp = 100; bot.dead = false; bot.enemy = null; bot.fireCd = 1+Math.random();
    bot.target.copy(bot.grp.position); bot.stuckT = 0;
    bot.grp.visible = true;
    try {
        const T = getTeamStyle(bot.team);
        if(bot.body && bot.body.material) bot.body.material.color.setHex(T.body);
        if(bot.head && bot.head.material) bot.head.material.color.setHex(T.head);
    } catch(e) {}
}

function enemyMeshes(){
    const out = [];
    for(const b of bots) if(b.team==='enemy' && !b.dead) out.push(b.body, b.head);
    return out;
}

function countAlive(team){ let n=0; for(const b of bots) if(b.team===team && !b.dead) n++; return n; }

function clearAllBots(){
    for(const b of bots){ try{ scene.remove(b.grp); }catch(e){} }
    bots.length = 0;
}
function createTeams(){
    clearAllBots();
    const an = ALLY_NAMES.slice().sort(()=>Math.random()-0.5), en = ENEMY_NAMES.slice().sort(()=>Math.random()-0.5);
    for(let i=0;i<ALLY_COUNT;i++)  spawnBot('ally',  an[i]);
    for(let i=0;i<ENEMY_COUNT;i++) spawnBot('enemy', en[i]);
    placeSites();
}

// ---------- ТРАССЕРЫ ----------
const tracers = [];
function spawnTracer(from, to, color){
    const geo = new THREE.BufferGeometry().setFromPoints([from, to]);
    const mat = new THREE.LineBasicMaterial({ color: color||0xffd27a, transparent:true, opacity:0.9 });
    const line = new THREE.Line(geo, mat);
    scene.add(line);
    tracers.push({ line, life:0.07 });
}

// ---------- СТРЕЛЬБА ----------
const raycaster = new THREE.Raycaster();
raycaster.far = 300;

function flashHitmarker(){
    hitmarkerEl.style.opacity='1';
    clearTimeout(flashHitmarker._t);
    flashHitmarker._t=setTimeout(()=>hitmarkerEl.style.opacity='0', 70);
}

function updateAmmoHUD(){
    const st = wstate[curWeapon];
    ammoCur.textContent = st.ammo;
    ammoMax.textContent = st.reserve;
    ammoCur.style.color = st.ammo===0 ? '#ff3b3b' : (st.ammo<=5 ? '#ff8c00' : '#fff');
}

function startReload(){
    const W = WEAPONS[curWeapon], st = wstate[curWeapon];
    if(reloading || st.ammo===W.mag || st.reserve<=0) return;
    reloading = true;
    reloadStartedAt = performance.now();
    reloadDuration = W.reloadTime;
    $('btn-reload').classList.add('active');
    setTimeout(()=>{},0);
    reloadTimer = setTimeout(()=>{
        const need = W.mag - st.ammo;
        const take = Math.min(need, st.reserve);
        st.ammo += take; st.reserve -= take;
        reloading = false;
        reloadStartedAt = 0; reloadDuration = 0;
        if(weaponAnim.magazine) weaponAnim.magazine.position.y=weaponAnim.magazineBaseY||0;
        if(weaponAnim.bolt) weaponAnim.bolt.position.z=0;
        if(weaponAnim.pump) weaponAnim.pump.position.z=-0.49;
        $('btn-reload').classList.remove('active');
        updateAmmoHUD();
    }, W.reloadTime);
}

function showBanner(html, ms){
    let el = $('team-banner');
    if(!el){
        el = document.createElement('div'); el.id = 'team-banner';
        el.style.cssText = 'position:absolute;left:50%;top:30%;transform:translate(-50%,-50%);z-index:60;pointer-events:none;text-align:center;font:900 34px sans-serif;letter-spacing:.12em;color:#fff;text-shadow:0 2px 12px #000;display:none';
        container.appendChild(el);
    }
    el.innerHTML = html; el.style.display = 'block';
    clearTimeout(showBanner._t); showBanner._t = setTimeout(()=>{ el.style.display='none'; }, ms||2500);
}

function addScore(team){
    if(team==='ally'){ scoreCT++; scoreCtEl.textContent = scoreCT; }
    else { scoreTR++; scoreTrEl.textContent = scoreTR; }
    if(!matchOver && (scoreCT>=KILL_LIMIT || scoreTR>=KILL_LIMIT)){
        matchOver = true;
        const win = scoreCT>=KILL_LIMIT;
        showBanner(win?'<span style="color:#4ade80">ПОБЕДА КОМАНДЫ</span>':'<span style="color:#f87171">ПОРАЖЕНИЕ</span>', 4500);
        setTimeout(resetMatch, 5000);
    }
}

function resetMatch(){
    scoreCT = scoreTR = 0; scoreCtEl.textContent = 0; scoreTrEl.textContent = 0;
    bots.forEach(respawnBot);
    respawnPlayer();
    matchOver = false;
}

function killBot(bot, attacker, headshot){
    bot.dead = true; bot.grp.visible = false; bot.enemy = null;
    bot.respawnT = 4 + Math.random()*2;
    const aTeam = attacker===player ? 'ally' : attacker.team;
    addScore(aTeam);
    addKillFeed(attacker.name, bot.name, attacker===player, headshot, aTeam, bot.team);
    if(attacker===player){ sfxDie(); playerMoney=Math.min(16000, playerMoney+300); updateMoneyHUD(); }
}

function damageBot(bot, dmg, part, attacker){
    if(bot.dead) return;
    if(bot.team==='ally' && attacker===player) return;
    if(attacker && attacker!==player && attacker.team===bot.team) return;
    bot.hp -= dmg;
    if(attacker===player){ flashHitmarker(); sfxHit(); }
    if(bot.hp<=0) killBot(bot, attacker, part==='head');
}

function tryFire(now){
    if(!player.alive || reloading) return;
    const W = WEAPONS[curWeapon], st = wstate[curWeapon];
    if(!W) return;
    // нож
    if(W.melee){
        if(now-lastShot < 500) return;
        lastShot = now;
        gunKick.z = -0.18; gunKick.x = -0.22;
        const origin = camera.getWorldPosition(new THREE.Vector3());
        const dir = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
        raycaster.set(origin, dir);
        const hits = raycaster.intersectObjects(enemyMeshes(), false);
        if(hits.length && hits[0].distance < 2.2){
            const bot = hits[0].object.userData.bot;
            if(bot && !bot.dead) damageBot(bot, W.dmg, hits[0].object.userData.part||'body', player);
        }
        return;
    }
    if(now - lastShot < 60000/W.rpm) return;
    if(st.ammo<=0){ startReload(); return; }
    lastShot = now;
    st.ammo--;
    updateAmmoHUD();
    sfxShot(W.snd);

    // спред
    const moveFactor = Math.min(1, player.vel.length()/5);
    const spread = (W.spread + bloom*0.02 + moveFactor*0.02) * (aiming?0.45:1);
    const dir = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
    dir.x += (Math.random()*2-1)*spread;
    dir.y += (Math.random()*2-1)*spread;
    dir.z += (Math.random()*2-1)*spread;
    dir.normalize();
    raycaster.set(camera.position.clone(), dir);

    const pellets = W.pellets || 1;
    const from = camera.position.clone().add(new THREE.Vector3(0.22,-0.2,-0.6).applyQuaternion(camera.quaternion));
    let endPoint = camera.position.clone().add(dir.clone().multiplyScalar(80));
    for(let p=0;p<pellets;p++){
        const d2 = dir.clone();
        if(pellets>1){ d2.x+=(Math.random()*2-1)*spread; d2.y+=(Math.random()*2-1)*spread; d2.z+=(Math.random()*2-1)*spread; d2.normalize(); }
        raycaster.set(camera.position.clone(), d2);
        const botHits = raycaster.intersectObjects(enemyMeshes(), false);
        const wallHits = raycaster.intersectObjects(wallMeshes, false);
        const wallDist = wallHits.length ? wallHits[0].distance : Infinity;
        if(botHits.length && botHits[0].distance < wallDist){
            const h = botHits[0];
            endPoint = h.point;
            const part = h.object.userData.part;
            damageBot(h.object.userData.bot, W.dmg * (part==='head'?2:1), part, player);
        } else if(wallHits.length){
            endPoint = wallHits[0].point;
        } else {
            endPoint = camera.position.clone().add(d2.multiplyScalar(80));
        }
        if(p===0 || pellets<=3) spawnTracer(from, endPoint);
    }

    muzzleLight.intensity = 3.2;
    player.pitch += W.recoil * (aiming?0.55:1);
    player.yaw += (Math.random()*2-1)*W.recoil*0.45;
    bloom = Math.min(1, bloom + (curWeapon===3?0.6:0.25));
    // анимация отдачи viewmodel
    gunKick.z = -0.14 - W.recoil*2.2;
    gunKick.x = -0.05 - W.recoil*1.5;
    gunKick.y = (Math.random()*2-1)*0.03;
}


// ---------- УРОН ПО ИГРОКУ ----------
function applyDamage(d, attacker){
    if(!player.alive) return;
    const absorbed = Math.min(player.armor, d*0.55);
    player.armor = Math.max(0, player.armor - absorbed);
    player.hp = Math.max(0, player.hp - (d - absorbed));
    hpVal.textContent = Math.ceil(player.hp);
    armorVal.textContent = Math.ceil(player.armor);
    vignette.style.boxShadow = 'inset 0 0 120px rgba(255,0,0,0.65)';
    clearTimeout(applyDamage._t);
    applyDamage._t = setTimeout(()=>vignette.style.boxShadow='inset 0 0 100px rgba(255,0,0,0)', 130);
    if(player.hp<=0) playerDie(attacker);
}

function respawnPlayer(){
    const _list = spawnListFor('ally'); const sp = _list[Math.floor(Math.random()*_list.length)] || [0,24];
    player.pos.set(sp[0], 0, sp[1]); player.vel.set(0,0,0);
    player.yaw = 0; player.pitch = 0;
    player.hp = 100; player.armor = 100; player.alive = true;
    for(const k in WEAPONS){ wstate[k].ammo = WEAPONS[k].mag; wstate[k].reserve = WEAPONS[k].reserve; }
    reloading = false; reloadStartedAt=0; reloadDuration=0; clearTimeout(reloadTimer); $('btn-reload').classList.remove('active');
    hpVal.textContent = 100; armorVal.textContent = 100; bloom = 0;
    updateAmmoHUD();
    $('death-overlay').style.display = 'none';
}

function playerDie(attacker){
    player.alive = false;
    const killer = attacker || { name:'?', team:'enemy' };
    addScore('enemy');
    addKillFeed(killer.name, 'Вы', false, false, 'enemy', 'ally');
    $('death-overlay').style.display = 'flex';
    clearTimeout(playerDie._t);
    playerDie._t = setTimeout(()=>{ if(!player.alive) respawnPlayer(); }, 3000);
}

// ---------- KILL FEED ----------
function addKillFeed(a, b, playerIsKiller, headshot, aTeam, bTeam){
    const col = t => t==='ally' ? 'text-cyan-300' : 'text-amber-400';
    const div = document.createElement('div');
    div.className='kill-item so2-panel px-2 py-0.5 rounded text-[10px] font-sans';
    if(playerIsKiller) div.style.borderColor = '#38e8ff';
    div.innerHTML = '<span class="'+col(aTeam||'ally')+'">'+a+'</span>' +
        ' <i class="fa-solid '+(headshot?'fa-crosshairs':'fa-skull')+' text-slate-400 mx-1"></i> ' +
        '<span class="'+col(bTeam||'enemy')+'">'+b+'</span>';
    killFeedEl.prepend(div);
    while(killFeedEl.children.length>5) killFeedEl.lastChild.remove();
    setTimeout(()=>{ if(div.parentNode) div.remove(); }, 4500);
}

// ---------- ПЕРЕКЛЮЧЕНИЕ ОРУЖИЯ ----------
function updateMoneyHUD(){
    const el=$('money-val'); if(el) el.textContent='$'+playerMoney;
    const bm=$('buy-money'); if(bm) bm.textContent='$'+playerMoney;
}
function refreshWeaponSwitcher(){
    const box = $('weapon-switcher'); if(!box) return;
    box.innerHTML = '';
    const ids = Object.keys(owned).map(Number).filter(function(id){ return owned[id] && WEAPONS[id]; }).sort(function(a,b){ return a-b; });
    ids.forEach(function(id){
        const W = WEAPONS[id];
        const b = document.createElement('button');
        b.type = 'button';
        b.id = 'wslot-'+id;
        const short = W.name.length>7 ? W.name.slice(0,6)+'…' : W.name;
        b.textContent = short;
        b.className = 'px-2.5 py-1 rounded text-[10px] font-bold whitespace-nowrap '+(id===curWeapon?'bg-white/20 border border-orange-500':'bg-black/40 border border-white/10 opacity-70');
        b.onclick = function(){ switchWeapon(id); };
        box.appendChild(b);
    });
}
window.switchWeapon = function(slot){
    if(!WEAPONS[slot] || !owned[slot]) return;
    if(slot===curWeapon){ buildGun(slot); updateAmmoHUD(); return; }
    curWeapon = slot;
    save.weapon = slot; writeSave();
    reloading = false; clearTimeout(reloadTimer);
    const br=$('btn-reload'); if(br) br.classList.remove('active');
    aiming = false;
    refreshWeaponSwitcher();
    buildGun(slot);
    updateAmmoHUD();
};
function openBuyMenu(){
    const m=$('buy-menu'); if(!m) return;
    renderBuyList();
    m.classList.remove('hidden');
}
function closeBuyMenu(){
    const m=$('buy-menu'); if(m) m.classList.add('hidden');
}
function renderBuyList(){
    const list=$('buy-list'); if(!list) return;
    list.innerHTML='';
    const cats = [
        ['pistols','ПИСТОЛЕТЫ',[4,5,6,7,8,9,10,11,12]],
        ['smg','ПП',[20,21,22,23,24,25,26]],
        ['rifles','ВИНТОВКИ',[1,2,30,31,32,33,34]],
        ['snipers','СНАЙПЕРКИ',[3,40,41,42]],
        ['shotguns','ДРОБОВИКИ',[50,51,52,53]],
        ['lmg','ПУЛЕМЁТЫ',[60,61]],
        ['melee','БЛИЖНИЙ',[70]]
    ];
    cats.forEach(function(c){
        const title=document.createElement('div');
        title.className='text-xs font-bold text-orange-400 mb-1 mt-2 tracking-wide';
        title.textContent=c[1];
        list.appendChild(title);
        c[2].forEach(function(id){
            const W=WEAPONS[id]; if(!W) return;
            const has=!!owned[id];
            const btn=document.createElement('button');
            btn.type='button';
            btn.className='w-full flex justify-between items-center px-3 py-2.5 mb-1.5 rounded-xl border text-left text-sm font-bold '+(
                has ? 'bg-emerald-900/40 border-emerald-500/50' :
                (playerMoney>=W.price ? 'bg-slate-800 border-slate-600' : 'bg-slate-900/50 border-slate-800 opacity-50')
            );
            btn.innerHTML = '<span>'+W.name+(has?' <span style="color:#4ade80;font-size:10px">✓</span>':'')+'</span>'+
                '<span style="color:#fb923c">'+(W.price===0?'FREE':('$'+W.price))+'</span>';
            btn.onclick = function(){ buyWeapon(id); };
            list.appendChild(btn);
        });
    });
}
function buyWeapon(id){
    const W=WEAPONS[id]; if(!W) return;
    if(owned[id]){
        // refill ammo cheap
        const refill = Math.max(50, Math.floor(W.price*0.15));
        if(W.price===0){ wstate[id].ammo=W.mag; wstate[id].reserve=W.reserve; switchWeapon(id); closeBuyMenu(); return; }
        if(playerMoney>=refill){
            playerMoney-=refill; wstate[id].ammo=W.mag; wstate[id].reserve=W.reserve;
            updateMoneyHUD(); switchWeapon(id); showBanner('Патроны: '+W.name, 900); renderBuyList();
        }
        return;
    }
    if(playerMoney < W.price){ showBanner('Не хватает денег', 900); return; }
    playerMoney -= W.price;
    owned[id]=true;
    wstate[id].ammo=W.mag; wstate[id].reserve=W.reserve;
    updateMoneyHUD(); refreshWeaponSwitcher(); switchWeapon(id);
    showBanner('Куплено: '+W.name, 1200);
    renderBuyList();
}


// ---------- ВВОД: клавиатура/мышь ----------
const keys = {};
addEventListener('keydown', e=>{
    keys[e.code]=true;
    if(e.code==='KeyR') startReload();
    if(e.code==='KeyB') openBuyMenu();
    if(e.code==='KeyC') toggleCrouch();
    if(e.code==='Digit1'||e.code==='Digit2'||e.code==='Digit3'||e.code==='Digit4'||e.code==='Digit5'){
        const ids = Object.keys(owned).map(Number).filter(function(id){ return owned[id]&&WEAPONS[id]; }).sort(function(a,b){return a-b;});
        const idx = parseInt(e.code.replace('Digit',''),10)-1;
        if(ids[idx]!=null) switchWeapon(ids[idx]);
    }
    if(e.code==='KeyQ') switchWeapon(70); // knife
});
addEventListener('keyup', e=>keys[e.code]=false);

const canvas = renderer.domElement;
canvas.addEventListener('click', ()=>{
    audio();
    if(!('ontouchstart' in window) && document.pointerLockElement!==canvas){
        canvas.requestPointerLock && canvas.requestPointerLock();
    }
});
addEventListener('mousemove', e=>{
    if(document.pointerLockElement===canvas){
        const sens = 0.0022 * sensitivity * (aiming?(WEAPONS[curWeapon].scoped?0.35:0.6):1);
        player.yaw -= e.movementX*sens;
        player.pitch -= e.movementY*sens;
        player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch));
    }
});
addEventListener('mousedown', e=>{
    audio();
    if(document.pointerLockElement!==canvas) return;
    if(e.button===0){ fireHeld=true; tryFire(performance.now()); }
    if(e.button===2){ aiming=true; }
});
addEventListener('mouseup', e=>{
    if(e.button===0) fireHeld=false;
    if(e.button===2) aiming=false;
});
addEventListener('contextmenu', e=>e.preventDefault());

function toggleCrouch(){
    player.crouch=!player.crouch;
    $('btn-crouch').classList.toggle('active', player.crouch);
}

// ---------- ВВОД: тач ----------
const joy = { x:0, y:0, id:null };
const joyEl=$('joystick-container'), stickEl=$('joystick-stick');
const JOY_R = 46;

joyEl.addEventListener('pointerdown', e=>{
    if(hudEdit) return;
    joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId);
});
joyEl.addEventListener('pointermove', e=>{
    if(e.pointerId!==joy.id) return;
    const r = joyEl.getBoundingClientRect();
    let dx = e.clientX-(r.left+r.width/2), dy = e.clientY-(r.top+r.height/2);
    const len = Math.hypot(dx,dy);
    if(len>JOY_R){ dx=dx/len*JOY_R; dy=dy/len*JOY_R; }
    stickEl.style.transform = 'translate(calc(-50% + '+dx+'px), calc(-50% + '+dy+'px))';
    joy.x = dx/JOY_R; joy.y = dy/JOY_R;
});
function joyEnd(e){
    if(e.pointerId!==joy.id) return;
    joy.id=null; joy.x=0; joy.y=0;
    stickEl.style.transform='translate(-50%,-50%)';
}
joyEl.addEventListener('pointerup', joyEnd);
joyEl.addEventListener('pointercancel', joyEnd);

// зона обзора
const camArea=$('touch-camera-area');
let lookId=null, lookX=0, lookY=0;
function applyLook(dx,dy){
    const sens = 0.0042 * sensitivity * (aiming?(WEAPONS[curWeapon].scoped?0.35:0.6):1);
    player.yaw -= dx*sens;
    player.pitch -= dy*sens;
    player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch));
}
camArea.addEventListener('pointerdown', e=>{
    audio();
    if(lookId!==null) return;
    lookId=e.pointerId; lookX=e.clientX; lookY=e.clientY;
    camArea.setPointerCapture(e.pointerId);
});
camArea.addEventListener('pointermove', e=>{
    if(e.pointerId!==lookId) return;
    applyLook(e.clientX-lookX, e.clientY-lookY);
    lookX=e.clientX; lookY=e.clientY;
});
function lookEnd(e){ if(e.pointerId===lookId) lookId=null; }
camArea.addEventListener('pointerup', lookEnd);
camArea.addEventListener('pointercancel', lookEnd);

// кнопки (удержание привязано к конкретному пальцу)
function bindHold(el, down, up){
    let pid=null;
    el.addEventListener('pointerdown', e=>{
        if(hudEdit) return;
        e.preventDefault(); audio();
        pid=e.pointerId; el.setPointerCapture(e.pointerId); down();
    });
    const end=e=>{ if(e.pointerId!==pid) return; pid=null; up&&up(); };
    ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>el.addEventListener(ev, end));
}
bindHold($('btn-jump'), ()=>{ keys['Space']=true; }, ()=>{ keys['Space']=false; });

// МОБИЛЬНЫЙ ОГОНЬ + ОБЗОР: палец можно уводить за пределы кнопки,
// сама кнопка остаётся на месте. Захват указателя сохраняет стрельбу.
const fireBtn=$('btn-fire');
let fireLookId=null, fireLX=0, fireLY=0;
fireBtn.style.touchAction='none';
fireBtn.addEventListener('pointerdown', e=>{
    if(hudEdit) return;
    e.preventDefault(); e.stopPropagation(); audio();
    if(fireLookId!==null) return;
    fireLookId=e.pointerId; fireLX=e.clientX; fireLY=e.clientY;
    fireHeld=true; tryFire(performance.now());
    try { fireBtn.setPointerCapture(e.pointerId); } catch(_) {}
});
addEventListener('pointermove', e=>{
    if(e.pointerId!==fireLookId) return;
    e.preventDefault();
    applyLook(e.clientX-fireLX, e.clientY-fireLY);
    fireLX=e.clientX; fireLY=e.clientY;
},{passive:false});
function fireTouchEnd(e){
    if(e.pointerId!==fireLookId) return;
    fireLookId=null; fireHeld=false;
}
['pointerup','pointercancel'].forEach(ev=>addEventListener(ev, fireTouchEnd));

$('btn-aim').addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; aiming=!aiming; $('btn-aim').classList.toggle('active', aiming); });
$('btn-crouch').addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; toggleCrouch(); });
$('btn-reload').addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; startReload(); });

// ---------- ПАМЯТЬ ИГРЫ (localStorage) ----------
const SAVE_KEY = 'standoff3d_save_v1';
const save = {
    gfx: { rs:1.0, sh:'high', fps:'60', sens:1.0, preset:'high', auto:true },
    hud: {},        // позиции кнопок в долях экрана {x,y}
    hudScale: 1,    // размер кнопок
    weapon: 1
};
function loadSave(){
    try{
        const raw = localStorage.getItem(SAVE_KEY);
        if(!raw) return;
        const d = JSON.parse(raw);
        if(!d || typeof d!=='object') return;
        Object.assign(save.gfx, d.gfx||{});
        save.hud = (d.hud && typeof d.hud==='object') ? d.hud : {};
        const hs = parseFloat(d.hudScale);
        save.hudScale = (hs>=0.7 && hs<=1.5) ? hs : 1;
        const w = parseInt(d.weapon,10);
        save.weapon = (WEAPONS[w] ? w : 4);
    }catch(e){}
}
function writeSave(){
    try{ localStorage.setItem(SAVE_KEY, JSON.stringify(save)); }catch(e){}
}

// ---------- HUD EDIT MODE ----------
let hudEdit=false;
const hudEls = { joy:$('joystick-container'), fire:$('btn-fire'), aim:$('btn-aim'), jump:$('btn-jump'), crouch:$('btn-crouch'), reload:$('btn-reload') };
const hudBase = {}, hudInit = {};
for(const k in hudEls){
    hudInit[k] = hudEls[k].style.cssText;
    hudBase[k] = k==='joy' ? 130 : (parseFloat(hudEls[k].style.width)||52);
}
function setHudEdit(on){
    hudEdit = !!on;
    wrapper.classList.toggle('hud-edit-mode', hudEdit);
    const bar = $('hud-edit-bar');
    if(bar) bar.classList.toggle('hidden', !hudEdit);
    const legacy = $('btn-hud-edit');
    if(legacy) legacy.classList.toggle('bg-orange-500', hudEdit);
    // отпускаем всё, что могло остаться зажатым
    fireHeld=false; keys['Space']=false; joy.id=null; joy.x=0; joy.y=0;
    if(hudEdit) showBanner('Перетащите кнопки · затем «ГОТОВО»', 2200);
    else { writeSave(); showBanner('Раскладка сохранена', 1200); }
}
$('btn-hud-edit').addEventListener('click', ()=>setHudEdit(!hudEdit));
$('btn-hud-move').addEventListener('click', ()=>{ closeSettings(); setHudEdit(true); });
const _hudDone=$('btn-hud-done'); if(_hudDone) _hudDone.addEventListener('click', e=>{ e.preventDefault(); setHudEdit(false); });


function clampHud(el){
    const w=el.offsetWidth, h=el.offsetHeight;
    let l=parseFloat(el.style.left), t=parseFloat(el.style.top);
    if(isNaN(l)||isNaN(t)) return;
    el.style.left = Math.max(0, Math.min(innerWidth-w, l))+'px';
    el.style.top  = Math.max(0, Math.min(innerHeight-h, t))+'px';
}
function applyHudScale(){
    const sc = save.hudScale;
    for(const k in hudEls){
        if(k==='joy') continue;
        const px = Math.round(hudBase[k]*sc);
        hudEls[k].style.width = px+'px'; hudEls[k].style.height = px+'px';
    }
    $('hud-scale-val').textContent = sc.toFixed(2)+'x';
    $('setting-hud-scale').value = sc;
    for(const k in hudEls) clampHud(hudEls[k]);
}
function applyHudLayout(){
    for(const k in hudEls){
        const p = save.hud[k];
        if(!p || typeof p.x!=='number' || typeof p.y!=='number') continue;
        const el = hudEls[k];
        el.style.left = (p.x*innerWidth)+'px';
        el.style.top  = (p.y*innerHeight)+'px';
        el.style.right='auto'; el.style.bottom='auto';
        clampHud(el);
    }
}
let dragEl=null, dragOX=0, dragOY=0;
for(const k in hudEls){
    const el = hudEls[k];
    el.addEventListener('pointerdown', e=>{
        if(!hudEdit) return;
        e.preventDefault(); e.stopPropagation();
        dragEl=el; el.setPointerCapture(e.pointerId);
        const r=el.getBoundingClientRect();
        dragOX=e.clientX-r.left; dragOY=e.clientY-r.top;
        el.style.left=r.left+'px'; el.style.top=r.top+'px';
        el.style.right='auto'; el.style.bottom='auto';
    });
    el.addEventListener('pointermove', e=>{
        if(!hudEdit || dragEl!==el) return;
        el.style.left=(e.clientX-dragOX)+'px';
        el.style.top=(e.clientY-dragOY)+'px';
        clampHud(el);
    });
    const dragEnd = ()=>{
        if(dragEl!==el) return;
        dragEl=null;
        const r=el.getBoundingClientRect();
        save.hud[k] = { x:r.left/innerWidth, y:r.top/innerHeight };
        writeSave();
    };
    el.addEventListener('pointerup', dragEnd);
    el.addEventListener('pointercancel', dragEnd);
}
$('setting-hud-scale').addEventListener('input', e=>{
    save.hudScale = parseFloat(e.target.value);
    applyHudScale(); writeSave();
});
$('btn-hud-reset').addEventListener('click', ()=>{
    for(const k in hudEls) hudEls[k].style.cssText = hudInit[k];
    save.hud = {}; save.hudScale = 1;
    applyHudScale(); writeSave();
    showBanner('Раскладка сброшена', 1200);
});

// ---------- НАСТРОЙКИ ГРАФИКИ ----------
let fpsCap = 60, preset = 'high';
const rsInput=$('setting-render-scale'), shadowSel=$('setting-shadows'), fpsSel=$('setting-fps-cap'), sensInput=$('setting-sens'), autoChk=$('setting-auto');
// null-safe listeners below

function markPreset(p){
    document.querySelectorAll('.preset-btn').forEach(b=>{
        const on = b.dataset.preset===p;
        b.classList.toggle('border-orange-500', on);
        b.classList.toggle('text-orange-400', on);
        b.classList.toggle('border-slate-700', !on);
    });
}
function syncGfxUI(){
    const g = save.gfx;
    const rs = parseFloat(g.rs);
    rsInput.value = (rs>=0.5 && rs<=1.25) ? rs : 1.0;
    shadowSel.value = ['off','low','high','ultra'].includes(g.sh) ? g.sh : 'high';
    fpsSel.value = ['30','60','90','120','0'].includes(String(g.fps)) ? String(g.fps) : '60';
    const se = parseFloat(g.sens);
    sensInput.value = (se>=0.3 && se<=2.5) ? se : 1.0;
    autoChk.checked = g.auto!==false;
    preset = ['low','medium','high','ultra'].includes(g.preset) ? g.preset : null;
    markPreset(preset);
}

function applyGraphics(){
    const scale = parseFloat(rsInput.value);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2)*scale);
    renderer.setSize(innerWidth, innerHeight);
    const renderScaleLabel = $('render-scale-val');
    if (renderScaleLabel) renderScaleLabel.textContent = scale.toFixed(2)+'x';
    const sh = shadowSel.value;
    const shadowsOn = sh!=='off';
    renderer.shadowMap.enabled = shadowsOn;
    sun.castShadow = shadowsOn;
    if(shadowsOn){
        const size = sh==='low'?1024 : sh==='high'?2048 : 4096;
        if(sun.shadow.mapSize.x!==size){
            sun.shadow.mapSize.set(size,size);
            if(sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map=null; }
        }
    }
    scene.traverse(o=>{
        if(o.material){ (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.needsUpdate=true); }
    });
    fpsCap = parseInt(fpsSel.value,10);
    sensitivity = parseFloat(sensInput.value);
    $('sens-val').textContent = sensitivity.toFixed(1);
    save.gfx = { rs:scale, sh:sh, fps:fpsSel.value, sens:sensitivity, preset:preset, auto:autoChk.checked };
    writeSave();
}
function onManualGfx(){ preset=null; markPreset(null); applyGraphics(); }
[rsInput, shadowSel, fpsSel].forEach(el=>el.addEventListener('change', onManualGfx));
const presetSel=$('setting-preset');
if(presetSel) presetSel.addEventListener('change', e=>{
  const p=e.target.value;
  if(p==='low'){ if(rsInput) rsInput.value=0.55; if(shadowSel) shadowSel.value='off'; if(fpsSel) fpsSel.value='30'; }
  else if(p==='medium'){ if(rsInput) rsInput.value=0.75; if(shadowSel) shadowSel.value='low'; if(fpsSel) fpsSel.value='60'; }
  else { if(rsInput) rsInput.value=1; if(shadowSel) shadowSel.value='high'; if(fpsSel) fpsSel.value='60'; }
  applyGraphics();
});
if(rsInput) rsInput.addEventListener('input', ()=>{ const v=$('rs-val'); if(v) v.textContent=rsInput.value; applyGraphics(); });
if(shadowSel) shadowSel.addEventListener('change', applyGraphics);
if(fpsSel) fpsSel.addEventListener('change', applyGraphics);
if(sensInput) sensInput.addEventListener('input', ()=>{ const v=$('sens-val'); if(v) v.textContent=parseFloat(sensInput.value).toFixed(2); applyGraphics(); });

if(autoChk) autoChk.addEventListener('change', applyGraphics);

window.setGraphicPreset = function(p){
    const map = {
        low:    { rs:0.5,  sh:'off',  fps:'30'  },
        medium: { rs:0.75, sh:'low',  fps:'60'  },
        high:   { rs:1.0,  sh:'high', fps:'60'  },
        ultra:  { rs:1.25, sh:'ultra',fps:'120' }
    }[p];
    rsInput.value=map.rs; shadowSel.value=map.sh; fpsSel.value=map.fps;
    preset=p; markPreset(p);
    applyGraphics();
};

// Авто-качество: если FPS стабильно ниже цели (60), снижаем нагрузку по шагам
let aqLow=0, aqCool=performance.now()+4000;
function autoQuality(fps, now){
    const setOpen = $('settings-modal') && !$('settings-modal').classList.contains('hidden');
    if(!autoChk.checked || document.hidden || hudEdit || setOpen || now<aqCool){ aqLow=0; return; }
    const target = fpsCap>0 ? Math.min(fpsCap,60) : 60;
    if(fps >= target*0.88){ aqLow=0; return; }
    if(++aqLow<3) return;
    aqLow=0; aqCool=now+3000;
    const rs=parseFloat(rsInput.value), sh=shadowSel.value;
    if(sh==='ultra') shadowSel.value='high';
    else if(rs>0.75) rsInput.value=rs-0.25;
    else if(sh==='high') shadowSel.value='low';
    else if(rs>0.5) rsInput.value=rs-0.25;
    else if(sh==='low') shadowSel.value='off';
    else return;
    onManualGfx();
    showBanner('Авто-качество: снижена нагрузка для 60 FPS', 1500);
}

function openSettings(){
  const m=$('settings-modal'); if(m) m.classList.remove('hidden');
  // показать вкладку ИГРА по умолчанию
  document.querySelectorAll('.settings-tab').forEach(t=>{
    const on = t.getAttribute('data-tab')==='game';
    t.classList.toggle('text-orange-400', on);
    t.classList.toggle('text-slate-400', !on);
    t.classList.toggle('border-orange-500', on);
    t.classList.toggle('border-transparent', !on);
  });
  document.querySelectorAll('.settings-panel').forEach(p=>{
    if(p.getAttribute('data-panel')==='game') p.classList.remove('hidden');
    else p.classList.add('hidden');
  });
}
function closeSettings(){
  const m=$('settings-modal'); if(m) m.classList.add('hidden');
  const g=$('graphics-modal'); if(g) g.classList.add('hidden');
}
const _btnSet=$('btn-settings'); if(_btnSet) _btnSet.addEventListener('click', e=>{ e.preventDefault(); openSettings(); });
const _sc=$('settings-close'); if(_sc) _sc.addEventListener('click', closeSettings);
const _sc2=$('settings-close2'); if(_sc2) _sc2.addEventListener('click', closeSettings);
// tabs
document.querySelectorAll('.settings-tab').forEach(tab=>{
  tab.addEventListener('click', ()=>{
    const name = tab.getAttribute('data-tab');
    document.querySelectorAll('.settings-tab').forEach(t=>{
      t.classList.remove('text-orange-400','border-orange-500');
      t.classList.add('text-slate-400');
      t.style.borderBottomColor = 'transparent';
    });
    tab.classList.add('text-orange-400');
    tab.classList.remove('text-slate-400');
    tab.style.borderBottomColor = '#f97316';
    document.querySelectorAll('.settings-panel').forEach(p=>{
      if(p.getAttribute('data-panel')===name) p.classList.remove('hidden');
      else p.classList.add('hidden');
    });
  });
});
// legacy
if($('btn-graphics')) $('btn-graphics').addEventListener('click', openSettings);
if($('close-graphics-btn')) $('close-graphics-btn').addEventListener('click', closeSettings);

$('btn-fullscreen').addEventListener('click', ()=>{
    if(document.fullscreenElement) document.exitFullscreen();
    else wrapper.requestFullscreen && wrapper.requestFullscreen();
});

// ---------- КОЛЛИЗИИ ----------
function resolveCollisions(p, r){
    for(const c of colliders){
        // Боковые столкновения работают только когда игрок по высоте пересекается с блоком.
        const feet = p.y || 0;
        const head = feet + (player.crouch ? 1.15 : 1.75);
        if(head <= (c.minY ?? 0) + 0.02 || feet >= (c.maxY ?? 5) - 0.02) continue;
        const cx = Math.max(c.minX, Math.min(p.x, c.maxX));
        const cz = Math.max(c.minZ, Math.min(p.z, c.maxZ));
        const dx = p.x-cx, dz = p.z-cz;
        const d2 = dx*dx+dz*dz;
        if(d2 < r*r){
            if(d2>1e-6){
                const d=Math.sqrt(d2), push=r-d;
                p.x += dx/d*push; p.z += dz/d*push;
            } else {
                // внутри бокса — выталкиваем по минимальной оси
                const ox = Math.min(p.x-c.minX+r, c.maxX+r-p.x);
                const oz = Math.min(p.z-c.minZ+r, c.maxZ+r-p.z);
                if(ox<oz) p.x = (p.x-c.minX < c.maxX-p.x) ? c.minX-r : c.maxX+r;
                else p.z = (p.z-c.minZ < c.maxZ-p.z) ? c.minZ-r : c.maxZ+r;
            }
        }
    }
    p.x = Math.max(-WORLD+1, Math.min(WORLD-1, p.x));
    p.z = Math.max(-WORLD+1, Math.min(WORLD-1, p.z));
}

// ---------- МИНИКАРТА ----------
function drawMinimap(){
    const S = minimap.width;
    mmCtx.clearRect(0,0,S,S);
    mmCtx.fillStyle='rgba(10,14,20,0.92)';
    mmCtx.beginPath(); mmCtx.arc(S/2,S/2,S/2,0,Math.PI*2); mmCtx.fill();
    const k = S/(WORLD*2);
    mmCtx.fillStyle='rgba(120,140,170,0.75)';
    for(const c of colliders){
        mmCtx.fillRect((c.minX+WORLD)*k, (c.minZ+WORLD)*k, (c.maxX-c.minX)*k, (c.maxZ-c.minZ)*k);
    }
    // боты: союзники синие, враги красные
    for(const b of bots){
        if(b.dead) continue;
        mmCtx.fillStyle = b.team==='ally' ? '#38bdf8' : '#ff5544';
        const bx=(b.grp.position.x+WORLD)*k, bz=(b.grp.position.z+WORLD)*k;
        mmCtx.beginPath(); mmCtx.arc(bx,bz,b.team==='ally'?2.2:1.8,0,Math.PI*2); mmCtx.fill();
    }
    // игрок (стрелка)
    const px=(player.pos.x+WORLD)*k, pz=(player.pos.z+WORLD)*k;
    mmCtx.save();
    mmCtx.translate(px,pz);
    mmCtx.rotate(-player.yaw);
    mmCtx.fillStyle='#38e8ff';
    mmCtx.beginPath(); mmCtx.moveTo(0,-3.5); mmCtx.lineTo(2.5,2.5); mmCtx.lineTo(-2.5,2.5); mmCtx.closePath(); mmCtx.fill();
    mmCtx.restore();
}

const tmpV = new THREE.Vector3();
// ---------- БОТ ИИ ----------
const aiRay = new THREE.Raycaster();
const aiFrom = new THREE.Vector3(), aiTo = new THREE.Vector3(), aiDir = new THREE.Vector3();
const posOf = t => t===player ? player.pos : t.grp.position;

function canSee(a, b){
    aiFrom.set(a.x, 1.5, a.z); aiTo.set(b.x, 1.5, b.z);
    aiDir.subVectors(aiTo, aiFrom); const d = aiDir.length(); if(d<0.01) return true;
    aiDir.divideScalar(d);
    aiRay.set(aiFrom, aiDir); aiRay.near = 0.1; aiRay.far = d;
    return aiRay.intersectObjects(wallMeshes,false).length===0;
}

function findEnemy(bot){
    const me = bot.grp.position;
    let best = null, bd = 42;
    const consider = t => {
        const p = posOf(t), d = Math.hypot(p.x-me.x, p.z-me.z);
        if(d<bd && canSee(me,p)){ bd=d; best=t; }
    };
    if(bot.team==='enemy'){
        if(player.alive) consider(player);
        for(const o of bots) if(o.team==='ally' && !o.dead) consider(o);
    } else {
        for(const o of bots) if(o.team==='enemy' && !o.dead) consider(o);
    }
    bot.enemy = best; bot.enemyDist = bd;
}

function randomPoint(){
    let nx, nz, t=0;
    do{ nx=(Math.random()*2-1)*(WORLD-3); nz=(Math.random()*2-1)*(WORLD-3); t++; }
    while(t<15 && pointInCollider(nx,nz,0.8));
    return [nx,nz];
}

function botShoot(bot, tgt, dist){
    const isP = tgt===player, tp = posOf(tgt);
    const base = bot.team==='ally' ? 0.5 : 0.4;
    const hit = Math.random() < Math.max(0.1, base - dist*0.008);
    const from = bot.grp.position.clone(); from.y = 1.35;
    const to = new THREE.Vector3(tp.x, isP ? player.eyeH*0.85 : 1.2, tp.z);
    if(!hit){ to.x += (Math.random()*2-1)*2.2; to.y += (Math.random()*2-1)*1.2; to.z += (Math.random()*2-1)*2.2; }
    spawnTracer(from, to, bot.team==='ally' ? 0x7ab8ff : 0xff8866);
    if(!hit) return;
    if(isP){ if(bot.team==='ally') return; applyDamage(7+Math.random()*7, bot); }
    else { if(bot.team===tgt.team) return; damageBot(tgt, 22+Math.random()*14, Math.random()<0.15?'head':'body', bot); }
}

function updateBot(bot, dt){
    const g = bot.grp;
    if(bot.dead){
        bot.respawnT -= dt;
        if(bot.respawnT<=0 && !matchOver) respawnBot(bot);
        return;
    }
    bot.checkT -= dt;
    if(bot.checkT<=0){ bot.checkT = 0.3 + Math.random()*0.15; findEnemy(bot); }
    // цель могла умереть
    if(bot.enemy && ((bot.enemy===player && !player.alive) || (bot.enemy!==player && bot.enemy.dead))) bot.enemy = null;

    let mvx=0, mvz=0;
    const speed = bot.team==='ally' ? 3.5 : 3.1;

    if(bot.enemy){
        const tp = posOf(bot.enemy);
        const ang = Math.atan2(tp.x-g.position.x, tp.z-g.position.z);
        g.rotation.y = ang;
        const dist = Math.hypot(tp.x-g.position.x, tp.z-g.position.z);
        bot.enemyDist = dist;
        bot.strafeT -= dt;
        if(bot.strafeT<=0){ bot.strafeT = 1+Math.random()*1.5; bot.strafe *= -1; }
        const ideal = 14;
        const toward = dist>ideal ? 1 : (dist<ideal-5 ? -1 : 0);
        mvx = Math.sin(ang)*toward + Math.cos(ang)*bot.strafe*0.8;
        mvz = Math.cos(ang)*toward - Math.sin(ang)*bot.strafe*0.8;
        bot.fireCd -= dt;
        if(bot.fireCd<=0){
            bot.fireCd = 0.7 + Math.random()*0.8;
            botShoot(bot, bot.enemy, dist);
        }
    } else {
        // нет цели: союзники держатся рядом с игроком, враги патрулируют и давят
        let gx, gz;
        if(bot.team==='ally' && player.alive){
            const a = bot.slot*1.05 + player.yaw*0 ;
            gx = player.pos.x + Math.cos(a)*4.5; gz = player.pos.z + Math.sin(a)*4.5;
            bot.target.set(gx,0,gz);
        } else {
            tmpV.set(bot.target.x-g.position.x, 0, bot.target.z-g.position.z);
            if(tmpV.length()<1.4){
                let p;
                if(bot.team==='enemy' && Math.random()<0.5){
                    const pool = [player.alive?player.pos:null].concat(bots.filter(o=>o.team==='ally'&&!o.dead).map(o=>o.grp.position)).filter(Boolean);
                    const t = pool.length ? pool[Math.floor(Math.random()*pool.length)] : null;
                    p = t ? [t.x+(Math.random()-0.5)*10, t.z+(Math.random()-0.5)*10] : randomPoint();
                    if(pointInCollider(p[0],p[1],0.8)) p = randomPoint();
                } else p = randomPoint();
                bot.target.set(Math.max(-WORLD+2,Math.min(WORLD-2,p[0])),0,Math.max(-WORLD+2,Math.min(WORLD-2,p[1])));
            }
        }
        tmpV.set(bot.target.x-g.position.x, 0, bot.target.z-g.position.z);
        const d = tmpV.length();
        if(d>(bot.team==='ally'?1.6:1.0)){
            tmpV.normalize(); mvx=tmpV.x; mvz=tmpV.z;
            g.rotation.y = Math.atan2(mvx, mvz);
            // застрял -> новая точка
            bot.stuckT += dt;
            if(bot.stuckT>0.6){
                if(Math.hypot(g.position.x-bot.lastX, g.position.z-bot.lastZ)<0.25){
                    const p = randomPoint(); bot.target.set(p[0],0,p[1]);
                    bot.strafe *= -1;
                }
                bot.stuckT = 0; bot.lastX = g.position.x; bot.lastZ = g.position.z;
            }
        }
    }
    const len = Math.hypot(mvx,mvz);
    if(len>0.01){
        const sp = (bot.enemy?0.85:1) * speed;
        g.position.x += mvx/len*sp*dt;
        g.position.z += mvz/len*sp*dt;
        resolveCollisions(g.position, 0.45);
    }
    // отталкивание от других ботов и игрока
    for(const o of bots){
        if(o===bot || o.dead) continue;
        const dx=g.position.x-o.grp.position.x, dz=g.position.z-o.grp.position.z;
        const d2=dx*dx+dz*dz;
        if(d2<0.81 && d2>1e-4){
            const d=Math.sqrt(d2), push=(0.9-d)*0.5;
            g.position.x+=dx/d*push; g.position.z+=dz/d*push;
        }
    }
    if(player.alive){
        const dx=g.position.x-player.pos.x, dz=g.position.z-player.pos.z, d2=dx*dx+dz*dz;
        if(d2<0.64 && d2>1e-4){ const d=Math.sqrt(d2), push=(0.8-d)*0.5; g.position.x+=dx/d*push; g.position.z+=dz/d*push; }
    }
    bot.body.position.y = 0.85 + Math.sin(performance.now()*0.008 + bot.id)*0.03;
}

// ---------- ОБНОВЛЕНИЕ ИГРОКА ----------
const chArms = { top:$('ch-top'), bottom:$('ch-bottom'), left:$('ch-left'), right:$('ch-right') };
[chArms.top,chArms.bottom,chArms.left,chArms.right].forEach(a=>{
    a.style.transform='translate(-50%,-50%)'; a.style.left='50%'; a.style.top='50%';
});

function updatePlayer(dt, now){
    // ввод
    let f = (keys['KeyW']?1:0)-(keys['KeyS']?1:0) + (-joy.y);
    let s = (keys['KeyD']?1:0)-(keys['KeyA']?1:0) + joy.x;
    const fl = Math.hypot(f,s);
    if(fl>1){ f/=fl; s/=fl; }
    const speed = player.crouch?2.6:5.4;
    const sinY=Math.sin(player.yaw), cosY=Math.cos(player.yaw);
    const mx = (-sinY*f + cosY*s)*speed;
    const mz = (-cosY*f - sinY*s)*speed;
    player.vel.x = mx; player.vel.z = mz;
    // Прыжки на блоки: приземлиться можно только на верхнюю поверхность,
    // если высоты прыжка хватает. Через высокие блоки пройти нельзя.
    const prevY = player.pos.y;
    player.vel.y -= 22*dt;
    if(keys['Space'] && player.onGround){ player.vel.y=7.5; player.onGround=false; }
    player.pos.x += player.vel.x*dt;
    player.pos.z += player.vel.z*dt;
    player.pos.y += player.vel.y*dt;
    let landedTop = 0;
    if(player.vel.y <= 0){
        for(const c of colliders){
            const top = c.maxY ?? 0;
            if(top <= 0.02 || prevY < top - 0.02 || player.pos.y > top) continue;
            if(player.pos.x >= c.minX-0.32 && player.pos.x <= c.maxX+0.32 &&
               player.pos.z >= c.minZ-0.32 && player.pos.z <= c.maxZ+0.32){
                if(top > landedTop) landedTop = top;
            }
        }
    }
    if(landedTop > 0){ player.pos.y=landedTop; player.vel.y=0; player.onGround=true; }
    else if(player.pos.y<=0){ player.pos.y=0; player.vel.y=0; player.onGround=true; }
    else { player.onGround=false; }
    resolveCollisions(player.pos, 0.4);

    // камера
    const targetEye = player.crouch?1.08:1.7;
    player.eyeH += (targetEye-player.eyeH)*Math.min(1, dt*10);
    camera.position.set(player.pos.x, player.pos.y+player.eyeH, player.pos.z);
    camera.rotation.y = player.yaw;
    camera.rotation.x = player.pitch;

    // авто-огонь
    if(fireHeld && WEAPONS[curWeapon].auto) tryFire(now);

    // fov / прицел
    const W = WEAPONS[curWeapon];
    const targetFov = aiming ? W.aimFov : 75;
    camera.fov += (targetFov-camera.fov)*Math.min(1, dt*12);
    camera.updateProjectionMatrix();
    const scoped = W.scoped && aiming;
    scopeEl.style.display = scoped ? 'block' : 'none';
    crosshairEl.style.opacity = scoped ? '0' : '1';
    gunGroup.visible = !scoped;

    // анимация оружия: отдача + ходьба + sway
    gunKick.x += (0-gunKick.x)*Math.min(1, dt*10);
    gunKick.y += (0-gunKick.y)*Math.min(1, dt*10);
    gunKick.z += (0-gunKick.z)*Math.min(1, dt*12);
    const moving = Math.hypot(player.vel.x, player.vel.z);
    if(moving>0.4 && player.onGround && !reloading){
        gunBob += dt * (player.crouch?7:12) * Math.min(1, moving/4);
    } else {
        gunBob += (0-gunBob)*Math.min(1, dt*4);
    }
    gunSway += ((player.yaw*0.15)-gunSway)*Math.min(1, dt*6);
    const bobY = Math.sin(gunBob)*0.012 * (aiming?0.25:1);
    const bobX = Math.sin(gunBob*0.5)*0.008 * (aiming?0.25:1);
    const baseX = aiming ? 0.12 : 0.28;
    const baseY = aiming ? -0.14 : -0.24;
    const baseZ = aiming ? -0.32 : -0.42;
    gunGroup.position.x = baseX + bobX + gunKick.y + gunSway*0.02;
    gunGroup.position.y = baseY + bobY + gunKick.x*0.3;
    gunGroup.position.z = baseZ + gunKick.z;
    gunGroup.rotation.x = 0.04 + gunKick.x*0.8 + (reloading?0.55:0);
    gunGroup.rotation.y = 0.08 + gunKick.y*0.5 - gunSway*0.04;
    gunGroup.rotation.z = 0.02 + gunKick.y*0.4;
    // Короткий цикл затвора при выстреле и многофазная анимация перезарядки.
    const reloadP = reloading && reloadDuration>0 ? Math.max(0,Math.min(1,(now-reloadStartedAt)/reloadDuration)) : 0;
    const reloadWave = reloading ? Math.sin(reloadP*Math.PI) : 0;
    if(weaponAnim.bolt){
        const kickPulse = Math.max(0, Math.min(1, -gunKick.z*5));
        weaponAnim.bolt.position.z = reloading ? (reloadP>0.22 && reloadP<0.56 ? 0.045 : 0) : -kickPulse*0.055;
    }
    if(weaponAnim.magazine){
        let drop=0;
        if(reloading){
            if(reloadP>0.18 && reloadP<0.48) drop=-Math.sin(((reloadP-0.18)/0.30)*Math.PI/2)*0.13;
            else if(reloadP>=0.48 && reloadP<0.68) drop=-0.13*(1-(reloadP-0.48)/0.20);
        }
        weaponAnim.magazine.position.y=(weaponAnim.magazineBaseY||0)+drop;
    }
    if(weaponAnim.pump){
        weaponAnim.pump.position.z=-0.49+(reloading?Math.sin(reloadP*Math.PI*2)*0.055:0);
    }
    if(reloading){
        gunGroup.rotation.x=0.04+gunKick.x*0.8+0.22+reloadWave*0.13;
        gunGroup.rotation.z=0.02+Math.sin(reloadP*Math.PI*2)*0.12;
        gunGroup.position.y=baseY+bobY+gunKick.x*0.3-reloadWave*0.045;
    }

    // блум прицела
    bloom = Math.max(0, bloom - dt*1.6);
    const moveSpread = Math.min(8, Math.hypot(player.vel.x,player.vel.z)*1.1);
    const gap = 8 + bloom*14 + moveSpread;
    chArms.top.style.top = 'calc(50% - '+gap+'px)';
    chArms.bottom.style.top = 'calc(50% + '+gap+'px)';
    chArms.left.style.left = 'calc(50% - '+gap+'px)';
    chArms.right.style.left = 'calc(50% + '+gap+'px)';

    // дыхание
    if(player.alive && Math.hypot(player.vel.x,player.vel.z)>0.5 && player.onGround){
        camera.position.y += Math.sin(now*0.012)*0.02;
    }
}

// ---------- ВЫБОР КАРТЫ ----------
function applySideAndMode(){
    createTeams();
    const list = spawnListFor('ally');
    const sp = list[Math.floor(Math.random()*list.length)] || [0,24];
    player.pos.set(sp[0], 0, sp[1]);
    player.vel.set(0,0,0); player.onGround=true;
    player.yaw = playerSide==='t' ? 0 : Math.PI;
    player.pitch = 0;
    player.hp = 100; player.armor = 50; player.alive = true;
    hpVal.textContent = 100; armorVal.textContent = 50;
    placeSites();
    showBanner(playerSide==='t' ? 'Сторона: T · ТЕРРОР' : 'Сторона: CT · СПЕЦНАЗ', 1600);
}
const _modeSel = $('mode-select');
if(_modeSel) _modeSel.addEventListener('change', e=>{
    gameMode = e.target.value === 'plant' ? MODE.PLANT : MODE.TDM;
    placeSites();
    showBanner(gameMode===MODE.PLANT ? 'Режим: PLANT' : 'Режим: TDM', 1400);
});
const _sideSel = $('side-select');
if(_sideSel) _sideSel.addEventListener('change', e=>{
    playerSide = e.target.value === 't' ? 't' : 'ct';
    applySideAndMode();
});
const _mapSel = $('map-select');
if(_mapSel) _mapSel.addEventListener('change', e=>{
    const chosen=e.target.value;
    if(!['arena','dust','mirage'].includes(chosen)) return;
    currentMap=chosen;
    buildMap(currentMap);
    applySideAndMode();
    showBanner('Карта: '+(chosen==='dust'?'Dust':chosen==='mirage'?'Mirage':'Арена'));
});


// ---------- FPS-МЕТР ----------
const frameTimes = [];
let fpsAccum=0, fpsFrames=0, lastFpsUpdate=performance.now();

function updateFps(dt, now){
    fpsAccum+=dt; fpsFrames++;
    frameTimes.push(dt*1000);
    if(frameTimes.length>55) frameTimes.shift();
    if(now-lastFpsUpdate>=500){
        const fps = Math.round(fpsFrames/fpsAccum);
        fpsVal.textContent = fps;
        autoQuality(fps, now);
        fpsVal.className = fps>=50?'text-green-400':(fps>=30?'text-amber-400':'text-red-400');
        frameTimeEl.textContent = (fpsAccum/fpsFrames*1000).toFixed(1);
        fpsAccum=0; fpsFrames=0; lastFpsUpdate=now;
        // график
        fgCtx.clearRect(0,0,110,30);
        const max=40;
        frameTimes.forEach((ms,i)=>{
            const h=Math.min(30, ms/max*30);
            fgCtx.fillStyle = ms<20?'#4ade80':(ms<33?'#fbbf24':'#f87171');
            fgCtx.fillRect(108-i*2, 30-h, 1.6, h);
        });
    }
}

// ---------- MAIN LOOP ----------
let lastRender = 0, prevFrame = 0;
function loop(now){
    requestAnimationFrame(loop);
    const interval = fpsCap>0 ? 1000/fpsCap : 0;
    const elapsed = now - lastRender;
    if(elapsed < interval - 1) return;           // ещё рано (допуск 1 мс на джиттер)
    // компенсация дрейфа: ровный ритм 60 кадров на экранах 60/90/120 Гц
    lastRender = (interval && elapsed < interval*4) ? now - (elapsed % interval) : now;
    let dt = (now - prevFrame)/1000;
    prevFrame = now;
    if(dt>0.05) dt=0.05;
    if(dt<=0) dt=0.001;

    if(player.alive) updatePlayer(dt, now);
    else { camera.rotation.y += dt*0.4; }

    for(let i=bots.length-1;i>=0;i--) updateBot(bots[i], dt);
    entityCount.textContent = countAlive('ally')+' / '+countAlive('enemy');

    // трассеры
    for(let i=tracers.length-1;i>=0;i--){
        const t=tracers[i];
        t.life-=dt;
        if(t.life<=0){ scene.remove(t.line); t.line.geometry.dispose(); t.line.material.dispose(); tracers.splice(i,1); }
        else t.line.material.opacity = t.life/0.07*0.9;
    }
    muzzleLight.intensity = Math.max(0, muzzleLight.intensity - dt*30);

    drawMinimap();
    updateFps(dt, now);
    renderer.render(scene, camera);
}

// ---------- RESIZE ----------
function onResize(){
    camera.aspect = innerWidth/innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
    for(const k in hudEls) clampHud(hudEls[k]);
}
addEventListener('resize', onResize);

// ---------- INIT ----------
if('ontouchstart' in window) $('desktop-hint').style.display='none';
loadSave();
syncGfxUI();
onResize();
applyGraphics();
applyHudScale();
applyHudLayout();
if(!owned[save.weapon]) save.weapon = 4;
curWeapon = save.weapon || 4;
switchWeapon(curWeapon);
createTeams();
updateAmmoHUD();
updateMoneyHUD();
refreshWeaponSwitcher();
const _bb=$('btn-buy'); if(_bb) _bb.addEventListener('click', openBuyMenu);
const _bc=$('buy-close'); if(_bc) _bc.addEventListener('click', closeBuyMenu);
requestAnimationFrame(loop);

})();
