Standoff 3D — Android (WebView)
Игра лежит в app/src/main/assets/ (index.html, css/, js/).
Сборка: AGP 8.5.2, Gradle 8.7+, JDK 17, compileSdk 34.
Команда: gradle :app:assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
Библиотеки (Three.js, Tailwind, FontAwesome, шрифты) грузятся с CDN — нужен интернет.
