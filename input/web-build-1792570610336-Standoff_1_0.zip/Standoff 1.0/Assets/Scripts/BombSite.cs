using UnityEngine;

[RequireComponent(typeof(Collider))]
public class BombSite : MonoBehaviour
{
    public string siteName = "A";
    Collider col;

    void Awake()
    {
        col = GetComponent<Collider>();
        col.isTrigger = true;
    }

    public bool Contains(Vector3 point) => col.bounds.Contains(point);
}
