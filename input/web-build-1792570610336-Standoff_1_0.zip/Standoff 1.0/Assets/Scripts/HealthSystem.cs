using System.Collections;
using UnityEngine;

public class HealthSystem : MonoBehaviour
{
    public static HealthSystem Player;

    public float maxHealth = 100f;
    public float currentHealth;
    public float maxArmor = 100f;
    public float armor;                 // броня: поглощает половину урона, пока есть; сбрасывается каждый раунд
    public Team team = Team.None;
    public float respawnDelay = 3f;
    public bool IsRemote;          // прокси чужого игрока (урон приходит по сети)
    public int NetId = -1;

    public bool IsDead { get; private set; }
    HUDManager hudManager;
    Vector3 startPos;
    Quaternion startRot;

    void Start()
    {
        hudManager = FindObjectOfType<HUDManager>();
        startPos = transform.position;
        startRot = transform.rotation;
        if (CompareTag("Player"))
        {
            Player = this;
            if (GetComponent<PlayerController>() == null) gameObject.AddComponent<PlayerController>();
        }
        Revive();
    }

    public void Revive()
    {
        IsDead = false;
        currentHealth = maxHealth;
        armor = 0f;
        RefreshHUD();
        GetComponentInChildren<WeaponHolder>(true)?.Draw(snapLowered: true);
    }

    void RefreshHUD()
    {
        if (hudManager && CompareTag("Player"))
        {
            hudManager.UpdateHealth(currentHealth, maxHealth);
            hudManager.UpdateArmor(armor);
        }
    }

    public void GiveArmor(float amount)
    {
        armor = Mathf.Min(armor + amount, maxArmor);
        RefreshHUD();
    }

    public void TakeDamage(float damage, HealthSystem attacker = null)
    {
        if (IsDead) return;

        if (armor > 0f)
        {
            float absorbed = Mathf.Min(armor, damage * 0.5f);
            armor -= absorbed;
            damage -= absorbed;
        }

        currentHealth -= damage;
        RefreshHUD();
        if (currentHealth <= 0) Die(attacker);
    }

    void Die(HealthSystem killer)
    {
        IsDead = true;
        Debug.Log(gameObject.name + " died!");
        GetComponentInChildren<WeaponHolder>(true)?.LowerForDeath();

        bool isPlayer = CompareTag("Player");
        if (isPlayer) StatsManager.AddDeath();
        else if (killer != null && killer == Player)
        {
            StatsManager.AddKill();
            Economy.AddKill();
        }

        if (NetMatch.Instance != null && NetMatch.Instance.IsActive)
        {
            if (isPlayer)
            {
                NetMatch.Instance.ReportDeath(killer != null ? killer.NetId : -1);
                StartCoroutine(Respawn());
            }
            return;
        }

        if (CompetitiveRoundManager.Instance != null)
        {
            CompetitiveRoundManager.Instance.OnUnitDied(this);
            return;
        }

        var gm = Standoff3DGameManager.Instance;
        if (gm != null && gm.gameMode == GameMode.TeamDeathmatch)
        {
            gm.OnTdmKill(team);
            StartCoroutine(Respawn());
            return;
        }

        if (isPlayer) { if (gm) gm.PlayerDied(); }
        else Destroy(gameObject);
    }

    IEnumerator Respawn()
    {
        bool isPlayer = CompareTag("Player");
        if (!isPlayer) SetVisible(false);
        yield return new WaitForSeconds(respawnDelay);
        if (isPlayer && NetMatch.Instance != null && NetMatch.Instance.IsActive)
        {
            Transform sp = NetMatch.Instance.PickSpawn();
            MoveTo(sp.position, sp.rotation);
        }
        else MoveTo(startPos, startRot);
        Revive();
        if (!isPlayer) SetVisible(true);
    }

    public void SetVisible(bool on)
    {
        foreach (var r in GetComponentsInChildren<Renderer>()) r.enabled = on;
        foreach (var c in GetComponentsInChildren<Collider>()) c.enabled = on;
    }

    public void MoveTo(Transform t) => MoveTo(t.position, t.rotation);

    public void MoveTo(Vector3 pos, Quaternion rot)
    {
        var cc = GetComponent<CharacterController>();
        if (cc) cc.enabled = false;
        transform.SetPositionAndRotation(pos, rot);
        if (cc) cc.enabled = true;
        GetComponent<PlayerController>()?.OnTeleported(rot);
    }
}
