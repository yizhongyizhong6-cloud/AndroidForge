using System.Collections.Generic;
using UnityEngine;

// Пул объектов: во время игры ничего не создаётся и не уничтожается
// (Instantiate/Destroy на кадр — главный источник просадок FPS на слабых телефонах).
// Если свободных объектов нет и лимит достигнут, Get() возвращает null, и эффект пропускается.
public class ObjectPool
{
    readonly Stack<GameObject> free = new Stack<GameObject>();
    readonly GameObject prefab;
    readonly Transform parent;
    readonly int maxSize;
    int total;

    public ObjectPool(GameObject prefab, Transform parent, int prewarm, int maxSize)
    {
        this.prefab = prefab;
        this.parent = parent;
        this.maxSize = Mathf.Max(1, maxSize);
        if (prefab == null) return;
        int count = Mathf.Min(prewarm, this.maxSize);
        for (int i = 0; i < count; i++) Create();
    }

    void Create()
    {
        var go = Object.Instantiate(prefab, parent);
        go.SetActive(false);
        free.Push(go);
        total++;
    }

    public GameObject Get()
    {
        if (prefab == null) return null;
        if (free.Count == 0)
        {
            if (total >= maxSize) return null;
            Create();
        }
        return free.Pop();
    }

    public void Release(GameObject go)
    {
        if (go == null || free.Contains(go)) return;   // защита от двойного возврата
        go.SetActive(false);
        free.Push(go);
    }
}
