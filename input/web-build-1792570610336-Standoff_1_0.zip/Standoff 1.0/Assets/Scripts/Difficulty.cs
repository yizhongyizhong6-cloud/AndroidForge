using System;
using UnityEngine;

public enum BotDifficulty { Easy, Normal, Hard }

public struct BotSettings
{
    public float accuracy;             // 0..1, чем выше — тем точнее
    public float reactionTime;         // сек. до открытия огня после того, как увидел игрока
    public float spread;               // базовый разброс в градусах
    public float healthMultiplier;     // множитель здоровья бота
    public float moveSpeed;            // м/с
    public float fireIntervalMultiplier;
}

public static class BotDifficultyUtil
{
    public static BotDifficulty Load()
    {
        string s = PlayerPrefs.GetString("BotDifficulty", BotDifficulty.Normal.ToString());
        return Enum.TryParse(s, out BotDifficulty d) ? d : BotDifficulty.Normal;
    }

    public static BotSettings Settings(BotDifficulty d) => d switch
    {
        BotDifficulty.Easy => new BotSettings
        {
            accuracy = 0.35f, reactionTime = 1.2f, spread = 6f,
            healthMultiplier = 0.8f, moveSpeed = 2.5f, fireIntervalMultiplier = 1.6f
        },
        BotDifficulty.Hard => new BotSettings
        {
            accuracy = 0.9f, reactionTime = 0.25f, spread = 1f,
            healthMultiplier = 1.2f, moveSpeed = 4.5f, fireIntervalMultiplier = 0.8f
        },
        _ => new BotSettings
        {
            accuracy = 0.6f, reactionTime = 0.6f, spread = 3f,
            healthMultiplier = 1f, moveSpeed = 3.5f, fireIntervalMultiplier = 1f
        },
    };

    public static string Title(BotDifficulty d) => d switch
    {
        BotDifficulty.Easy => "Лёгкая",
        BotDifficulty.Hard => "Сложная",
        _ => "Средняя",
    };
}
