using UnityEngine;

public static class StatsManager
{
    const string KillsKey = "Stats_Kills";
    const string DeathsKey = "Stats_Deaths";
    const string MatchesKey = "Stats_Matches";
    const string WinsKey = "Stats_Wins";

    // Статистика текущей сессии (сбрасывается при загрузке сцены)
    public static int SessionKills { get; private set; }
    public static int SessionDeaths { get; private set; }

    // Общая статистика, сохраняется между запусками
    public static int Kills => PlayerPrefs.GetInt(KillsKey, 0);
    public static int Deaths => PlayerPrefs.GetInt(DeathsKey, 0);
    public static int Matches => PlayerPrefs.GetInt(MatchesKey, 0);
    public static int Wins => PlayerPrefs.GetInt(WinsKey, 0);
    public static float KD => Deaths == 0 ? Kills : (float)Kills / Deaths;
    public static float WinRate => Matches == 0 ? 0f : 100f * Wins / Matches;

    public static void AddKill()
    {
        SessionKills++;
        Increment(KillsKey);
        Wallet.Add(Wallet.KillCoins);
    }

    public static void AddDeath()
    {
        SessionDeaths++;
        Increment(DeathsKey);
    }

    public static void RecordMatch(bool won)
    {
        Increment(MatchesKey);
        if (won) Increment(WinsKey);
        Wallet.Add(won ? Wallet.WinCoins : Wallet.LossCoins);
    }

    public static void ResetSession()
    {
        SessionKills = 0;
        SessionDeaths = 0;
    }

    public static void ResetAll()
    {
        PlayerPrefs.DeleteKey(KillsKey);
        PlayerPrefs.DeleteKey(DeathsKey);
        PlayerPrefs.DeleteKey(MatchesKey);
        PlayerPrefs.DeleteKey(WinsKey);
        PlayerPrefs.Save();
        ResetSession();
    }

    static void Increment(string key)
    {
        PlayerPrefs.SetInt(key, PlayerPrefs.GetInt(key, 0) + 1);
        PlayerPrefs.Save();
    }
}
