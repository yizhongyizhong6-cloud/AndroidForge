using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour
{
    [Header("Timing")]
    public float plantTime = 3f;
    public float defuseTime = 5f;
    public float fuseTime = 40f;

    [Header("Explosion")]
    public float explosionRadius = 15f;
    public float explosionDamage = 300f;

    [Header("Visuals & Audio")]
    public GameObject model;
    public AudioSource audioSource;
    public AudioClip beepClip, explodeClip;

    public bool IsPlanted { get; private set; }
    public bool IsDefused { get; private set; }
    public bool IsExploded { get; private set; }

    CompetitiveRoundManager round;
    BombSite[] sites;
    BombSite currentSite;
    float progress, fuse, beepTimer;

    void Awake()
    {
        round = FindObjectOfType<CompetitiveRoundManager>();
        sites = FindObjectsOfType<BombSite>();
        if (model) model.SetActive(false);
    }

    public void ResetBomb()
    {
        IsPlanted = IsDefused = IsExploded = false;
        progress = fuse = beepTimer = 0f;
        currentSite = null;
        if (model) model.SetActive(false);
        round?.hud?.SetBombTimer("");
    }

    void Update()
    {
        if (round == null || IsExploded || IsDefused) return;

        bool holdingUse = !CompetitiveRoundManager.InputLocked && GameInput.UseHeld;
        Team myTeam = HealthSystem.Player != null ? HealthSystem.Player.team : Team.None;
        BombSite site = PlayerSite();

        if (!IsPlanted)
        {
            bool canPlant = holdingUse && myTeam == Team.Terrorist && site != null;
            progress = canPlant ? progress + Time.deltaTime : 0f;
            round.hud?.SetBombTimer(canPlant ? $"Установка {progress:F1} / {plantTime:F1}с" : "");
            if (canPlant && progress >= plantTime) Plant(site);
        }
        else
        {
            fuse -= Time.deltaTime;
            TickBeep();

            bool canDefuse = holdingUse && myTeam == Team.CounterTerrorist && site != null && site == currentSite;
            progress = canDefuse ? progress + Time.deltaTime : 0f;
            round.hud?.SetBombTimer(canDefuse
                ? $"Разминирование {progress:F1} / {defuseTime:F1}с"
                : $"Бомба: {Mathf.Max(fuse, 0f):F1}с");

            if (canDefuse && progress >= defuseTime) Defuse();
            else if (fuse <= 0f) Explode();
        }
    }

    BombSite PlayerSite()
    {
        if (HealthSystem.Player == null) return null;
        Vector3 p = HealthSystem.Player.transform.position;
        foreach (var s in sites) if (s.Contains(p)) return s;
        return null;
    }

    void Plant(BombSite site)
    {
        IsPlanted = true;
        currentSite = site;
        fuse = fuseTime;
        progress = 0f;
        beepTimer = 0f;
        transform.position = site.transform.position;
        if (model) model.SetActive(true);
        round.OnBombPlanted();
    }

    void Defuse()
    {
        IsDefused = true;
        progress = 0f;
        if (model) model.SetActive(false);
        round.hud?.SetBombTimer("");
        round.OnBombDefused();
    }

    void Explode()
    {
        IsExploded = true;
        round.hud?.SetBombTimer("");
        if (audioSource && explodeClip) audioSource.PlayOneShot(explodeClip);

        var hit = new HashSet<HealthSystem>();
        foreach (var c in Physics.OverlapSphere(transform.position, explosionRadius))
        {
            var hs = c.GetComponentInParent<HealthSystem>();
            if (hs == null || hs.IsDead || !hit.Add(hs)) continue;
            float d = Vector3.Distance(transform.position, hs.transform.position);
            hs.TakeDamage(explosionDamage * (1f - Mathf.Clamp01(d / explosionRadius)));
        }

        round.OnBombExploded();
    }

    void TickBeep()
    {
        beepTimer -= Time.deltaTime;
        if (beepTimer > 0f) return;
        float ratio = Mathf.Clamp01(fuse / fuseTime);
        beepTimer = Mathf.Lerp(0.1f, 1f, ratio);
        if (audioSource && beepClip) audioSource.PlayOneShot(beepClip);
    }
}
