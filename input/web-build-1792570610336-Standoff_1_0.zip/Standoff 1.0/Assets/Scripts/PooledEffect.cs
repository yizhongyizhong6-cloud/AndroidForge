using System;
using UnityEngine;

// Эффект из пула: проигрывает частицы и через life секунд возвращает объект в пул.
// На префабе: ParticleSystem (Play On Awake выключен), этот компонент.
public class PooledEffect : MonoBehaviour
{
    ParticleSystem[] systems;
    Action<GameObject> release;
    float timer;

    void Awake()
    {
        systems = GetComponentsInChildren<ParticleSystem>(true);
    }

    public void Play(Action<GameObject> onFinished, float life)
    {
        if (systems == null) systems = GetComponentsInChildren<ParticleSystem>(true);
        release = onFinished;
        timer = Mathf.Max(life, 0.05f);
        for (int i = 0; i < systems.Length; i++)
        {
            systems[i].Clear(true);
            systems[i].Play(true);
        }
    }

    void Update()
    {
        if (release == null) return;
        timer -= Time.deltaTime;
        if (timer > 0f) return;
        var r = release;
        release = null;
        r(gameObject);
    }

    void OnDisable()
    {
        release = null;
    }
}
