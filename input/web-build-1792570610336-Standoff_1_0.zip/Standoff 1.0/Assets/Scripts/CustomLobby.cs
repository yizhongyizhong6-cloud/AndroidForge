using UnityEngine;
using UnityEngine.UI;
using TMPro;

// Кастомная игра (лобби в духе Standoff): сторона, карта, число ботов-противников,
// раундов до победы и время раунда. Настройки сохраняются в PlayerPrefs, затем грузится карта.
// Соревновательный режим (покупки, нож и пистолет в начале раунда).
public class CustomLobby : MonoBehaviour
{
    [Header("Панель")]
    public GameObject panel;

    [Header("Карта")]
    public Button sandstoneButton;
    public Button dust2Button;
    public TextMeshProUGUI mapText;

    [Header("Сторона")]
    public Button terroristButton;
    public Button counterTerroristButton;
    public TextMeshProUGUI sideText;

    [Header("Боты-противники")]
    public Button botsMinusButton;
    public Button botsPlusButton;
    public TextMeshProUGUI botsText;
    [Tooltip("Максимум ботов, которых расставлено на сцене")]
    public int maxBots = 9;

    [Header("Раунды")]
    public Button roundsMinusButton;
    public Button roundsPlusButton;
    public TextMeshProUGUI roundsText;
    public int[] roundOptions = { 3, 5, 8, 13 };   // до скольких раундов
    public int roundsIndex = 2;

    [Header("Старт")]
    public Button startButton;
    public Button closeButton;
    public TextMeshProUGUI summaryText;

    string map = "Sandstone";
    Team side = Team.CounterTerrorist;
    int bots = 3;
    int rounds;
    const float FreezeTime = 5f;
    const float RoundTime = 115f;

    void Start()
    {
        if (sandstoneButton) sandstoneButton.onClick.AddListener(() => SetMap("Sandstone"));
        if (dust2Button) dust2Button.onClick.AddListener(() => SetMap("Dust2"));
        if (terroristButton) terroristButton.onClick.AddListener(() => SetSide(Team.Terrorist));
        if (counterTerroristButton) counterTerroristButton.onClick.AddListener(() => SetSide(Team.CounterTerrorist));
        if (botsMinusButton) botsMinusButton.onClick.AddListener(() => SetBots(bots - 1));
        if (botsPlusButton) botsPlusButton.onClick.AddListener(() => SetBots(bots + 1));
        if (roundsMinusButton) roundsMinusButton.onClick.AddListener(() => ChangeRounds(-1));
        if (roundsPlusButton) roundsPlusButton.onClick.AddListener(() => ChangeRounds(1));
        if (startButton) startButton.onClick.AddListener(StartMatch);
        if (closeButton) closeButton.onClick.AddListener(Close);

        rounds = roundOptions[Mathf.Clamp(roundsIndex, 0, roundOptions.Length - 1)];
        SetMap(map);
        SetSide(side);
        SetBots(bots);
        ChangeRounds(0);
        if (panel) panel.SetActive(false);
    }

    public void Open() { if (panel) panel.SetActive(true); }
    public void Close() { if (panel) panel.SetActive(false); }

    void SetMap(string m)
    {
        map = m;
        if (mapText) mapText.text = m == "Dust2" ? "Dust II" : "Sandstone";
        Summary();
    }

    void SetSide(Team t)
    {
        side = t;
        if (sideText) sideText.text = t == Team.Terrorist ? "Террористы" : "Контр-террористы";
        Summary();
    }

    void SetBots(int count)
    {
        bots = Mathf.Clamp(count, 0, maxBots);
        if (botsText) botsText.text = bots.ToString();
        Summary();
    }

    void ChangeRounds(int step)
    {
        roundsIndex = Mathf.Clamp(roundsIndex + step, 0, roundOptions.Length - 1);
        rounds = roundOptions[roundsIndex];
        if (roundsText) roundsText.text = "до " + rounds;
        Summary();
    }

    void Summary()
    {
        if (summaryText == null) return;
        string mapName = map == "Dust2" ? "Dust II" : "Sandstone";
        string sideName = side == Team.Terrorist ? "Т" : "КТ";
        summaryText.text = $"{mapName}  •  вы за {sideName}  •  ботов: {bots}  •  раундов до победы: {rounds}";
    }

    void StartMatch()
    {
        if (!Application.CanStreamedLevelBeLoaded(map))
        {
            Debug.LogError($"Сцена '{map}' не добавлена в Build Settings");
            return;
        }

        PlayerPrefs.SetString("GameMode", GameMode.Competitive.ToString());
        PlayerPrefs.SetString("Map", map);
        PlayerPrefs.SetString("PlayerTeam", side.ToString());
        PlayerPrefs.SetInt("BotLimit", bots);
        PlayerPrefs.SetInt("RoundsToWin", rounds);
        PlayerPrefs.SetFloat("FreezeTime", FreezeTime);
        PlayerPrefs.SetFloat("RoundTime", RoundTime);
        PlayerPrefs.Save();

        SceneLoader.Load(map);
    }
}
