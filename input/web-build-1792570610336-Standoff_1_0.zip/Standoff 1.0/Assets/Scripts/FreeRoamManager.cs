using UnityEngine;

// Режим «Без ботов» (осмотр карты): нет ботов, раундов и таймеров.
// Игрок ходит по карте, прыгает на ящики и стены, смотрит скины.
// Клавиша N — следующий скин текущего оружия (все скины, без покупки).
// Смерть — возрождение на месте старта через respawnDelay секунд.
public class FreeRoamManager : MonoBehaviour
{
    public static FreeRoamManager Instance { get; private set; }

    [Header("Что отключить у игрока в этом режиме")]
    [Tooltip("Твой старый скрипт движения, если он есть на игроке (чтобы не конфликтовал)")]
    public MonoBehaviour[] disableInFreeRoam;

    [Header("Управление")]
    public float respawnDelay = 2f;

    HealthSystem player;
    Vector3 spawnPos;
    Quaternion spawnRot;
    bool active;

    void Awake()
    {
        Instance = this;
        active = GameModeUtil.Load() == GameMode.FreeRoam;
        if (!active) enabled = false;
    }

    void Start()
    {
        player = HealthSystem.Player;
        if (player == null)
        {
            Debug.LogError("FreeRoam: игрок не найден (нужен тег Player)");
            return;
        }

        spawnPos = player.transform.position;
        spawnRot = player.transform.rotation;

        // Боты не нужны: отключаем их объекты. Игрок и сетевые прокси остаются.
        foreach (var u in FindObjectsOfType<HealthSystem>())
            if (!u.CompareTag("Player") && !u.IsRemote) u.gameObject.SetActive(false);

        foreach (var m in disableInFreeRoam)
            if (m != null) m.enabled = false;

        FindObjectOfType<HUDManager>()?.ShowMessage(
            "Без ботов: ходьба, прыжок, осмотр. Клавиша N или кнопка — скин", 6f);
    }

    void Update()
    {
        if (player == null || player.IsDead) return;
        if (GameInput.SkinDown) CycleSkin();
    }

    void CycleSkin()
    {
        var holder = player.GetComponentInChildren<WeaponHolder>(true);
        var w = holder != null ? holder.CurrentWeapon : null;
        if (w == null || w.skins == null || w.skins.Length == 0) return;

        SkinPrefs.CyclePreview(w.weaponName, w.skins.Length);
        w.RefreshSkin();

        int shown = SkinPrefs.GetSelected(w.weaponName, w.skins.Length) + 1;
        FindObjectOfType<HUDManager>()?.ShowMessage(
            w.weaponName + ": скин " + shown + " / " + w.skins.Length, 2f);
    }

    public void Respawn()
    {
        if (!active) return;
        Invoke(nameof(DoRespawn), respawnDelay);
    }

    void DoRespawn()
    {
        if (player == null) return;
        player.MoveTo(spawnPos, spawnRot);
        player.Revive();
    }
}
