using UnityEngine;
using UnityEngine.Profiling;
using UnityEngine.Rendering;

// Производительность. Работает само, настраивать сцену не нужно.
// 1) Уровень качества Low / Mid / High по памяти и числу ядер.
//    Вручную: PlayerPrefs "GfxTier" = 0 (Low), 1 (Mid), 2 (High).
// 2) Частота кадров: 60 FPS на всех устройствах; 120 FPS только на High и экране 120 Гц.
// 3) Авто-масштаб разрешения, если кадры проседают. Если и на минимуме не держим
//    40 FPS, опускаемся до 30 (можно отключить: allowFallbackTo30 = false).
// 4) Полная панель отладки: F3 на ПК, или PlayerPrefs "ShowFps" = 1.
public class PerformanceManager : MonoBehaviour
{
    public enum Tier { Low = 0, Mid = 1, High = 2 }

    public static PerformanceManager Instance { get; private set; }
    public static Tier CurrentTier { get; private set; } = Tier.Mid;
    public static int TargetFps { get; private set; } = 60;

    [Header("Частота кадров")]
    public int baseFps = 60;
    public int highFps = 120;
    public bool allowFallbackTo30 = true;

    [Header("Масштаб рендера по уровням (доля от разрешения экрана)")]
    [Range(0.3f, 1f)] public float lowScale = 0.6f;
    [Range(0.3f, 1f)] public float midScale = 0.8f;
    [Range(0.3f, 1f)] public float highScale = 1f;
    [Range(0.3f, 1f)] public float minScale = 0.45f;

    [Header("Панель отладки")]
    public bool showPanel = false;

    const int HistoryLength = 120;               // кадров в истории для графика и статистики

    float scale = 1f;
    float windowTime;
    int windowFrames;

    float[] history = new float[HistoryLength];  // времена кадров, сек
    int historyIndex;
    int historyCount;

    float statsTimer;                            // обновляем цифры панели 4 раза в секунду
    string panelText = "";
    float avgFps, minFps, maxFps, low1Fps, frameMs;

    Texture2D pixel;
    GUIStyle panelStyle;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Bootstrap()
    {
        if (Instance != null) return;
        var go = new GameObject("PerformanceManager");
        go.AddComponent<PerformanceManager>();
        DontDestroyOnLoad(go);
    }

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;

        Application.runInBackground = false;
        QualitySettings.vSyncCount = 0;          // иначе targetFrameRate не работает

        showPanel = PlayerPrefs.GetInt("ShowFps", 0) == 1;
        pixel = new Texture2D(1, 1, TextureFormat.RGBA32, false);
        pixel.SetPixel(0, 0, Color.white);
        pixel.Apply();

        CurrentTier = DetectTier();
        ApplyQuality();
        PickFrameRate();

        scale = TierScale();
        ApplyScale();
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    static Tier DetectTier()
    {
        if (PlayerPrefs.HasKey("GfxTier"))
            return (Tier)Mathf.Clamp(PlayerPrefs.GetInt("GfxTier"), 0, 2);

        int ramMb = SystemInfo.systemMemorySize;
        int cores = SystemInfo.processorCount;
        if (ramMb < 3000 || cores <= 4) return Tier.Low;
        if (ramMb < 6000) return Tier.Mid;
        return Tier.High;
    }

    float TierScale()
    {
        switch (CurrentTier)
        {
            case Tier.Low: return lowScale;
            case Tier.Mid: return midScale;
            default: return highScale;
        }
    }

    void ApplyQuality()
    {
        bool high = CurrentTier == Tier.High;
        bool low = CurrentTier == Tier.Low;

        QualitySettings.shadows = high ? ShadowQuality.HardOnly : ShadowQuality.Disable;
        QualitySettings.shadowDistance = high ? 40f : 0f;
        QualitySettings.antiAliasing = high ? 2 : 0;
        QualitySettings.softParticles = false;
        QualitySettings.realtimeReflectionProbes = false;
        QualitySettings.pixelLightCount = high ? 2 : 1;
        QualitySettings.lodBias = low ? 0.5f : (high ? 2f : 1f);
        QualitySettings.skinWeights = low ? SkinWeights.TwoBones : SkinWeights.FourBones;
        QualitySettings.particleRaycastBudget = low ? 4 : 16;
        QualitySettings.maxQueuedFrames = 2;
    }

    void PickFrameRate()
    {
        double hz = Screen.currentResolution.refreshRateRatio.value;
        bool can120 = CurrentTier == Tier.High && hz >= 119.5;
        TargetFps = can120 ? highFps : baseFps;
        Application.targetFrameRate = TargetFps;
    }

    void Update()
    {
        if (GameInput.DebugToggleDown) showPanel = !showPanel;

        float dt = Time.unscaledDeltaTime;
        if (dt <= 0f || dt > 0.5f) return;       // пауза или сворачивание — не считаем

        // История кадров для статистики и графика
        history[historyIndex] = dt;
        historyIndex = (historyIndex + 1) % HistoryLength;
        if (historyCount < HistoryLength) historyCount++;

        // Авто-масштаб: решение раз в 2 секунды
        windowTime += dt;
        windowFrames++;
        if (windowTime < 2f) return;

        float fps = windowFrames / windowTime;
        windowTime = 0f;
        windowFrames = 0;

        float ceiling = TierScale();
        if (fps < TargetFps * 0.9f && scale > minScale + 0.001f)
        {
            scale = Mathf.Max(minScale, scale - 0.1f);
            ApplyScale();
        }
        else if (fps > TargetFps * 0.98f && scale < ceiling - 0.001f)
        {
            scale = Mathf.Min(ceiling, scale + 0.05f);
            ApplyScale();
        }
        else if (allowFallbackTo30 && TargetFps > 30 && fps < 40f && scale <= minScale + 0.001f)
        {
            TargetFps = 30;
            Application.targetFrameRate = 30;
        }
    }

    // Цифры панели: средний, минимальный, максимальный FPS и 1% низких кадров
    void RefreshStats()
    {
        if (historyCount == 0) return;

        float sum = 0f, worst = 0f, best = float.MaxValue;
        var sorted = new float[historyCount];
        for (int i = 0; i < historyCount; i++)
        {
            float t = history[i];
            sorted[i] = t;
            sum += t;
            if (t > worst) worst = t;
            if (t < best) best = t;
        }
        System.Array.Sort(sorted);

        float avgDt = sum / historyCount;
        float low1Dt = sorted[Mathf.Clamp(Mathf.FloorToInt(historyCount * 0.99f), 0, historyCount - 1)];

        avgFps = 1f / avgDt;
        minFps = 1f / worst;
        maxFps = 1f / best;
        low1Fps = 1f / low1Dt;
        frameMs = avgDt * 1000f;

        float memMb = Profiler.GetTotalAllocatedMemoryLong() / (1024f * 1024f);
        float monoMb = Profiler.GetMonoUsedSizeLong() / (1024f * 1024f);

        panelText =
            $"FPS {avgFps:0}   (цель {TargetFps})\n" +
            $"min {minFps:0}   max {maxFps:0}   1% low {low1Fps:0}\n" +
            $"кадр {frameMs:0.0} мс\n" +
            $"уровень {CurrentTier}   масштаб {scale:0.00}\n" +
            $"память {memMb:0} МБ   mono {monoMb:0} МБ\n" +
            $"устройство {SystemInfo.deviceModel}\n" +
            $"{SystemInfo.processorCount} ядер   RAM {SystemInfo.systemMemorySize} МБ";
    }

    void OnGUI()
    {
        if (!showPanel) return;

        if (panelStyle == null)
        {
            panelStyle = new GUIStyle(GUI.skin.label)
            {
                fontSize = Mathf.Max(14, Screen.height / 45),
                normal = { textColor = Color.white },
                wordWrap = false,
            };
        }

        statsTimer -= Time.unscaledDeltaTime;
        if (statsTimer <= 0f)
        {
            RefreshStats();
            statsTimer = 0.25f;
        }

        float pad = Screen.height * 0.02f;
        float lineH = panelStyle.fontSize * 1.4f;
        float panelW = Screen.height * 0.9f;
        float panelH = lineH * 8f + Screen.height * 0.16f;

        // Фон панели
        GUI.color = new Color(0f, 0f, 0f, 0.6f);
        GUI.DrawTexture(new Rect(pad, pad, panelW, panelH), pixel);
        GUI.color = Color.white;

        GUI.Label(new Rect(pad * 2, pad * 1.5f, panelW, panelH), panelText, panelStyle);

        // График: высота столбца — время кадра; цвет — по близости к цели
        float graphX = pad;
        float graphY = pad + panelH + pad * 0.5f;
        float graphW = panelW;
        float graphH = Screen.height * 0.12f;
        float targetDt = 1f / Mathf.Max(TargetFps, 1);

        GUI.color = new Color(0f, 0f, 0f, 0.6f);
        GUI.DrawTexture(new Rect(graphX, graphY, graphW, graphH), pixel);

        float barW = graphW / HistoryLength;
        for (int i = 0; i < historyCount; i++)
        {
            int idx = (historyIndex - historyCount + i + HistoryLength) % HistoryLength;
            float dt = history[idx];
            float h = Mathf.Clamp01(dt / (targetDt * 3f)) * graphH;   // 3 цели = полная высота
            float x = graphX + i * barW;
            GUI.color = dt <= targetDt * 1.1f ? Color.green
                      : dt <= targetDt * 1.6f ? Color.yellow
                      : Color.red;
            GUI.DrawTexture(new Rect(x, graphY + graphH - h, Mathf.Max(barW - 1f, 1f), h), pixel);
        }

        // Линия цели
        float lineY = graphY + graphH - graphH / 3f;
        GUI.color = new Color(1f, 1f, 1f, 0.5f);
        GUI.DrawTexture(new Rect(graphX, lineY, graphW, 1f), pixel);

        GUI.color = Color.white;
    }

    // Рендер в пониженном разрешении (встроенный конвейер; в URP масштаб задаётся в ассете)
    void ApplyScale()
    {
        ScalableBufferManager.ResizeBuffers(scale, scale);
    }
}
