using UnityEngine;

// Экономика матча (как в CS:GO): деньги за убийства, победы и поражения.
// Сбрасывается в начале матча; боты деньги не тратят (покупает только игрок).
public static class Economy
{
    public const int StartMoney = 800;
    public const int KillReward = 300;
    public const int WinReward = 3000;
    public const int LossBase = 1400;
    public const int LossStep = 500;     // бонус растёт с серией поражений
    public const int MaxMoney = 16000;
    public const int MaxLossStreak = 4;

    public static int Money { get; private set; } = StartMoney;
    static int lossStreak;

    public static void ResetMatch()
    {
        Money = StartMoney;
        lossStreak = 0;
    }

    public static bool TrySpend(int cost)
    {
        if (Money < cost) return false;
        Money -= cost;
        return true;
    }

    public static void AddKill() => Add(KillReward);

    public static void RoundWon()
    {
        lossStreak = 0;
        Add(WinReward);
    }

    public static void RoundLost()
    {
        lossStreak = Mathf.Min(lossStreak + 1, MaxLossStreak);
        Add(LossBase + LossStep * (lossStreak - 1));
    }

    static void Add(int amount) => Money = Mathf.Min(Money + amount, MaxMoney);
}
