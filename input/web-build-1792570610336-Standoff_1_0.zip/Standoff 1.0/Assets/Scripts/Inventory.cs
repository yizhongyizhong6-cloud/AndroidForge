using System.Collections.Generic;
using UnityEngine;

// Инвентарь: купленные и выпавшие из кейсов предметы. Id вида "skin:<оружие>:<индекс>".
public static class Inventory
{
    const string Key = "Inventory";
    static HashSet<string> owned;

    static void Load()
    {
        if (owned != null) return;
        owned = new HashSet<string>();
        foreach (var id in PlayerPrefs.GetString(Key, "").Split('|'))
            if (id.Length > 0) owned.Add(id);
    }

    public static string SkinId(string weapon, int index) => "skin:" + weapon + ":" + index;

    public static bool Owns(string id)
    {
        Load();
        return owned.Contains(id);
    }

    public static void Add(string id)
    {
        Load();
        if (!owned.Add(id)) return;
        PlayerPrefs.SetString(Key, string.Join("|", owned));
        PlayerPrefs.Save();
    }
}
