public enum GameMode { Competitive, TeamDeathmatch, PVE, FreeRoam }

public enum Team { None, Terrorist, CounterTerrorist }

public static class GameModeUtil
{
    public static GameMode Load()
    {
        string s = UnityEngine.PlayerPrefs.GetString("GameMode", GameMode.Competitive.ToString());
        return System.Enum.TryParse(s, out GameMode m) ? m : GameMode.Competitive;
    }

    public static string Title(GameMode m) => m switch
    {
        GameMode.Competitive => "Соревновательный (бомба)",
        GameMode.TeamDeathmatch => "Командный бой",
        GameMode.FreeRoam => "Без ботов (осмотр карты)",
        _ => "PVE (против ботов)",
    };
}
