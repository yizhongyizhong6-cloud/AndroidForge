using UnityEngine;

// Единый ввод: клавиатура и мышь (ПК) + сенсорное управление (телефон).
// Все скрипты читают ввод отсюда, а не из Input напрямую.
public static class GameInput
{
    // Заполняет TouchControls каждый кадр
    public static Vector2 TouchMove;          // джойстик, -1..1
    public static Vector2 TouchLook;          // свайп обзора за кадр (в единицах мыши)
    public static bool TouchFireHeld;
    public static bool TouchUseHeld;
    // Одноразовые нажатия: номер кадра, в котором кнопку нажали
    public static int TouchJumpFrame = -1, TouchReloadFrame = -1, TouchGrenadeFrame = -1,
                      TouchBuyFrame = -1, TouchNextWeaponFrame = -1;
    // Свайп для смены оружия: +1 вверх (следующее), -1 вниз (предыдущее)
    public static int TouchWeaponSwipeDir;
    public static int TouchWeaponSwipeFrame = -1;

    public static int WeaponSwipeDir => TouchWeaponSwipeFrame == Time.frameCount ? TouchWeaponSwipeDir : 0;

    // Движение: WASD/стрелки или джойстик. X — вправо, Y — вперёд.
    public static Vector2 Move
    {
        get
        {
            Vector2 k = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            return Vector2.ClampMagnitude(k + TouchMove, 1f);
        }
    }

    // Обзор: мышь (только когда курсор захвачен) + свайп на телефоне
    public static Vector2 LookDelta
    {
        get
        {
            Vector2 m = Vector2.zero;
            if (Cursor.lockState == CursorLockMode.Locked)
                m = new Vector2(Input.GetAxis("Mouse X"), Input.GetAxis("Mouse Y"));
            return m + TouchLook;
        }
    }

    public static bool SprintHeld => Input.GetKey(KeyCode.LeftShift) || TouchMove.magnitude > 0.92f;
    public static bool FireHeld => Input.GetButton("Fire1") || TouchFireHeld;
    public static bool UseHeld => Input.GetKey(KeyCode.E) || TouchUseHeld;
    public static bool JumpDown => Input.GetKeyDown(KeyCode.Space) || TouchJumpFrame == Time.frameCount;
    public static bool ReloadDown => Input.GetKeyDown(KeyCode.R) || TouchReloadFrame == Time.frameCount;
    public static bool GrenadeDown => Input.GetKeyDown(KeyCode.G) || TouchGrenadeFrame == Time.frameCount;
    public static bool BuyDown => Input.GetKeyDown(KeyCode.B) || TouchBuyFrame == Time.frameCount;
    public static bool NextWeaponDown => Input.GetKeyDown(KeyCode.Q) || TouchNextWeaponFrame == Time.frameCount;
    public static bool SkinDown => Input.GetKeyDown(KeyCode.N);
    public static bool EscapeDown => Input.GetKeyDown(KeyCode.Escape);
    public static bool DebugToggleDown => Input.GetKeyDown(KeyCode.F3);   // панель FPS на ПК
    public static bool ClickDown => Input.GetMouseButtonDown(0);
}
