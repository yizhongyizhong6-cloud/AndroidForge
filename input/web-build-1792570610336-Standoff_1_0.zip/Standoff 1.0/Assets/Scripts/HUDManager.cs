using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HUDManager : MonoBehaviour
{
    public static HUDManager Instance { get; private set; }

    [Header("Weapon Info")]
    public TextMeshProUGUI ammoText;
    public TextMeshProUGUI weaponNameText;
    public Image weaponIcon;

    [Header("Health & Armor")]
    public Image healthBar;
    public TextMeshProUGUI healthText;
    public TextMeshProUGUI armorText;

    [Header("Crosshair")]
    public Image crosshair;
    [Tooltip("Крестик-подтверждение попадания (Image, выключен по умолчанию)")]
    public Image hitMarker;
    public Color hitColor = Color.white;
    public Color killColor = Color.red;
    public float hitMarkerTime = 0.12f;

    [Header("Round / Mode")]
    public TextMeshProUGUI roundInfoText;
    public TextMeshProUGUI bombTimerText;
    public TextMeshProUGUI messageText;

    [Header("Stats & Economy")]
    public TextMeshProUGUI killDeathText;
    public TextMeshProUGUI moneyText;

    WeaponHolder playerHolder;
    WeaponController lastWeapon;
    int lastAmmo = -1, lastMaxAmmo = -1, lastKills = -1, lastDeaths = -1, lastMoney = -1;
    float messageTimer;
    float hitTimer;

    void Awake()
    {
        Instance = this;
        if (hitMarker) hitMarker.enabled = false;
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    void Update()
    {
        // Держатель оружия игрока ищем один раз, а не каждый кадр
        if (playerHolder == null && HealthSystem.Player != null)
            playerHolder = HealthSystem.Player.GetComponentInChildren<WeaponHolder>(true);

        WeaponController w = playerHolder != null ? playerHolder.CurrentWeapon : null;
        if (w != null)
        {
            if (w != lastWeapon || w.currentAmmo != lastAmmo || w.maxAmmo != lastMaxAmmo)
            {
                lastWeapon = w; lastAmmo = w.currentAmmo; lastMaxAmmo = w.maxAmmo;
                SetText(ammoText, w.IsMelee ? "—" : lastAmmo + " / " + lastMaxAmmo);
            }
            SetText(weaponNameText, w.weaponName);
        }

        int kills = StatsManager.SessionKills, deaths = StatsManager.SessionDeaths;
        if (kills != lastKills || deaths != lastDeaths)
        {
            lastKills = kills; lastDeaths = deaths;
            SetText(killDeathText, "K " + kills + "   D " + deaths);
        }
        int money = Economy.Money;
        if (money != lastMoney)
        {
            lastMoney = money;
            SetText(moneyText, "$" + money);
        }

        if (messageTimer > 0f)
        {
            messageTimer -= Time.deltaTime;
            if (messageTimer <= 0f) SetText(messageText, "");
        }

        if (hitTimer > 0f)
        {
            hitTimer -= Time.deltaTime;
            if (hitTimer <= 0f && hitMarker) hitMarker.enabled = false;
        }
    }

    // Не пересоздаёт текст, если значение не изменилось (пересборка меша TMP дорогая)
    static void SetText(TextMeshProUGUI t, string value)
    {
        if (t != null && t.text != value) t.text = value;
    }

    public void UpdateHealth(float currentHealth, float maxHealth)
    {
        if (healthBar) healthBar.fillAmount = maxHealth > 0 ? currentHealth / maxHealth : 0;
        SetText(healthText, Mathf.RoundToInt(currentHealth).ToString());
    }

    public void UpdateArmor(float armor)
    {
        SetText(armorText, Mathf.RoundToInt(armor).ToString());
    }

    public void ShowMessage(string msg, float duration = 2.5f)
    {
        SetText(messageText, msg);
        messageTimer = duration;
    }

    public void ShowHitMarker(bool kill)
    {
        if (hitMarker == null) return;
        hitMarker.color = kill ? killColor : hitColor;
        hitMarker.enabled = true;
        hitTimer = hitMarkerTime;
    }

    public void SetRoundInfo(string text) => SetText(roundInfoText, text);
    public void SetBombTimer(string text) => SetText(bombTimerText, text);
}
