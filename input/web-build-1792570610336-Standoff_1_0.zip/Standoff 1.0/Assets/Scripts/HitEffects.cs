using UnityEngine;

// Эффекты попадания в духе Standoff: искры и пыль от стены, брызги от тела,
// пулевые отверстия и взрыв гранаты. Все эффекты берутся из пулов.
public class HitEffects : MonoBehaviour
{
    public static HitEffects Instance { get; private set; }

    [Header("Префабы (у каждого компонент PooledEffect, Play On Awake выключен)")]
    public GameObject surfaceSparkPrefab;   // искры и пыль от стены
    public GameObject bloodPrefab;          // брызги от тела
    public GameObject bulletHolePrefab;     // декаль пулевого отверстия
    public GameObject explosionPrefab;      // взрыв гранаты

    [Header("Размер пулов (на Low-уровне автоматически половина)")]
    public int decalPool = 40;
    public int sparkPool = 12;
    public int bloodPool = 10;
    public int explosionPool = 4;

    [Header("Время жизни, сек")]
    public float decalLife = 10f;
    public float sparkLife = 0.5f;
    public float bloodLife = 0.6f;
    public float explosionLife = 1.2f;

    [Header("Звук (необязательно)")]
    public AudioSource sfx;
    public AudioClip hitFleshClip;
    public AudioClip hitSurfaceClip;
    public AudioClip explosionClip;

    ObjectPool decals, sparks, bloods, explosions;

    void Awake()
    {
        Instance = this;
        int div = PerformanceManager.CurrentTier == PerformanceManager.Tier.Low ? 2 : 1;

        decals = new ObjectPool(bulletHolePrefab, transform, decalPool / div, decalPool / div);
        sparks = new ObjectPool(surfaceSparkPrefab, transform, sparkPool / div, sparkPool / div);
        bloods = new ObjectPool(bloodPrefab, transform, bloodPool / div, bloodPool / div);
        explosions = new ObjectPool(explosionPrefab, transform, explosionPool / div, explosionPool / div);
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
    }

    // Попадание: flesh = true — тело (кровь), иначе — поверхность (искры).
    public void PlayHit(Vector3 point, Vector3 normal, bool flesh)
    {
        Quaternion rot = Quaternion.LookRotation(normal);
        if (flesh)
        {
            Spawn(bloods, point, rot, bloodLife);
            PlaySfx(hitFleshClip);
        }
        else
        {
            Spawn(sparks, point, rot, sparkLife);
            PlaySfx(hitSurfaceClip);
        }
    }

    public void PlayDecal(Vector3 point, Vector3 normal)
    {
        Spawn(decals, point + normal * 0.01f, Quaternion.LookRotation(normal), decalLife);
    }

    public void PlayExplosion(Vector3 point)
    {
        Spawn(explosions, point, Quaternion.identity, explosionLife);
        PlaySfx(explosionClip);
    }

    GameObject Spawn(ObjectPool pool, Vector3 pos, Quaternion rot, float life)
    {
        if (pool == null) return null;
        var go = pool.Get();
        if (go == null) return null;          // пул заполнен — эффект пропускаем
        go.transform.SetPositionAndRotation(pos, rot);
        go.SetActive(true);
        var fx = go.GetComponent<PooledEffect>();
        if (fx != null) fx.Play(pool.Release, life);
        else pool.Release(go);                // префаб без PooledEffect не держим активным
        return go;
    }

    void PlaySfx(AudioClip clip)
    {
        if (sfx != null && clip != null) sfx.PlayOneShot(clip);
    }
}
