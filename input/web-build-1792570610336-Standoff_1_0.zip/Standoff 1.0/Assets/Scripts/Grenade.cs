using System.Collections.Generic;
using UnityEngine;

// Осколочная граната (HE в Standoff): бросок по параболе, отскок от поверхностей,
// взрыв через fuse секунд. Урон по радиусу с падением к краю; за стеной урон вдвое меньше.
// Гранаты берутся из пула и возвращаются в него после взрыва.
// На префабе: MeshRenderer и этот компонент, без Rigidbody (движение ручное).
public class Grenade : MonoBehaviour
{
    [Header("Параметры")]
    public float fuse = 2f;
    public float gravity = 18f;
    public float bounce = 0.35f;
    public float radius = 6f;
    public float maxDamage = 98f;
    public LayerMask blockMask = ~0;        // поверхности, которые блокируют урон и отскакивают

    readonly Collider[] buffer = new Collider[32];
    readonly List<HealthSystem> damaged = new List<HealthSystem>(16);

    Vector3 velocity;
    float timer;
    bool active;
    HealthSystem owner;
    ObjectPool pool;

    public void Launch(Vector3 position, Vector3 vel, HealthSystem thrower, ObjectPool returnTo)
    {
        transform.position = position;
        velocity = vel;
        owner = thrower;
        pool = returnTo;
        timer = fuse;
        active = true;
    }

    void Update()
    {
        if (!active) return;

        float dt = Time.deltaTime;
        timer -= dt;

        velocity.y -= gravity * dt;
        Vector3 step = velocity * dt;
        float dist = step.magnitude;

        // Проверка по лучу: граната не проходит сквозь стены при большой скорости
        if (dist > 0f && Physics.Raycast(transform.position, step / dist, out RaycastHit hit,
                dist + 0.02f, blockMask, QueryTriggerInteraction.Ignore))
        {
            Vector3 reflected = Vector3.Reflect(velocity, hit.normal) * bounce;
            transform.position = hit.point + hit.normal * 0.03f;
            velocity = reflected.sqrMagnitude < 0.25f ? Vector3.zero : reflected;
        }
        else
        {
            transform.position += step;
        }

        if (timer <= 0f) Explode();
    }

    void Explode()
    {
        active = false;
        Vector3 center = transform.position;
        HitEffects.Instance?.PlayExplosion(center);

        damaged.Clear();
        int n = Physics.OverlapSphereNonAlloc(center, radius, buffer, ~0, QueryTriggerInteraction.Ignore);
        for (int i = 0; i < n; i++)
        {
            var hs = buffer[i].GetComponentInParent<HealthSystem>();
            if (hs == null || hs.IsDead || hs == owner || damaged.Contains(hs)) continue;
            if (owner != null && hs.team != Team.None && hs.team == owner.team) continue;   // свои не страдают
            damaged.Add(hs);

            Vector3 chest = hs.transform.position + Vector3.up * 0.9f;
            float falloff = 1f - Mathf.Clamp01(Vector3.Distance(center, chest) / radius);
            if (falloff <= 0f) continue;

            float dmg = maxDamage * falloff;
            if (Physics.Linecast(center, chest, out RaycastHit wall, blockMask, QueryTriggerInteraction.Ignore)
                && wall.transform.root != hs.transform.root)
            {
                dmg *= 0.5f;
            }

            if (hs.IsRemote)
            {
                if (NetMatch.Instance != null) NetMatch.Instance.ReportHit(hs.NetId, dmg);
            }
            else hs.TakeDamage(dmg, owner);
        }

        if (pool != null) pool.Release(gameObject);
        else gameObject.SetActive(false);
    }
}
