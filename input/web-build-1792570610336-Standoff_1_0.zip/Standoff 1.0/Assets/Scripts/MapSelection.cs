using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class MapSelection : MonoBehaviour
{
    [Header("Maps")]
    public Button sandstoneButton;
    public Button dust2Button;
    public Button dust2V2Button;
    public Button randomMapButton;
    public Button playButton;
    public TextMeshProUGUI mapText;
    public Image mapPreview;
    public Sprite sandstonePreview;
    public Sprite dust2Preview;

    [Header("Mode")]
    public Button competitiveButton;
    public Button deathmatchButton;
    public Button pveButton;
    public Button freeRoamButton;   // «Без ботов»: осмотр карты
    public TextMeshProUGUI modeText;

    [Header("Team (сторона в соревновательном)")]
    public Button terroristButton;
    public Button counterTerroristButton;
    public TextMeshProUGUI teamText;

    [Header("Bot difficulty")]
    public Button easyButton;
    public Button normalButton;
    public Button hardButton;
    public TextMeshProUGUI difficultyText;

    static readonly string[] maps = { "Sandstone", "Dust2", "Dust2v2" };
    // Dust2v2 — тот же сцена Dust2, вариант выбирает DustMapBuilder по PlayerPrefs "Map"
    static string SceneFor(string map) => map == "Dust2v2" ? "Dust2" : map;

    GameMode selectedMode = GameMode.Competitive;
    string selectedMap = "Sandstone";
    Team selectedTeam = Team.CounterTerrorist;
    BotDifficulty selectedDifficulty = BotDifficulty.Normal;

    void Start()
    {
        if (sandstoneButton) sandstoneButton.onClick.AddListener(() => SelectMap("Sandstone"));
        if (dust2Button) dust2Button.onClick.AddListener(() => SelectMap("Dust2"));
        if (dust2V2Button) dust2V2Button.onClick.AddListener(() => SelectMap("Dust2v2"));
        if (randomMapButton) randomMapButton.onClick.AddListener(() => SelectMap(maps[Random.Range(0, maps.Length)]));
        if (playButton) playButton.onClick.AddListener(Play);

        if (competitiveButton) competitiveButton.onClick.AddListener(() => SelectMode(GameMode.Competitive));
        if (deathmatchButton) deathmatchButton.onClick.AddListener(() => SelectMode(GameMode.TeamDeathmatch));
        if (pveButton) pveButton.onClick.AddListener(() => SelectMode(GameMode.PVE));
        if (freeRoamButton) freeRoamButton.onClick.AddListener(() => SelectMode(GameMode.FreeRoam));

        if (terroristButton) terroristButton.onClick.AddListener(() => SelectTeam(Team.Terrorist));
        if (counterTerroristButton) counterTerroristButton.onClick.AddListener(() => SelectTeam(Team.CounterTerrorist));

        if (easyButton) easyButton.onClick.AddListener(() => SelectDifficulty(BotDifficulty.Easy));
        if (normalButton) normalButton.onClick.AddListener(() => SelectDifficulty(BotDifficulty.Normal));
        if (hardButton) hardButton.onClick.AddListener(() => SelectDifficulty(BotDifficulty.Hard));

        SelectMode(selectedMode);
        SelectMap(selectedMap);
        SelectTeam(selectedTeam);
        SelectDifficulty(selectedDifficulty);
    }

    void SelectMode(GameMode mode)
    {
        selectedMode = mode;
        if (modeText) modeText.text = GameModeUtil.Title(mode);
    }

    void SelectMap(string map)
    {
        selectedMap = map;
        if (mapText) mapText.text = map == "Dust2v2" ? "Dust II (v2)" : map == "Dust2" ? "Dust II" : "Sandstone";
        if (mapPreview) mapPreview.sprite = map.StartsWith("Dust2") ? dust2Preview : sandstonePreview;
    }

    void SelectTeam(Team team)
    {
        selectedTeam = team;
        if (teamText) teamText.text = team == Team.Terrorist ? "Террористы" : "Контр-террористы";
    }

    void SelectDifficulty(BotDifficulty d)
    {
        selectedDifficulty = d;
        if (difficultyText) difficultyText.text = BotDifficultyUtil.Title(d);
    }

    void Play()
    {
        string scene = SceneFor(selectedMap);
        if (!Application.CanStreamedLevelBeLoaded(scene))
        {
            Debug.LogError($"Сцена '{scene}' не добавлена в Build Settings (File > Build Profiles / Build Settings)");
            return;
        }
        // Быстрая игра использует настройки по умолчанию, а не из кастомной игры
        PlayerPrefs.DeleteKey("BotLimit");
        PlayerPrefs.DeleteKey("RoundsToWin");
        PlayerPrefs.DeleteKey("FreezeTime");
        PlayerPrefs.DeleteKey("RoundTime");
        PlayerPrefs.SetString("GameMode", selectedMode.ToString());
        PlayerPrefs.SetString("Map", selectedMap);          // Dust2v2 читает DustMapBuilder
        PlayerPrefs.SetString("PlayerTeam", selectedTeam.ToString());
        PlayerPrefs.SetString("BotDifficulty", selectedDifficulty.ToString());
        PlayerPrefs.Save();
        SceneLoader.Load(scene);
    }
}
