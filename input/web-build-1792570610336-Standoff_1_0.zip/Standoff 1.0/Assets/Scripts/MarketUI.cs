using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Рынок в меню: покупка предметов за монеты. Покупка скина сразу его экипирует.
// Внимание: это магазин против монет игрока. Торговли между игроками здесь нет (нужен сервер).
public class MarketUI : MonoBehaviour
{
    public MarketItemDef[] items;
    public Transform rowsRoot;
    public GameObject rowPrefab;     // строка: 2 TMP (название, цена) + Button ("Купить")
    public TextMeshProUGUI coinsText;
    public TextMeshProUGUI statusText;

    readonly System.Collections.Generic.List<Button> buttons = new System.Collections.Generic.List<Button>();

    void Start()
    {
        if (items == null || rowPrefab == null || rowsRoot == null) return;
        for (int i = 0; i < items.Length; i++)
        {
            int idx = i;
            var go = Instantiate(rowPrefab, rowsRoot);
            var texts = go.GetComponentsInChildren<TextMeshProUGUI>();
            var btn = go.GetComponentInChildren<Button>();
            if (texts.Length >= 2)
            {
                texts[0].text = items[i].title;
                texts[1].text = items[i].price + " монет";
            }
            if (btn != null) btn.onClick.AddListener(() => Buy(idx));
            buttons.Add(btn);
        }
        Refresh();
    }

    void Update()
    {
        if (coinsText) coinsText.text = "Монеты: " + Wallet.Coins;
    }

    public void Buy(int index)
    {
        if (index < 0 || index >= items.Length) return;
        var item = items[index];

        if (Inventory.Owns(item.id)) { Status("Уже куплено"); return; }
        if (!Wallet.TrySpend(item.price)) { Status("Не хватает монет"); return; }

        Inventory.Add(item.id);
        EquipIfSkin(item.id);
        Status("Куплено: " + item.title);
        Refresh();
    }

    // Для скина: экипировать сразу после покупки
    public static void EquipIfSkin(string id)
    {
        var parts = id.Split(':');
        if (parts.Length == 3 && parts[0] == "skin" && int.TryParse(parts[2], out int idx))
            SkinPrefs.Select(parts[1], idx);
    }

    void Refresh()
    {
        for (int i = 0; i < items.Length && i < buttons.Count; i++)
        {
            var b = buttons[i];
            if (b == null) continue;
            var txt = b.GetComponentInChildren<TextMeshProUGUI>();
            bool owned = Inventory.Owns(items[i].id);
            b.interactable = !owned;
            if (txt) txt.text = owned ? "Куплено" : "Купить";
        }
    }

    void Status(string t) { if (statusText) statusText.text = t; }
}
