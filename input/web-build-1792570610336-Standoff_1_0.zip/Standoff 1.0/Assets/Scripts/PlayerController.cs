using UnityEngine;

// Ходьба игрока во всех режимах: джойстик/WASD, бег, прыжок, обзор мышью или свайпом.
// Движение через CharacterController — сквозь стены и пол не проходит.
// Страховка: если игрок упал ниже killY, возвращается на последнюю твёрдую точку.
// Во время фриза и после смерти движение заблокировано (обзор работает).
[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public Transform cameraPivot;               // камера игрока (дочерний объект тела)
    public float walkSpeed = 5.5f;
    public float runSpeed = 8.5f;
    [Tooltip("Высота прыжка, м. Ящики до ~1.3 м берутся прыжком; выше — нужна лестница из ящиков")]
    public float jumpHeight = 1.5f;
    public float gravity = 20f;
    public float mouseSensitivity = 2f;
    public float maxLookAngle = 85f;
    public float killY = -15f;                  // ниже этого — провалился под карту

    CharacterController cc;
    float yaw, pitch, verticalVelocity;
    Vector3 safePos;
    Quaternion safeRot;
    bool pcCursor;

    void Awake()
    {
        cc = GetComponent<CharacterController>();
    }

    void Start()
    {
        if (cameraPivot == null && Camera.main != null) cameraPivot = Camera.main.transform;
        yaw = transform.eulerAngles.y;
        if (cameraPivot != null)
        {
            float x = cameraPivot.localEulerAngles.x;
            if (x > 180f) x -= 360f;
            pitch = x;
        }
        safePos = transform.position;
        safeRot = transform.rotation;

        // На ПК курсор захватываем мышью; на телефоне курсора нет
        pcCursor = !Application.isMobilePlatform;
        if (pcCursor) Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        if (pcCursor)
        {
            if (GameInput.EscapeDown) Cursor.lockState = CursorLockMode.None;
            else if (Cursor.lockState != CursorLockMode.Locked && GameInput.ClickDown)
                Cursor.lockState = CursorLockMode.Locked;
        }

        Look();
        Move();
        CheckFallen();
    }

    // Вызывается из HealthSystem.MoveTo (спавн, респавн): синхронизируем поворот
    public void OnTeleported(Quaternion rot)
    {
        yaw = rot.eulerAngles.y;
        safePos = transform.position;
        safeRot = rot;
        verticalVelocity = 0f;
    }

    void Look()
    {
        Vector2 l = GameInput.LookDelta;
        yaw += l.x * mouseSensitivity;
        pitch = Mathf.Clamp(pitch - l.y * mouseSensitivity, -maxLookAngle, maxLookAngle);
        transform.rotation = Quaternion.Euler(0f, yaw, 0f);
        if (cameraPivot != null) cameraPivot.localRotation = Quaternion.Euler(pitch, 0f, 0f);
    }

    void Move()
    {
        bool locked = CompetitiveRoundManager.InputLocked;   // фриз, конец раунда, смерть
        Vector2 m = locked ? Vector2.zero : GameInput.Move;

        Vector3 forward = transform.forward;
        forward.y = 0f;
        forward.Normalize();
        Vector3 dir = forward * m.y + transform.right * m.x;

        float speed = GameInput.SprintHeld ? runSpeed : walkSpeed;

        if (cc.isGrounded)
        {
            if (verticalVelocity < 0f) verticalVelocity = -2f;   // прилипание к полу
            if (!locked && GameInput.JumpDown)
                verticalVelocity = Mathf.Sqrt(2f * gravity * jumpHeight);
        }
        verticalVelocity -= gravity * Time.deltaTime;

        cc.Move((dir * speed + Vector3.up * verticalVelocity) * Time.deltaTime);

        if (cc.isGrounded)
        {
            safePos = transform.position;
            safeRot = transform.rotation;
        }
    }

    void CheckFallen()
    {
        if (transform.position.y >= killY) return;
        var hs = GetComponent<HealthSystem>();
        if (hs != null) hs.MoveTo(safePos + Vector3.up * 0.5f, safeRot);
        verticalVelocity = 0f;
    }
}
