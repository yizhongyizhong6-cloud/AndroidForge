using System.Collections.Generic;
using UnityEngine;

// Выбор скина для каждого оружия. Стандартный скин (индекс 0) доступен всегда,
// остальные — только если есть в Inventory.
// В режиме осмотра («Без ботов») видны все скины без покупки, а выбор не сохраняется.
public static class SkinPrefs
{
    public static bool PreviewAll => GameModeUtil.Load() == GameMode.FreeRoam;

    static readonly Dictionary<string, int> preview = new Dictionary<string, int>();

    static string Key(string weapon) => "Skin_" + weapon;

    public static int GetSelected(string weapon, int count)
    {
        if (count <= 0) return 0;

        if (PreviewAll)
            return preview.TryGetValue(weapon, out int p) ? Mathf.Clamp(p, 0, count - 1) : 0;

        int i = Mathf.Clamp(PlayerPrefs.GetInt(Key(weapon), 0), 0, count - 1);
        if (i != 0 && !Inventory.Owns(Inventory.SkinId(weapon, i))) return 0;
        return i;
    }

    public static void Select(string weapon, int index)
    {
        PlayerPrefs.SetInt(Key(weapon), index);
        PlayerPrefs.Save();
    }

    public static void Cycle(string weapon, int count)
    {
        if (count <= 0) return;
        int cur = GetSelected(weapon, count);
        int next = 0;
        for (int k = 1; k <= count; k++)
        {
            int c = (cur + k) % count;
            if (c == 0 || Inventory.Owns(Inventory.SkinId(weapon, c))) { next = c; break; }
        }
        Select(weapon, next);
    }

    // Просмотр: перебирает все скины, не сохраняя выбор в PlayerPrefs
    public static void CyclePreview(string weapon, int count)
    {
        if (count <= 0) return;
        int cur = GetSelected(weapon, count);
        preview[weapon] = (cur + 1) % count;
    }
}
