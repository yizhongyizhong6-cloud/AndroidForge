using System;

[Serializable]
public class MarketItemDef
{
    public string id;      // например "skin:AK-47:1"
    public string title;   // что показывать в списке
    public int price;      // цена в монетах
}

