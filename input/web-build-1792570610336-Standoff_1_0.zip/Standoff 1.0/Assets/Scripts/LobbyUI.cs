using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Экран сетевого лобби в главном меню: «Открыть для сети», поиск игр, вход по IP, готовность, старт.
public class LobbyUI : MonoBehaviour
{
    [Header("Panels")]
    public GameObject menuPanel;
    public GameObject lobbyPanel;

    [Header("Inputs")]
    public TMP_InputField nameInput;
    public TMP_InputField ipInput;

    [Header("Buttons")]
    public Button hostButton;
    public Button scanButton;
    public Button joinIpButton;
    public Button[] joinFoundButtons;   // до 4 найденных игр
    public Button readyButton;
    public Button mapButton;
    public Button startButton;          // видна только хосту
    public Button leaveButton;

    [Header("Texts")]
    public TextMeshProUGUI statusText;
    public TextMeshProUGUI hostIpText;
    public TextMeshProUGUI foundText;
    public TextMeshProUGUI rosterText;
    public TextMeshProUGUI mapText;

    static readonly string[] maps = { "Sandstone", "Dust2" };
    NetManager net;
    readonly List<string> foundIps = new List<string>();
    bool myReady;
    float refreshTimer;

    void Start()
    {
        net = NetManager.Instance;
        if (nameInput) nameInput.text = PlayerPrefs.GetString("PlayerName", "Player");
        if (net == null) { SetStatus("NetManager не найден (добавь его на сцену меню)"); return; }

        net.MessageReceived += OnNetMessage;
        net.Disconnected += OnDisconnected;

        if (hostButton) hostButton.onClick.AddListener(Host);
        if (scanButton) scanButton.onClick.AddListener(Scan);
        if (joinIpButton) joinIpButton.onClick.AddListener(JoinByIp);
        for (int i = 0; i < joinFoundButtons.Length; i++)
        {
            int idx = i;
            if (joinFoundButtons[i]) joinFoundButtons[i].onClick.AddListener(() => JoinFound(idx));
        }
        if (readyButton) readyButton.onClick.AddListener(ToggleReady);
        if (mapButton) mapButton.onClick.AddListener(CycleMap);
        if (startButton) startButton.onClick.AddListener(() => net.RequestStart());
        if (leaveButton) leaveButton.onClick.AddListener(Leave);

        Refresh();
    }

    void OnDestroy()
    {
        if (net != null)
        {
            net.MessageReceived -= OnNetMessage;
            net.Disconnected -= OnDisconnected;
        }
    }

    void Update()
    {
        if (net == null) return;
        refreshTimer -= Time.deltaTime;
        if (refreshTimer > 0f) return;
        refreshTimer = 0.5f;
        Refresh();
    }

    void Refresh()
    {
        bool inLobby = net.IsConnected;
        if (menuPanel) menuPanel.SetActive(!inLobby);
        if (lobbyPanel) lobbyPanel.SetActive(inLobby);
        if (hostIpText)
            hostIpText.text = net.IsHost ? $"Адрес для друзей: {NetManager.GetLocalIP()}:{NetManager.TcpPort}" : "";
        if (startButton)
        {
            startButton.gameObject.SetActive(net.IsHost);
            startButton.interactable = net.IsHost && net.IsConnected;
        }
        RefreshFound();
        RefreshRoster();
    }

    void RefreshFound()
    {
        string self = NetManager.GetLocalIP();
        foundIps.Clear();
        foreach (var kv in net.Discovered)
            if (kv.Key != self) foundIps.Add(kv.Key);

        for (int i = 0; i < joinFoundButtons.Length; i++)
        {
            var b = joinFoundButtons[i];
            if (b == null) continue;
            bool has = i < foundIps.Count;
            b.gameObject.SetActive(has);
            if (has)
            {
                var g = net.Discovered[foundIps[i]];
                SetButtonText(b, $"{g.name} ({g.players}) — {g.ip}");
            }
        }
        if (foundText)
            foundText.text = foundIps.Count == 0 ? "Игр в сети не найдено. Введи IP вручную." : "Найденные игры:";
    }

    void RefreshRoster()
    {
        if (rosterText)
        {
            var sb = new StringBuilder();
            foreach (var e in net.Roster)
                sb.AppendLine($"{(e.isHost ? "★ " : "")}{e.name}   {(e.team == Team.Terrorist ? "T" : "CT")}   {(e.ready ? "готов" : "не готов")}");
            rosterText.text = sb.Length == 0 ? "Игроков пока нет" : sb.ToString();
        }
        if (mapText)
            mapText.text = "Карта: " + (net.LobbyMap == "Dust2" ? "Dust II" : "Sandstone") + "   Режим: командный бой";
    }

    string MyName()
    {
        string n = nameInput ? nameInput.text.Trim() : "";
        if (string.IsNullOrEmpty(n)) n = "Player";
        PlayerPrefs.SetString("PlayerName", n);
        PlayerPrefs.Save();
        return n;
    }

    void Host()
    {
        myReady = false;
        net.HostGame(MyName());
        SetStatus("Лобби открыто. Друзья подключаются по адресу ниже.");
        Refresh();
    }

    void Scan()
    {
        net.StartDiscovery();
        SetStatus("Ищу игры в локальной сети...");
    }

    void JoinByIp()
    {
        string ip = ipInput ? ipInput.text.Trim() : "";
        if (ip.Length == 0) { SetStatus("Введи IP хоста"); return; }
        net.JoinGame(ip, MyName());
        SetStatus("Подключаюсь к " + ip + "...");
    }

    void JoinFound(int i)
    {
        if (i < 0 || i >= foundIps.Count) return;
        net.JoinGame(foundIps[i], MyName());
        SetStatus("Подключаюсь...");
    }

    void ToggleReady()
    {
        myReady = !myReady;
        net.SetReady(myReady);
    }

    void CycleMap()
    {
        int i = System.Array.IndexOf(maps, net.LobbyMap);
        net.SetMap(maps[(i + 1) % maps.Length]);
    }

    void Leave()
    {
        net.Shutdown();
        myReady = false;
        SetStatus("Вышел из лобби");
        Refresh();
    }

    void OnDisconnected()
    {
        SetStatus("Соединение потеряно");
        Refresh();
    }

    void OnNetMessage(NetMsg m)
    {
        switch (m.type)
        {
            case "lobby":
            case "welcome":
                Refresh();
                break;
            case "start":
                StartGame(m.map);
                break;
        }
    }

    void StartGame(string map)
    {
        if (string.IsNullOrEmpty(map) || !Application.CanStreamedLevelBeLoaded(map))
        {
            SetStatus("Сцена " + map + " не добавлена в Build Settings");
            return;
        }
        PlayerPrefs.SetString("GameMode", GameMode.TeamDeathmatch.ToString());
        PlayerPrefs.SetString("Map", map);
        PlayerPrefs.Save();
        SceneLoader.Load(map);
    }

    void SetStatus(string t) { if (statusText) statusText.text = t; }

    static void SetButtonText(Button b, string t)
    {
        var txt = b.GetComponentInChildren<TextMeshProUGUI>();
        if (txt) txt.text = t;
    }
}
