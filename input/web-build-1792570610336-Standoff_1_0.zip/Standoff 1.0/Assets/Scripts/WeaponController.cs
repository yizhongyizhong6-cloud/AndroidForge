using System.Collections;
using UnityEngine;

public class WeaponController : MonoBehaviour
{
    [Header("Weapon Settings")]
    public string weaponName = "AK-47";          // ключ для WeaponStats (Knife, Pistol, MP5, AK-47)
    public WeaponCategory category = WeaponCategory.Rifle;   // переопределяется из WeaponStats
    public int price = 0;                        // переопределяется из WeaponStats
    public int maxAmmo = 30;
    public int currentAmmo;
    [Tooltip("Секунды между выстрелами (переопределяется из WeaponStats)")]
    public float fireRate = 0.1f;
    public float reloadTime = 2.5f;
    public float damage = 33f;                   // урон за попадание
    public float range = 100f;
    [Tooltip("Время доставания оружия, как в CS:GO ~0.5с")]
    public float drawTime = 0.5f;

    [Header("Skins")]
    public Renderer[] skinRenderers;
    public Material[] skins;              // варианты скина; индекс 0 — стандарт

    [Header("Audio")]
    public AudioClip shootSound, boltSound, reloadSound;
    public AudioSource audioSource;

    [Header("Animation")]
    public Animator weaponAnimator;

    [Header("Effects")]
    public ParticleSystem muzzleFlash;
    public GameObject bulletHoleDecal;

    [Header("Recoil")]
    public float recoilAmount = 2f;
    public float recoilSpeed = 10f;

    public bool IsMelee => category == WeaponCategory.Melee;
    public bool IsPistol => category == WeaponCategory.Pistol;

    float nextTimeToFire;
    bool isReloading;
    Camera fpsCam;
    Vector3 originalPosition;
    WeaponHolder holder;
    bool started;

    // Игрок управляет оружием с клавиатуры; у бота огнём управляет BotAI
    bool PlayerControlled => holder == null || holder.isPlayer;

    void Awake()
    {
        ApplyStats();
    }

    // Берёт характеристики из WeaponStats по weaponName. Неизвестное оружие — значения из Inspector.
    void ApplyStats()
    {
        if (!WeaponStats.TryGet(weaponName, out WeaponStat s)) return;
        category = s.category;
        price = s.price;
        damage = s.damage;
        fireRate = s.interval;
        range = s.range;
        reloadTime = s.reload;
        if (!IsMelee) maxAmmo = s.magazine;
    }

    void Start()
    {
        currentAmmo = maxAmmo;
        fpsCam = Camera.main;
        holder = GetComponentInParent<WeaponHolder>();
        originalPosition = transform.localPosition;
        started = true;
        if (audioSource == null) audioSource = GetComponent<AudioSource>();
        RefreshSkin();
    }

    // Публичный: скин можно сменить на лету (режим осмотра)
    public void RefreshSkin()
    {
        if (skins == null || skins.Length == 0 || skinRenderers == null) return;
        int idx = PlayerControlled
            ? SkinPrefs.GetSelected(weaponName, skins.Length)
            : Random.Range(0, skins.Length);
        Material mat = skins[Mathf.Clamp(idx, 0, skins.Length - 1)];
        if (mat == null) return;
        foreach (var r in skinRenderers) if (r) r.sharedMaterial = mat;
    }

    void Update()
    {
        if (!PlayerControlled)
        {
            if (!IsMelee && !isReloading && currentAmmo <= 0) StartReload();
            return;
        }

        if (CompetitiveRoundManager.InputLocked) return;
        if (HealthSystem.Player != null && HealthSystem.Player.IsDead) return;
        if (holder != null && (!holder.CanFire || holder.CurrentWeapon != this)) return;
        if (isReloading) return;
        if (!IsMelee && currentAmmo <= 0) { StartReload(); return; }

        if (fpsCam == null) fpsCam = Camera.main;
        if (fpsCam == null) return;

        if (GameInput.FireHeld && Time.time >= nextTimeToFire)
        {
            nextTimeToFire = Time.time + Mathf.Max(fireRate, 0.01f);
            Fire(fpsCam.transform.position, fpsCam.transform.forward);
        }
        if (!IsMelee && GameInput.ReloadDown && currentAmmo < maxAmmo) StartReload();
    }

    // Вызывается BotAI. Скорость стрельбы и разброс контролирует бот.
    public bool TryBotShoot(Vector3 origin, Vector3 aimDir, float spreadDegrees)
    {
        if (!IsMelee && (isReloading || currentAmmo <= 0)) return false;
        Vector2 r = Random.insideUnitCircle * spreadDegrees;
        Vector3 dir = Quaternion.Euler(r.y, r.x, 0f) * aimDir.normalized;
        Fire(origin, dir);
        return true;
    }

    void Fire(Vector3 origin, Vector3 dir)
    {
        if (!IsMelee) currentAmmo--;
        if (audioSource && shootSound) audioSource.PlayOneShot(shootSound);
        if (weaponAnimator) weaponAnimator.SetTrigger("Shoot");
        if (muzzleFlash) muzzleFlash.Play();
        if (boltSound) Invoke(nameof(PlayBoltSound), 0.1f);
        StartCoroutine(Recoil());

        if (Physics.Raycast(origin, dir, out RaycastHit hit, range))
        {
            HealthSystem attacker = PlayerControlled
                ? HealthSystem.Player
                : GetComponentInParent<HealthSystem>();
            HealthSystem target = hit.transform.GetComponentInParent<HealthSystem>();
            if (target != null)
            {
                if (target.IsRemote)
                {
                    if (NetMatch.Instance != null) NetMatch.Instance.ReportHit(target.NetId, damage);
                }
                else target.TakeDamage(damage, attacker);

                if (PlayerControlled) HUDManager.Instance?.ShowHitMarker(target.IsDead);
                HitEffects.Instance?.PlayHit(hit.point, hit.normal, true);
            }
            else
            {
                HitEffects.Instance?.PlayHit(hit.point, hit.normal, false);
                if (!IsMelee) HitEffects.Instance?.PlayDecal(hit.point, hit.normal);
            }
        }
    }

    // Полный магазин и сброс перезарядки. Вызывается в начале каждого раунда.
    public void Refill()
    {
        CancelInvoke(nameof(FinishReload));
        isReloading = false;
        currentAmmo = IsMelee ? 0 : maxAmmo;
    }

    void OnDisable()
    {
        StopAllCoroutines();
        isReloading = false;   // Invoke перезарядки отменяется при выключении — иначе оружие зависнет
        if (started) transform.localPosition = originalPosition;   // убрать остаточный сдвиг отдачи
    }

    void PlayBoltSound() { if (audioSource && boltSound) audioSource.PlayOneShot(boltSound, 0.7f); }

    void StartReload()
    {
        if (isReloading || IsMelee) return;
        isReloading = true;
        if (weaponAnimator) weaponAnimator.SetTrigger("Reload");
        if (audioSource && reloadSound) audioSource.PlayOneShot(reloadSound);
        Invoke(nameof(FinishReload), reloadTime);
    }

    void FinishReload() { currentAmmo = maxAmmo; isReloading = false; }

    IEnumerator Recoil()
    {
        Vector3 targetPos = originalPosition - new Vector3(0, 0, recoilAmount * 0.01f);
        float elapsed = 0;
        while (elapsed < 0.05f)
        {
            transform.localPosition = Vector3.Lerp(transform.localPosition, targetPos, elapsed / 0.05f);
            elapsed += Time.deltaTime; yield return null;
        }
        elapsed = 0;
        while (elapsed < 0.15f)
        {
            transform.localPosition = Vector3.Lerp(transform.localPosition, originalPosition, elapsed / 0.15f);
            elapsed += Time.deltaTime; yield return null;
        }
        transform.localPosition = originalPosition;
    }
}
