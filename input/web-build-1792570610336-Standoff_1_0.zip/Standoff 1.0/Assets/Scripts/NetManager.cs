using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;

// LAN-сеть в стиле «Открыть для сети» из Minecraft.
// Хост открывает TCP-сервер (порт 7777) и UDP-анонс (порт 47777) в локальной сети / точке доступа.
// Хост также подключается к себе (loopback), поэтому играет сам.
// Все изменения состояния — на главном потоке; сетевые потоки только читают/пишут сокеты.
public class NetManager : MonoBehaviour
{
    public static NetManager Instance { get; private set; }

    public const int TcpPort = 7777;
    public const int DiscoveryPort = 47777;
    const string Magic = "STANDOFF_LAN";

    public bool IsHost { get; private set; }
    public bool IsConnected { get; private set; }
    public int LocalId { get; private set; } = -1;
    public string PlayerName { get; private set; } = "Player";
    public string LobbyMap { get; private set; } = "Sandstone";
    public int LobbyLimit { get; private set; } = 30;
    public readonly List<LobbyEntry> Roster = new List<LobbyEntry>();
    public readonly Dictionary<string, FoundGame> Discovered = new Dictionary<string, FoundGame>();

    public struct FoundGame { public string ip; public string name; public int players; public float lastSeen; }

    public event Action<NetMsg> MessageReceived;
    public event Action Disconnected;

    readonly ConcurrentQueue<Action> mainQueue = new ConcurrentQueue<Action>();

    // ---- сервер (хост) ----
    TcpListener listener;
    UdpClient broadcaster;
    readonly List<Conn> clients = new List<Conn>();
    int nextId = 1;
    int killLimit = 30;
    bool matchRunning;
    int tKills, ctKills;
    float announceTimer;
    string hostName = "Standoff";

    // ---- клиент ----
    Conn server;
    UdpClient discoveryListener;

    sealed class Conn
    {
        public int id;
        public string name = "";
        public bool ready, isHost, alive = true;
        public Team team = Team.None;
        public TcpClient tcp;
        public StreamWriter writer;
    }

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    void OnApplicationQuit() => Shutdown();

    void Update()
    {
        while (mainQueue.TryDequeue(out var action))
        {
            try { action(); }
            catch (Exception e) { Debug.LogError("NetManager: " + e); }
        }

        if (IsHost && broadcaster != null)
        {
            announceTimer -= Time.deltaTime;
            if (announceTimer <= 0f) { announceTimer = 1f; Announce(); }
        }

        float now = Time.realtimeSinceStartup;
        var stale = new List<string>();
        foreach (var kv in Discovered) if (now - kv.Value.lastSeen > 3f) stale.Add(kv.Key);
        foreach (var key in stale) Discovered.Remove(key);
    }

    // ================= Хост =================

    public void HostGame(string name, int limit = 30)
    {
        Shutdown();
        killLimit = limit;
        hostName = Clean(name);
        try
        {
            listener = new TcpListener(IPAddress.Any, TcpPort);
            listener.Start();
        }
        catch (Exception e)
        {
            listener = null;
            Debug.LogError("Не удалось открыть порт " + TcpPort + ": " + e.Message);
            Disconnected?.Invoke();
            return;
        }

        var l = listener;
        new Thread(() => AcceptLoop(l)) { IsBackground = true }.Start();

        try { broadcaster = new UdpClient { EnableBroadcast = true }; }
        catch (Exception e) { Debug.LogWarning("Анонс в сети недоступен: " + e.Message); }

        announceTimer = 0f;
        JoinGame("127.0.0.1", hostName, asHost: true);
    }

    void AcceptLoop(TcpListener l)
    {
        while (true)
        {
            TcpClient tcp;
            try { tcp = l.AcceptTcpClient(); }
            catch { break; }
            mainQueue.Enqueue(() => AddClient(tcp));
        }
    }

    void AddClient(TcpClient tcp)
    {
        if (listener == null) { tcp.Close(); return; }
        var c = new Conn { id = nextId++, tcp = tcp };
        c.writer = new StreamWriter(tcp.GetStream(), Encoding.UTF8) { AutoFlush = true };
        clients.Add(c);
        StartReader(c, true);
        SendTo(c, new NetMsg { type = "welcome", id = c.id });
    }

    void Announce()
    {
        byte[] bytes = Encoding.UTF8.GetBytes($"{Magic}|{hostName}|{clients.Count}|{TcpPort}");
        try { broadcaster.Send(bytes, bytes.Length, new IPEndPoint(IPAddress.Broadcast, DiscoveryPort)); }
        catch (Exception e) { Debug.LogWarning("Анонс не отправлен: " + e.Message); }
    }

    void HandleClientMessage(Conn c, NetMsg m)
    {
        switch (m.type)
        {
            case "hello":
                c.name = Clean(m.name);
                c.isHost = m.data == "host";
                BroadcastLobby();
                break;
            case "ready":
                c.ready = m.ready;
                BroadcastLobby();
                break;
            case "setmap":
                if (c.isHost && !matchRunning) { LobbyMap = m.map; BroadcastLobby(); }
                break;
            case "start":
                if (c.isHost && !matchRunning) StartMatch();
                break;
            case "state":
                if (m.id != c.id) break;          // нельзя подделать чужую позицию
                Broadcast(m);
                break;
            case "hit":
                m.attacker = c.id;                 // атакующий — тот, кто прислал
                Broadcast(m);
                break;
            case "death":
                HandleDeath(c, m);
                break;
        }
    }

    void StartMatch()
    {
        matchRunning = true;
        tKills = 0;
        ctKills = 0;
        LobbyLimit = killLimit;
        Broadcast(new NetMsg { type = "start", map = LobbyMap, limit = killLimit });
    }

    void HandleDeath(Conn victim, NetMsg m)
    {
        if (!matchRunning) return;
        Conn killer = clients.Find(x => x.id == m.attacker);
        if (killer != null && killer != victim && killer.team != victim.team)
        {
            if (killer.team == Team.Terrorist) tKills++; else ctKills++;
        }
        Broadcast(new NetMsg { type = "score", data = tKills + ";" + ctKills });
        if (tKills >= killLimit || ctKills >= killLimit) EndMatch();
    }

    void EndMatch()
    {
        matchRunning = false;
        Broadcast(new NetMsg { type = "end" });
        BroadcastLobby();
    }

    void BroadcastLobby()
    {
        if (!matchRunning)
            for (int i = 0; i < clients.Count; i++)
                clients[i].team = i % 2 == 0 ? Team.CounterTerrorist : Team.Terrorist;

        var sb = new StringBuilder();
        foreach (var c in clients)
        {
            if (sb.Length > 0) sb.Append(';');
            sb.Append(c.id).Append('|').Append(c.name).Append('|')
              .Append(c.ready ? 1 : 0).Append('|')
              .Append(c.team == Team.Terrorist ? 1 : 0).Append('|')
              .Append(c.isHost ? 1 : 0);
        }
        Broadcast(new NetMsg { type = "lobby", data = sb.ToString(), map = LobbyMap, limit = killLimit });
    }

    void Broadcast(NetMsg m)
    {
        string json = JsonUtility.ToJson(m);
        foreach (var c in clients) SendRaw(c, json);
    }

    void SendTo(Conn c, NetMsg m) => SendRaw(c, JsonUtility.ToJson(m));

    static void SendRaw(Conn c, string json)
    {
        try { c.writer.WriteLine(json); }
        catch { }
    }

    // ================= Клиент =================

    public void JoinGame(string ip, string name, bool asHost = false)
    {
        DisconnectClient();
        PlayerName = Clean(name);
        IsHost = asHost;
        string target = ip;
        new Thread(() =>
        {
            try
            {
                var tcp = new TcpClient();
                tcp.Connect(target, TcpPort);
                mainQueue.Enqueue(() => AttachClient(tcp, asHost));
            }
            catch (Exception e)
            {
                mainQueue.Enqueue(() =>
                {
                    Debug.LogError("Не удалось подключиться к " + target + ": " + e.Message);
                    Disconnected?.Invoke();
                });
            }
        }) { IsBackground = true }.Start();
    }

    void AttachClient(TcpClient tcp, bool asHost)
    {
        server = new Conn { tcp = tcp, writer = new StreamWriter(tcp.GetStream(), Encoding.UTF8) { AutoFlush = true } };
        IsConnected = true;
        StartReader(server, false);
        Send(new NetMsg { type = "hello", name = PlayerName, data = asHost ? "host" : "" });
    }

    void HandleServerMessage(NetMsg m)
    {
        switch (m.type)
        {
            case "welcome":
                LocalId = m.id;
                break;
            case "lobby":
                ParseLobby(m);
                break;
            case "start":
                LobbyMap = m.map;
                LobbyLimit = m.limit;
                break;
        }
        MessageReceived?.Invoke(m);
    }

    void ParseLobby(NetMsg m)
    {
        Roster.Clear();
        if (!string.IsNullOrEmpty(m.map)) LobbyMap = m.map;
        if (m.limit > 0) LobbyLimit = m.limit;
        if (string.IsNullOrEmpty(m.data)) return;

        foreach (var entry in m.data.Split(';'))
        {
            var p = entry.Split('|');
            if (p.Length < 5) continue;
            if (!int.TryParse(p[0], out int id)) continue;
            Roster.Add(new LobbyEntry
            {
                id = id,
                name = p[1],
                ready = p[2] == "1",
                team = p[3] == "1" ? Team.Terrorist : Team.CounterTerrorist,
                isHost = p[4] == "1"
            });
        }
    }

    // Сообщения от клиента (main-thread обработка)
    public void Send(NetMsg m)
    {
        if (server == null || server.writer == null) return;
        try { server.writer.WriteLine(JsonUtility.ToJson(m)); }
        catch (Exception e) { Debug.LogWarning("Отправка не удалась: " + e.Message); }
    }

    public void SetReady(bool ready) => Send(new NetMsg { type = "ready", ready = ready });
    public void SetMap(string map) => Send(new NetMsg { type = "setmap", map = map });
    public void RequestStart() => Send(new NetMsg { type = "start" });

    // ================= Общее =================

    void StartReader(Conn c, bool serverSide)
    {
        new Thread(() =>
        {
            try
            {
                using (var sr = new StreamReader(c.tcp.GetStream(), Encoding.UTF8))
                {
                    string line;
                    while (c.alive && (line = sr.ReadLine()) != null)
                    {
                        NetMsg msg = null;
                        try { msg = JsonUtility.FromJson<NetMsg>(line); }
                        catch { }
                        if (msg == null) continue;
                        mainQueue.Enqueue(() =>
                        {
                            if (serverSide) HandleClientMessage(c, msg);
                            else HandleServerMessage(msg);
                        });
                    }
                }
            }
            catch { }
            mainQueue.Enqueue(() => OnConnLost(c, serverSide));
        }) { IsBackground = true }.Start();
    }

    void OnConnLost(Conn c, bool serverSide)
    {
        if (!c.alive) return;
        c.alive = false;
        if (serverSide)
        {
            clients.Remove(c);
            Broadcast(new NetMsg { type = "bye", id = c.id });
            BroadcastLobby();
            CloseSocket(c);
        }
        else if (c == server)
        {
            CloseSocket(c);
            server = null;
            IsConnected = false;
            IsHost = false;
            LocalId = -1;
            Roster.Clear();
            Disconnected?.Invoke();
        }
    }

    public void Shutdown()
    {
        foreach (var c in clients) CloseSocket(c);
        clients.Clear();
        DisconnectClient();
        try { listener?.Stop(); } catch { }
        listener = null;
        try { broadcaster?.Close(); } catch { }
        broadcaster = null;
        IsHost = false;
        IsConnected = false;
        LocalId = -1;
        matchRunning = false;
        nextId = 1;
        Roster.Clear();
    }

    void DisconnectClient()
    {
        if (server != null) CloseSocket(server);
        server = null;
        IsConnected = false;
    }

    static void CloseSocket(Conn c)
    {
        c.alive = false;
        try { c.writer?.Dispose(); } catch { }
        try { c.tcp?.Close(); } catch { }
    }

    // ================= Поиск игр в сети =================

    public void StartDiscovery()
    {
        if (discoveryListener != null) return;
        try { discoveryListener = new UdpClient(DiscoveryPort); }
        catch (Exception e) { Debug.LogWarning("Поиск игр недоступен: " + e.Message); return; }

        var listen = discoveryListener;
        new Thread(() =>
        {
            var ep = new IPEndPoint(IPAddress.Any, 0);
            while (true)
            {
                try
                {
                    byte[] data = listen.Receive(ref ep);
                    string text = Encoding.UTF8.GetString(data);
                    var p = text.Split('|');
                    if (p.Length < 4 || p[0] != Magic) continue;
                    if (!int.TryParse(p[2], out int players)) players = 0;
                    string ip = ep.Address.ToString();
                    string name = p[1];
                    mainQueue.Enqueue(() => Discovered[ip] = new FoundGame
                    {
                        ip = ip, name = name, players = players, lastSeen = Time.realtimeSinceStartup
                    });
                }
                catch { break; }
            }
        }) { IsBackground = true }.Start();
    }

    // Адрес для подключения: IPv4 локальной сети или точки доступа
    public static string GetLocalIP()
    {
        try
        {
            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.OperationalStatus != OperationalStatus.Up) continue;
                foreach (var a in ni.GetIPProperties().UnicastAddresses)
                    if (a.Address.AddressFamily == AddressFamily.InterNetwork && !IPAddress.IsLoopback(a.Address))
                        return a.Address.ToString();
            }
        }
        catch { }
        return "127.0.0.1";
    }

    static string Clean(string s)
    {
        string t = (s ?? "").Replace("|", "").Replace(";", "").Trim();
        if (t.Length > 16) t = t.Substring(0, 16);
        return t.Length == 0 ? "Player" : t;
    }
}
