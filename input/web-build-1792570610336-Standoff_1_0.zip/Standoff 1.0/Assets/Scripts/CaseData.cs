using UnityEngine;

public enum Rarity { Common, Rare, Epic, Legendary }

public struct CaseDrop
{
    public string itemId;
    public string title;
    public Rarity rarity;
    public int weight;   // чем больше, тем чаще
}

// Таблица кейсов. Правь здесь цену и выпадающие предметы.
// itemId должен совпадать с id в Inventory (skin:<оружие>:<индекс>) и с WeaponController.weaponName.
public static class CaseTable
{
    public const int Price = 150;

    public static readonly CaseDrop[] Drops =
    {
        new CaseDrop { itemId = "skin:AK-47:1", title = "AK-47 | Стандартный камуфляж", rarity = Rarity.Common,    weight = 60 },
        new CaseDrop { itemId = "skin:AK-47:2", title = "AK-47 | Пустыня",             rarity = Rarity.Rare,      weight = 25 },
        new CaseDrop { itemId = "skin:AK-47:3", title = "AK-47 | Неон",                rarity = Rarity.Epic,      weight = 12 },
        new CaseDrop { itemId = "skin:AK-47:4", title = "AK-47 | Золото",              rarity = Rarity.Legendary, weight = 3 },
    };

    public static CaseDrop Roll()
    {
        int total = 0;
        foreach (var d in Drops) total += d.weight;
        int r = Random.Range(0, total);
        foreach (var d in Drops)
        {
            if (r < d.weight) return d;
            r -= d.weight;
        }
        return Drops[Drops.Length - 1];
    }
}
