using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

// Вешается на сцену "Loading". Грузит SceneLoader.Target асинхронно и показывает 0–100%.
// Unity отдаёт progress до 0.9, поэтому 0.9 соответствует 100% реальной загрузки,
// а последние 10% — активация сцены. Полоса плавно догоняет реальный прогресс.
public class LoadingScreen : MonoBehaviour
{
    public Image bar;
    public TextMeshProUGUI percentText;
    public TextMeshProUGUI titleText;
    [Tooltip("Минимальное время показа экрана, чтобы не мелькал")]
    public float minShowTime = 1f;
    public float smoothSpeed = 0.8f;   // доля полосы в секунду

    float displayed;

    void Start()
    {
        if (titleText) titleText.text = "Загрузка...";
        StartCoroutine(Run());
    }

    IEnumerator Run()
    {
        string target = SceneLoader.Target;
        if (string.IsNullOrEmpty(target) || !Application.CanStreamedLevelBeLoaded(target))
        {
            if (titleText) titleText.text = "Сцена не найдена: " + target;
            Debug.LogError("LoadingScreen: сцена '" + target + "' не добавлена в Build Settings");
            yield return new WaitForSecondsRealtime(3f);
            SceneManager.LoadScene("MainMenu");
            yield break;
        }

        AsyncOperation op = SceneManager.LoadSceneAsync(target);
        op.allowSceneActivation = false;

        float elapsed = 0f;
        while (!op.isDone)
        {
            elapsed += Time.unscaledDeltaTime;
            float real = op.progress < 0.9f ? op.progress / 0.9f : 1f;
            displayed = Mathf.MoveTowards(displayed, real, Time.unscaledDeltaTime * smoothSpeed);
            Show(displayed);

            if (real >= 1f && displayed >= 0.999f && elapsed >= minShowTime)
                op.allowSceneActivation = true;

            yield return null;
        }
    }

    void Show(float value01)
    {
        int percent = Mathf.Clamp(Mathf.RoundToInt(value01 * 100f), 0, 100);
        if (bar) bar.fillAmount = percent / 100f;
        if (percentText) percentText.text = percent + "%";
    }
}
