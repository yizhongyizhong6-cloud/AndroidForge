using UnityEngine;
using UnityEngine.SceneManagement;

public class Standoff3DGameManager : MonoBehaviour
{
    public static Standoff3DGameManager Instance;

    [Header("Game Settings")]
    public int killLimit = 30;
    public int playerScore = 0;   // TDM: kills of the player's side
    public int enemyScore = 0;    // TDM: kills of the enemy side

    // Читаем из PlayerPrefs каждый раз: экземпляр живёт между сценами
    // и мог быть создан до выбора режима в меню.
    public GameMode gameMode => GameModeUtil.Load();

    bool matchOver;

    void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else { Destroy(gameObject); return; }
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDestroy()
    {
        if (Instance == this) SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void OnSceneLoaded(Scene s, LoadSceneMode m)
    {
        playerScore = enemyScore = 0;
        matchOver = false;
        StatsManager.ResetSession();
    }

    public void PlayerDied()
    {
        // В режиме осмотра нет ботов и раундов: игрок просто возрождается на месте старта
        if (gameMode == GameMode.FreeRoam)
        {
            FreeRoamManager.Instance?.Respawn();
            return;
        }
        Invoke(nameof(RestartLevel), 3f);
    }
    void RestartLevel() => SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    public void ReturnToMenu() => SceneManager.LoadScene("MainMenu");

    public void OnTdmKill(Team deadTeam)
    {
        if (matchOver) return;

        bool playerSideDied = HealthSystem.Player != null && deadTeam == HealthSystem.Player.team;
        if (playerSideDied) enemyScore++;
        else playerScore++;

        FindObjectOfType<HUDManager>()?.SetRoundInfo($"Вы {playerScore} : {enemyScore} Враги   (до {killLimit})");

        if (playerScore >= killLimit || enemyScore >= killLimit)
        {
            matchOver = true;
            StatsManager.RecordMatch(playerScore >= killLimit);
            FindObjectOfType<HUDManager>()?.ShowMessage(playerScore >= killLimit ? "Победа!" : "Поражение", 4f);
            Invoke(nameof(ReturnToMenu), 4f);
        }
    }
}
