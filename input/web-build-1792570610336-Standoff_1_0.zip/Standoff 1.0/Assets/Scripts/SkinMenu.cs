using UnityEngine;
using TMPro;

// Кнопка выбора скина для одного оружия в меню.
public class SkinMenu : MonoBehaviour
{
    public string weaponName = "AK-47";
    public Material[] skins;             // те же материалы, что у WeaponController этого оружия
    public TextMeshProUGUI label;

    void Start() => Refresh();

    public void Next()
    {
        SkinPrefs.Cycle(weaponName, skins.Length);
        Refresh();
    }

    void Refresh()
    {
        if (!label) return;
        int i = SkinPrefs.GetSelected(weaponName, skins.Length);
        string name = skins.Length > 0 && skins[i] != null ? skins[i].name : "Стандарт";
        label.text = weaponName + ": " + name;
    }
}
