using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

// Открытие кейса: списание монет, короткая «прокрутка» имён и результат.
public class CaseOpeningUI : MonoBehaviour
{
    public Button openButton;
    public TextMeshProUGUI spinText;
    public TextMeshProUGUI resultText;
    public TextMeshProUGUI priceText;
    public TextMeshProUGUI coinsText;
    public float spinTime = 2f;

    bool spinning;

    void Start()
    {
        if (openButton) openButton.onClick.AddListener(Open);
        if (priceText) priceText.text = "Цена: " + CaseTable.Price + " монет";
        Refresh();
    }

    void Update()
    {
        if (!spinning) Refresh();
    }

    void Refresh()
    {
        if (coinsText) coinsText.text = "Монеты: " + Wallet.Coins;
        if (openButton) openButton.interactable = !spinning && Wallet.Coins >= CaseTable.Price;
    }

    void Open()
    {
        if (spinning) return;
        if (!Wallet.TrySpend(CaseTable.Price))
        {
            if (resultText) resultText.text = "Не хватает монет";
            return;
        }
        CaseDrop prize = CaseTable.Roll();
        Inventory.Add(prize.itemId);
        StartCoroutine(Spin(prize));
    }

    IEnumerator Spin(CaseDrop prize)
    {
        spinning = true;
        if (resultText) resultText.text = "";
        float t = 0f;
        float delay = 0.05f;
        while (t < spinTime)
        {
            var fake = CaseTable.Drops[Random.Range(0, CaseTable.Drops.Length)];
            if (spinText) spinText.text = fake.title;
            yield return new WaitForSeconds(delay);
            t += delay;
            delay = Mathf.Lerp(0.05f, 0.3f, t / spinTime);   // замедляемся к концу
        }
        if (spinText) spinText.text = prize.title;
        if (resultText) resultText.text = "Выпало: " + prize.title + " (" + RarityTitle(prize.rarity) + ")";
        spinning = false;
        Refresh();
    }

    static string RarityTitle(Rarity r) => r switch
    {
        Rarity.Common => "обычный",
        Rarity.Rare => "редкий",
        Rarity.Epic => "эпический",
        _ => "легендарный",
    };
}
