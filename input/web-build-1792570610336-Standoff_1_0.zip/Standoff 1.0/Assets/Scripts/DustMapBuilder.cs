using UnityEngine;
using UnityEngine.Rendering;

// Карта Dust2: оригинальная раскладка в духе Dust2 (A справа, B слева, средний коридор
// с дверями, бэкплант за B). Строится в Awake из примитивов и процедурных текстур,
// поэтому не нужны никакие ассеты. Заменить можно через поля floorTexture и т.д.
//
// Варианты:
//   Dust2Classic — двери мида открыты, бэкплант открыт.
//   Dust2V2      — мид закрыт (обе двери), бэкплант закрыт.
// Выбор: поле variant, либо PlayerPrefs "Map" = "Dust2v2" (ставит меню).
//
// Выставляет точки спавна в CompetitiveRoundManager и создаёт зоны BombSite A и B.
// Геометрия объединяется статическим батчингом: меньше draw calls на телефоне.
[DefaultExecutionOrder(-100)]   // раньше Bomb и CompetitiveRoundManager, которым нужны зоны и спавны
public class DustMapBuilder : MonoBehaviour
{
    public enum Variant { Dust2Classic, Dust2V2 }

    public Variant variant = Variant.Dust2Classic;
    public CompetitiveRoundManager round;      // если пусто — найдётся в сцене

    [Header("Свои текстуры (необязательно, иначе процедурные)")]
    public Texture2D floorTexture;
    public Texture2D wallTexture;
    public Texture2D crateTexture;

    Material floorMat, wallMat, crateMat, siteAMat, siteBMat;
    Transform mapRoot;

    const float WallH = 4f;

    void Awake()
    {
        // Вариант из меню важнее инспектора
        string picked = PlayerPrefs.GetString("Map", "");
        if (picked == "Dust2v2") variant = Variant.Dust2V2;
        else if (picked == "Dust2") variant = Variant.Dust2Classic;

        if (round == null) round = FindObjectOfType<CompetitiveRoundManager>();

        BuildMaterials();

        var rootGo = new GameObject("Dust2Map");
        rootGo.transform.SetParent(transform, false);
        mapRoot = rootGo.transform;

        bool v2 = variant == Variant.Dust2V2;

        BuildGround();
        BuildOuterWalls();
        BuildMid(v2);
        BuildBSide(v2);
        BuildASide();
        BuildCover();

        // Всё, что не зона и не спавн, объединяем в несколько мешей
        StaticBatchingUtility.Combine(rootGo);

        BuildSites();
        BuildSpawns();
    }

    // ---------- Материалы ----------

    void BuildMaterials()
    {
        Shader sh = Shader.Find("Mobile/Diffuse");
        if (sh == null) sh = Shader.Find("Standard");

        Texture floorTex = floorTexture != null ? floorTexture : Noise(new Color(0.82f, 0.72f, 0.48f), new Color(0.68f, 0.58f, 0.36f), 1);
        Texture wallTex = wallTexture != null ? wallTexture : Noise(new Color(0.74f, 0.62f, 0.44f), new Color(0.55f, 0.44f, 0.30f), 2);
        Texture crateTex = crateTexture != null ? crateTexture : Noise(new Color(0.55f, 0.38f, 0.20f), new Color(0.38f, 0.25f, 0.12f), 3);

        floorMat = MakeMat(sh, floorTex, Color.white);
        wallMat = MakeMat(sh, wallTex, Color.white);
        crateMat = MakeMat(sh, crateTex, Color.white);
        siteAMat = MakeMat(sh, floorTex, new Color(1f, 0.65f, 0.35f));   // зона A — тёплый оттенок
        siteBMat = MakeMat(sh, floorTex, new Color(0.45f, 0.7f, 1f));    // зона B — холодный оттенок
    }

    static Material MakeMat(Shader sh, Texture tex, Color tint)
    {
        var m = new Material(sh);
        m.mainTexture = tex;
        m.color = tint;
        return m;
    }

    // Процедурная текстура 64×64 с шумом; мипмапы включены, память мала
    static Texture2D Noise(Color a, Color b, int seed)
    {
        const int N = 64;
        var t = new Texture2D(N, N, TextureFormat.RGB24, true);
        t.wrapMode = TextureWrapMode.Repeat;
        t.filterMode = FilterMode.Bilinear;
        var px = new Color[N * N];
        for (int y = 0; y < N; y++)
        for (int x = 0; x < N; x++)
        {
            float n = Mathf.PerlinNoise(x * 0.12f + seed * 17.3f, y * 0.12f + seed * 9.1f) * 0.6f
                    + Mathf.PerlinNoise(x * 0.45f, y * 0.45f) * 0.4f;
            px[y * N + x] = Color.Lerp(a, b, n);
        }
        t.SetPixels(px);
        t.Apply(true, false);
        return t;
    }

    // ---------- Примитивы ----------

    GameObject Box(Transform parent, string name, Vector3 center, Vector3 size, Material mat, bool solid = true)
    {
        var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
        go.name = name;
        go.transform.SetParent(parent, false);
        go.transform.localPosition = center;
        go.transform.localScale = size;
        go.GetComponent<Renderer>().sharedMaterial = mat;
        if (!solid) Destroy(go.GetComponent<Collider>());
        return go;
    }

    void Wall(string name, Vector3 center, Vector3 size) => Box(mapRoot, name, center, size, wallMat);

    // ---------- Геометрия (метры; X — восток, Z — север, пол на y = 0) ----------

    void BuildGround()
    {
        Box(mapRoot, "Ground", new Vector3(0, -0.5f, 0), new Vector3(120, 1, 110), floorMat);
    }

    void BuildOuterWalls()
    {
        Wall("Outer_N", new Vector3(0, WallH / 2, 55.5f), new Vector3(120, WallH, 1));
        Wall("Outer_S", new Vector3(0, WallH / 2, -55.5f), new Vector3(120, WallH, 1));
        Wall("Outer_E", new Vector3(60.5f, WallH / 2, 0), new Vector3(1, WallH, 110));
        Wall("Outer_W", new Vector3(-60.5f, WallH / 2, 0), new Vector3(1, WallH, 110));
    }

    // Средний коридор: x = ±12, двери на z = 5..10 (к B слева, к A справа)
    void BuildMid(bool closed)
    {
        Wall("Mid_W_South", new Vector3(-12, WallH / 2, -0.5f), new Vector3(1, WallH, 11));
        Wall("Mid_W_North", new Vector3(-12, WallH / 2, 17.5f), new Vector3(1, WallH, 15));
        Wall("Mid_E_South", new Vector3(12, WallH / 2, -0.5f), new Vector3(1, WallH, 11));
        Wall("Mid_E_North", new Vector3(12, WallH / 2, 17.5f), new Vector3(1, WallH, 15));

        if (closed)   // закрытый мид: двери заложены
        {
            Wall("Mid_W_Door", new Vector3(-12, WallH / 2, 7.5f), new Vector3(1, WallH, 5));
            Wall("Mid_E_Door", new Vector3(12, WallH / 2, 7.5f), new Vector3(1, WallH, 5));
        }

        // Ящики в коридоре — укрытия
        Box(mapRoot, "Crate_Mid", new Vector3(0, 1.2f, 2), new Vector3(3, 2.4f, 3), crateMat);
    }

    // Сторона B: зона B на (-38, 25), бэкплант — открытый проход на севере зоны
    void BuildBSide(bool closedBackplant)
    {
        Wall("B_West", new Vector3(-47, WallH / 2, 25), new Vector3(1, WallH, 16));
        Wall("B_South", new Vector3(-38, WallH / 2, 16), new Vector3(16, WallH, 1));

        if (closedBackplant)   // закрытый бэкплант
            Wall("B_Backplant_Block", new Vector3(-38, WallH / 2, 33.5f), new Vector3(18, WallH, 1));
    }

    // Сторона A: зона A на (38, 30), длинный A — коридор вдоль восточной стены
    void BuildASide()
    {
        Wall("A_Divider", new Vector3(24, WallH / 2, -5), new Vector3(1, WallH, 30));
        Wall("A_Long_Block", new Vector3(46, WallH / 2, 12), new Vector3(16, WallH, 1));
    }

    void BuildCover()
    {
        Box(mapRoot, "Crate_A1", new Vector3(30, 1.25f, -10), new Vector3(3, 2.5f, 3), crateMat);
        Box(mapRoot, "Crate_A2", new Vector3(40, 1.25f, 8), new Vector3(3, 2.5f, 3), crateMat);
        Box(mapRoot, "Crate_B1", new Vector3(-30, 1.25f, 12), new Vector3(3, 2.5f, 3), crateMat);
        Box(mapRoot, "Crate_T1", new Vector3(-20, 1.25f, -15), new Vector3(3, 2.5f, 3), crateMat);
        Box(mapRoot, "Crate_T2", new Vector3(20, 1.25f, -18), new Vector3(3, 2.5f, 3), crateMat);

        // Зоны (визуальные полы) — без коллайдера, поверх пола
        Box(mapRoot, "SiteA_Floor", new Vector3(38, 0.03f, 30), new Vector3(14, 0.06f, 14), siteAMat, false);
        Box(mapRoot, "SiteB_Floor", new Vector3(-38, 0.03f, 25), new Vector3(14, 0.06f, 14), siteBMat, false);
    }

    // ---------- Зоны бомбы и спавны ----------

    void BuildSites()
    {
        // Зона — триггер BombSite. Видимый пол уже создан в BuildCover.
        // Зона вне mapRoot, иначе статический батчинг её бы объединил.
        AddSite("BombSite_A", "A", new Vector3(38, 1.5f, 30));
        AddSite("BombSite_B", "B", new Vector3(-38, 1.5f, 25));
    }

    void AddSite(string name, string site, Vector3 center)
    {
        var go = Box(transform, name, center, new Vector3(14, 3, 14), floorMat);
        go.GetComponent<MeshRenderer>().enabled = false;   // невидимый триггер
        var bs = go.AddComponent<BombSite>();
        bs.siteName = site;
    }

    void BuildSpawns()
    {
        var root = new GameObject("Spawns").transform;
        root.SetParent(transform, false);

        var tSpawns = new Transform[6];
        var ctSpawns = new Transform[6];
        for (int i = 0; i < 6; i++)
        {
            float x = -20f + i * 8f;
            tSpawns[i] = MakeSpawn(root, "T_" + i, new Vector3(x, 0.05f, -42f), 0f);     // T смотрит на север
            ctSpawns[i] = MakeSpawn(root, "CT_" + i, new Vector3(x, 0.05f, 45f), 180f);  // CT смотрит на юг
        }

        if (round != null)
        {
            round.terroristSpawns = tSpawns;
            round.counterTerroristSpawns = ctSpawns;
        }
    }

    static Transform MakeSpawn(Transform parent, string name, Vector3 pos, float yaw)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = pos;
        go.transform.localRotation = Quaternion.Euler(0f, yaw, 0f);
        return go.transform;
    }
}
