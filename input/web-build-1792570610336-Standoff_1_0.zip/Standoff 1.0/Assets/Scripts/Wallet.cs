using UnityEngine;

// Игровая валюта (монеты). Хранится в PlayerPrefs на устройстве.
// Начисляется за убийства и матчи (см. StatsManager). Тратится в рынке и на кейсы.
public static class Wallet
{
    const string Key = "Coins";

    public const int KillCoins = 10;
    public const int WinCoins = 100;
    public const int LossCoins = 25;

    public static int Coins => PlayerPrefs.GetInt(Key, 0);

    public static void Add(int amount)
    {
        if (amount <= 0) return;
        PlayerPrefs.SetInt(Key, Coins + amount);
        PlayerPrefs.Save();
    }

    public static bool TrySpend(int amount)
    {
        if (amount <= 0) return true;
        if (Coins < amount) return false;
        PlayerPrefs.SetInt(Key, Coins - amount);
        PlayerPrefs.Save();
        return true;
    }
}
