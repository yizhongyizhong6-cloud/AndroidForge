using System.Collections.Generic;

public enum WeaponCategory { Melee, Pistol, Rifle, SMG }

// Характеристики оружия в духе Standoff. Ключ — поле weaponName у WeaponController.
// Урон задаётся за одно попадание (до брони). Интервал — секунды между выстрелами.
// Если оружия нет в таблице, используются значения из Inspector.
public struct WeaponStat
{
    public WeaponCategory category;
    public int price;          // цена в матче ($)
    public float damage;       // урон за попадание
    public float interval;     // сек между выстрелами
    public float range;        // дальность (для ножа — дистанция удара)
    public int magazine;       // патроны в магазине (0 для ножа)
    public float reload;       // сек на перезарядку
}

public static class WeaponStats
{
    static readonly Dictionary<string, WeaponStat> table = new Dictionary<string, WeaponStat>
    {
        // Нож: бесплатный, бьёт вблизи, без патронов
        ["Knife"] = new WeaponStat
        {
            category = WeaponCategory.Melee, price = 0, damage = 40f,
            interval = 0.9f, range = 2.2f, magazine = 0, reload = 0f
        },
        // Пистолет: дешёвый, 33 урона, мало патронов
        ["Pistol"] = new WeaponStat
        {
            category = WeaponCategory.Pistol, price = 200, damage = 33f,
            interval = 0.2f, range = 100f, magazine = 12, reload = 2.0f
        },
        // Пистолет-пулемёт: дешёвый автомат, меньше урон
        ["MP5"] = new WeaponStat
        {
            category = WeaponCategory.SMG, price = 1500, damage = 26f,
            interval = 0.09f, range = 100f, magazine = 30, reload = 2.5f
        },
        // Калаш: дорогой, самый сильный автомат
        ["AK-47"] = new WeaponStat
        {
            category = WeaponCategory.Rifle, price = 2700, damage = 36f,
            interval = 0.1f, range = 100f, magazine = 30, reload = 2.5f
        },
    };

    public static bool TryGet(string weaponName, out WeaponStat stat) => table.TryGetValue(weaponName, out stat);
}
