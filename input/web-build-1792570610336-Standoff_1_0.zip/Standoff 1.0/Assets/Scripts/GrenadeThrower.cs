using UnityEngine;
using TMPro;

// Гранаты игрока: покупаются в магазине (B) в фриз-тайм, бросаются клавишей G.
// Запас сбрасывается в начале каждого раунда. Гранаты берутся из пула.
public class GrenadeThrower : MonoBehaviour
{
    [Header("Префаб гранаты (с компонентом Grenade)")]
    public GameObject grenadePrefab;
    public Transform throwOrigin;           // обычно камера игрока
    public float throwSpeed = 12f;
    public float throwCooldown = 0.6f;

    [Header("Экономика")]
    public int price = 300;
    public int maxCount = 1;

    [Header("Управление и UI")]
    public KeyCode throwKey = KeyCode.G;
    public TextMeshProUGUI countText;

    public int Count { get; private set; }
    public bool CanBuy => Count < maxCount;

    ObjectPool pool;
    float cooldown;

    void Awake()
    {
        var parent = new GameObject("GrenadePool").transform;
        pool = new ObjectPool(grenadePrefab, parent, 2, 4);
    }

    void Start()
    {
        if (throwOrigin == null && Camera.main != null) throwOrigin = Camera.main.transform;
        Refresh();
    }

    public void ResetForRound()
    {
        Count = 0;
        Refresh();
    }

    public bool TryBuy()
    {
        if (!CanBuy) return false;
        if (!Economy.TrySpend(price)) return false;
        Count++;
        Refresh();
        return true;
    }

    void Update()
    {
        if (cooldown > 0f) cooldown -= Time.deltaTime;
        if (!GameInput.GrenadeDown) return;
        if (Count <= 0 || cooldown > 0f) return;
        if (CompetitiveRoundManager.InputLocked) return;
        if (HealthSystem.Player != null && HealthSystem.Player.IsDead) return;
        Throw();
    }

    void Throw()
    {
        var go = pool.Get();
        if (go == null) return;

        var grenade = go.GetComponent<Grenade>();
        if (grenade == null) { pool.Release(go); return; }

        Transform o = throwOrigin != null ? throwOrigin : transform;
        Vector3 dir = o.forward;
        Vector3 vel = dir * throwSpeed + Vector3.up * 3f;

        go.SetActive(true);
        grenade.Launch(o.position + dir * 0.4f, vel, HealthSystem.Player, pool);

        Count--;
        cooldown = throwCooldown;
        Refresh();
    }

    void Refresh()
    {
        if (countText != null) countText.text = "HE " + Count + "/" + maxCount;
    }
}
