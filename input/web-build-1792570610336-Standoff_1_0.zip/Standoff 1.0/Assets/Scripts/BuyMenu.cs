using UnityEngine;
using UnityEngine.UI;
using TMPro;

// Магазин (клавиша B). Покупка только в фриз-тайм соревновательного режима.
// weaponButtons[i] / weaponLabels[i] соответствуют playerHolder.weapons[i].
// Цена берётся из самого оружия (WeaponStats). Гранаты — отдельная кнопка.
public class BuyMenu : MonoBehaviour
{
    public GameObject panel;
    public WeaponHolder playerHolder;
    public int armorPrice = 650;
    public int armorAmount = 100;
    public KeyCode toggleKey = KeyCode.B;

    [Header("Оружие (по слотам)")]
    public Button[] weaponButtons;
    public TextMeshProUGUI[] weaponLabels;

    [Header("Гранаты")]
    public GrenadeThrower grenades;
    public Button grenadeButton;
    public TextMeshProUGUI grenadeLabel;

    [Header("Тексты")]
    public TextMeshProUGUI moneyText;
    public TextMeshProUGUI statusText;

    bool CanBuy => CompetitiveRoundManager.Instance == null || CompetitiveRoundManager.Instance.InFreeze;

    void Start()
    {
        if (panel) panel.SetActive(false);
        for (int i = 0; weaponButtons != null && i < weaponButtons.Length; i++)
        {
            int idx = i;
            if (weaponButtons[i] != null) weaponButtons[i].onClick.AddListener(() => BuyWeapon(idx));
        }
        if (grenadeButton != null) grenadeButton.onClick.AddListener(BuyGrenade);
    }

    void Update()
    {
        if (GameInput.BuyDown && panel) panel.SetActive(!panel.activeSelf);
        // Обновляем подписи только пока меню открыто
        if (panel != null && panel.activeSelf) Refresh();
    }

    void Refresh()
    {
        SetText(moneyText, "$" + Economy.Money);

        if (playerHolder != null)
        {
            for (int i = 0; i < playerHolder.weapons.Length; i++)
            {
                if (weaponLabels == null || i >= weaponLabels.Length || weaponLabels[i] == null) continue;
                var w = playerHolder.weapons[i];
                if (w == null) { SetText(weaponLabels[i], ""); continue; }

                string state;
                if (playerHolder.IsUnlocked(i)) state = i == playerHolder.CurrentIndex ? "в руках" : "куплено";
                else state = "$" + w.price;
                SetText(weaponLabels[i], w.weaponName + "  " + state);
            }
        }

        if (grenades != null && grenadeLabel != null)
            SetText(grenadeLabel, "Граната $" + grenades.price + "  (" + grenades.Count + "/" + grenades.maxCount + ")");
    }

    public void BuyWeapon(int index)
    {
        if (!CanBuy) { Status("Покупка только в фриз-тайм"); return; }
        if (playerHolder == null || index < 0 || index >= playerHolder.weapons.Length) return;
        var w = playerHolder.weapons[index];
        if (w == null) return;

        if (!playerHolder.IsUnlocked(index))
        {
            if (!Economy.TrySpend(w.price)) { Status("Недостаточно денег"); return; }
            playerHolder.Unlock(index);
            w.Refill();
        }
        playerHolder.Switch(index);
        Status("Экипировано: " + w.weaponName);
    }

    public void BuyGrenade()
    {
        if (!CanBuy) { Status("Покупка только в фриз-тайм"); return; }
        if (grenades == null) return;
        if (!grenades.CanBuy) { Status("Максимум гранат"); return; }
        if (!grenades.TryBuy()) { Status("Недостаточно денег"); return; }
        Status("Граната куплена");
    }

    public void BuyArmor()
    {
        if (!CanBuy) { Status("Покупка только в фриз-тайм"); return; }
        if (HealthSystem.Player == null) return;
        if (!Economy.TrySpend(armorPrice)) { Status("Недостаточно денег"); return; }
        HealthSystem.Player.GiveArmor(armorAmount);
        Status("Броня куплена");
    }

    void Status(string text) => SetText(statusText, text);

    static void SetText(TextMeshProUGUI t, string value)
    {
        if (t != null && t.text != value) t.text = value;
    }
}
