// Загрузка сцены через экран загрузки. Цель запоминается здесь,
// а сцена "Loading" после старта грузит её асинхронно и показывает прогресс 0–100%.
public static class SceneLoader
{
    public const string LoadingScene = "Loading";
    public static string Target { get; private set; }

    public static void Load(string sceneName)
    {
        Target = sceneName;
        UnityEngine.SceneManagement.SceneManager.LoadScene(LoadingScene);
    }
}
