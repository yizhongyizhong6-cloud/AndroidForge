using System;

// Одно сообщение протокола. Передаётся как одна строка JSON (JsonUtility) в TCP-потоке.
[Serializable]
public class NetMsg
{
    public string type;      // hello, welcome, lobby, ready, setmap, start, state, hit, death, score, end, bye
    public int id;           // отправитель / цель
    public int attacker;     // для hit и death
    public string name;
    public string data;      // служебные строки (лобби, счёт, флаг хоста)
    public string map;
    public int limit;        // лимит убийств
    public bool ready;
    public float x, y, z, ry; // позиция и поворот (ry — угол по Y)
    public float health;
    public float damage;
}

public struct LobbyEntry
{
    public int id;
    public string name;
    public bool ready;
    public Team team;
    public bool isHost;
}
