using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Сенсорное управление в духе Standoff.
// Слева — плавающий джойстик (палец ставится где угодно в левой части экрана).
// Справа — свайп обзора. Кнопки: огонь, прыжок, перезарядка, использовать (E),
// граната, магазин, смена оружия. Рисуется через OnGUI: префабы UI не нужны.
// Создаётся сам на телефоне (или по PlayerPrefs "Touch" = 1 для проверки).
[DefaultExecutionOrder(-200)]   // раньше остальных, чтобы одноразовые нажатия попали в тот же кадр
public class TouchControls : MonoBehaviour
{
    public static TouchControls Instance { get; private set; }
    public static bool Active { get; private set; }

    enum Role { None, Joystick, Look, Fire, Jump, Reload, Use, Grenade, Buy, NextWeapon }

    class TouchButton { public Role role; public Vector2 center; public float radius; public string label; }

    class Finger { public Role role; public Vector2 anchor; public Vector2 current; public float startTime; }

    readonly Dictionary<int, Finger> fingers = new Dictionary<int, Finger>();
    Vector2 lookThisFrame;
    Texture2D circleTex;
    GUIStyle labelStyle;
    bool inGame;

    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
    static void Bootstrap()
    {
        if (Instance != null) return;
        bool wanted = Application.isMobilePlatform || PlayerPrefs.GetInt("Touch", 0) == 1;
        if (!wanted) return;
        var go = new GameObject("TouchControls");
        go.AddComponent<TouchControls>();
        DontDestroyOnLoad(go);
    }

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
        Active = true;
        Input.multiTouchEnabled = true;
        circleTex = MakeCircleTexture(128);
    }

    void OnDestroy()
    {
        if (Instance == this) { Instance = null; Active = false; }
    }

    void Update()
    {
        string scene = SceneManager.GetActiveScene().name;
        inGame = scene == "Sandstone" || scene == "Dust2";   // управление только в картах, не в меню

        lookThisFrame = Vector2.zero;
        var buttons = Layout();

        foreach (Touch t in Input.touches)
        {
            Vector2 g = new Vector2(t.position.x, Screen.height - t.position.y);   // GUI: y вниз
            switch (t.phase)
            {
                case TouchPhase.Began:
                    OnBegan(t.fingerId, g, buttons);
                    break;
                case TouchPhase.Moved:
                case TouchPhase.Stationary:
                    OnMoved(t.fingerId, g, t.deltaPosition);
                    break;
                case TouchPhase.Ended:
                case TouchPhase.Canceled:
                    OnEnded(t.fingerId, g);
                    break;
            }
        }

        Publish();
    }

    void OnBegan(int id, Vector2 g, List<TouchButton> buttons)
    {
        if (!inGame) return;

        foreach (var b in buttons)
        {
            if ((g - b.center).sqrMagnitude <= b.radius * b.radius)
            {
                fingers[id] = new Finger { role = b.role, anchor = g, current = g };
                Pulse(b.role);   // одноразовые кнопки срабатывают в момент касания
                return;
            }
        }

        float h = Screen.height;
        bool left = g.x < Screen.width * 0.45f && g.y > h * 0.25f;
        fingers[id] = new Finger { role = left ? Role.Joystick : Role.Look, anchor = g, current = g,
                                   startTime = Time.unscaledTime };
    }

    // Быстрый вертикальный свайп по обзорной области — смена оружия (как в Standoff).
    // Вверх — следующее оружие, вниз — предыдущее. Медленное движение — обзор, не смена.
    void OnEnded(int id, Vector2 g)
    {
        if (fingers.TryGetValue(id, out Finger f) && f.role == Role.Look)
        {
            Vector2 move = g - f.anchor;                 // GUI: y вниз
            float dt = Time.unscaledTime - f.startTime;
            float minDist = Screen.height * 0.07f;       // ~70 мм на экране
            bool quick = dt <= 0.35f;
            bool vertical = Mathf.Abs(move.y) > Mathf.Abs(move.x) * 1.5f;

            if (quick && vertical && Mathf.Abs(move.y) >= minDist)
            {
                GameInput.TouchWeaponSwipeDir = move.y < 0f ? +1 : -1;
                GameInput.TouchWeaponSwipeFrame = Time.frameCount;
            }
        }
        fingers.Remove(id);
    }

    void OnMoved(int id, Vector2 g, Vector2 deltaPx)
    {
        if (!fingers.TryGetValue(id, out Finger f)) return;
        f.current = g;
        if (f.role == Role.Look)
        {
            // пиксели → единицы мыши: 0.3 на пиксель
            lookThisFrame += new Vector2(deltaPx.x, deltaPx.y) * 0.3f;
        }
    }

    // Что нажато сейчас: джойстик, удержание огня и E
    void Publish()
    {
        Vector2 move = Vector2.zero;
        bool fire = false, use = false;
        float radius = JoystickRadius();

        foreach (var f in fingers.Values)
        {
            switch (f.role)
            {
                case Role.Joystick:
                    Vector2 d = (f.current - f.anchor) / radius;
                    move += new Vector2(d.x, -d.y);   // GUI y вниз → мир: вперёд = +y
                    break;
                case Role.Fire: fire = true; break;
                case Role.Use: use = true; break;
            }
        }

        GameInput.TouchMove = Vector2.ClampMagnitude(move, 1f);
        GameInput.TouchLook = lookThisFrame;
        GameInput.TouchFireHeld = fire;
        GameInput.TouchUseHeld = use;
    }

    void Pulse(Role r)
    {
        switch (r)
        {
            case Role.Jump: GameInput.TouchJumpFrame = Time.frameCount; break;
            case Role.Reload: GameInput.TouchReloadFrame = Time.frameCount; break;
            case Role.Grenade: GameInput.TouchGrenadeFrame = Time.frameCount; break;
            case Role.Buy: GameInput.TouchBuyFrame = Time.frameCount; break;
            case Role.NextWeapon: GameInput.TouchNextWeaponFrame = Time.frameCount; break;
        }
    }

    float JoystickRadius() => Screen.height * 0.12f;

    // Расположение кнопок (GUI-координаты: начало в левом верхнем углу)
    List<TouchButton> Layout()
    {
        float W = Screen.width, H = Screen.height;
        float big = H * 0.13f, small = H * 0.085f;
        return new List<TouchButton>
        {
            new TouchButton { role = Role.Fire,       center = new Vector2(W - H * 0.16f, H - H * 0.18f), radius = big,   label = "ОГОНЬ" },
            new TouchButton { role = Role.Jump,       center = new Vector2(W - H * 0.42f, H - H * 0.13f), radius = small, label = "ПРЫЖОК" },
            new TouchButton { role = Role.Reload,     center = new Vector2(W - H * 0.16f, H - H * 0.44f), radius = small, label = "R" },
            new TouchButton { role = Role.Use,        center = new Vector2(W - H * 0.42f, H - H * 0.36f), radius = small, label = "E" },
            new TouchButton { role = Role.Grenade,    center = new Vector2(W - H * 0.30f, H - H * 0.50f), radius = small, label = "HE" },
            new TouchButton { role = Role.Buy,        center = new Vector2(W - H * 0.12f, H * 0.18f),     radius = small, label = "$" },
            new TouchButton { role = Role.NextWeapon, center = new Vector2(W - H * 0.12f, H * 0.36f),     radius = small, label = "Q" },
        };
    }

    void OnGUI()
    {
        if (!Active || !inGame) return;
        if (labelStyle == null)
        {
            labelStyle = new GUIStyle(GUI.skin.label)
            {
                alignment = TextAnchor.MiddleCenter,
                fontSize = Mathf.RoundToInt(Screen.height * 0.03f),
                normal = { textColor = Color.white },
            };
        }

        // Джойстик: кольцо в точке касания и ручка
        foreach (var f in fingers.Values)
        {
            if (f.role != Role.Joystick) continue;
            float r = JoystickRadius();
            DrawCircle(f.anchor, r, new Color(1, 1, 1, 0.25f));
            Vector2 knob = f.anchor + Vector2.ClampMagnitude(f.current - f.anchor, r);
            DrawCircle(knob, r * 0.4f, new Color(1, 1, 1, 0.6f));
        }

        // Кнопки: подсвечиваются, когда нажаты
        foreach (var b in Layout())
        {
            bool pressed = IsPressed(b.role);
            DrawCircle(b.center, b.radius, new Color(1, 1, 1, pressed ? 0.6f : 0.25f));
            Rect r = new Rect(b.center.x - b.radius, b.center.y - b.radius, b.radius * 2, b.radius * 2);
            GUI.Label(r, b.label, labelStyle);
        }
    }

    bool IsPressed(Role role)
    {
        foreach (var f in fingers.Values) if (f.role == role) return true;
        return false;
    }

    void DrawCircle(Vector2 c, float radius, Color color)
    {
        GUI.color = color;
        GUI.DrawTexture(new Rect(c.x - radius, c.y - radius, radius * 2, radius * 2), circleTex);
        GUI.color = Color.white;
    }

    static Texture2D MakeCircleTexture(int n)
    {
        var t = new Texture2D(n, n, TextureFormat.RGBA32, false);
        float c = (n - 1) * 0.5f;
        var px = new Color32[n * n];
        for (int y = 0; y < n; y++)
        for (int x = 0; x < n; x++)
        {
            float d = Mathf.Sqrt((x - c) * (x - c) + (y - c) * (y - c)) / c;
            byte a = d <= 1f ? (byte)255 : (byte)0;
            px[y * n + x] = new Color32(255, 255, 255, a);
        }
        t.SetPixels32(px);
        t.Apply();
        return t;
    }
}
