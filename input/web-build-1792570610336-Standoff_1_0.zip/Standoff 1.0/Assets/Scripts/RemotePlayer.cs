using UnityEngine;

// Прокси чужого игрока: плавно двигает модель к последнему полученному состоянию.
public class RemotePlayer : MonoBehaviour
{
    public float lerpSpeed = 12f;

    Vector3 targetPos;
    float targetYaw;
    bool hidden;
    HealthSystem hs;

    void Awake()
    {
        hs = GetComponent<HealthSystem>();
        targetPos = transform.position;
        targetYaw = transform.eulerAngles.y;
    }

    public void ApplyState(float x, float y, float z, float yaw, float health)
    {
        targetPos = new Vector3(x, y, z);
        targetYaw = yaw;

        bool dead = health <= 0f;
        if (dead != hidden)
        {
            hidden = dead;
            if (hs != null) hs.SetVisible(!dead);
        }
    }

    void Update()
    {
        float k = Time.deltaTime * lerpSpeed;
        transform.position = Vector3.Lerp(transform.position, targetPos, k);
        transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0f, targetYaw, 0f), k);
    }
}
