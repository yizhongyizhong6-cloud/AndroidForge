using UnityEngine;
using UnityEngine.SceneManagement;

public class CompetitiveRoundManager : MonoBehaviour
{
    public static CompetitiveRoundManager Instance { get; private set; }

    [Header("Match Rules")]
    public int roundsToWin = 8;
    public float freezeTime = 5f;
    public float roundTime = 115f;
    public float roundEndDelay = 4f;

    [Header("Spawns")]
    public Transform[] terroristSpawns;
    public Transform[] counterTerroristSpawns;

    [Header("References")]
    public Bomb bomb;
    public HUDManager hud;

    public Team playerTeam = Team.CounterTerrorist;   // ставится из меню (PlayerTeam)
    public int tScore, ctScore;
    public int round = 1;

    public bool RoundOver { get; private set; }
    public bool InFreeze => !RoundOver && phase == Phase.Freeze;
    // Все (игрок и боты) стоят на месте: конец раунда или фриз-тайм
    public static bool FreezeAll => Instance != null && (Instance.RoundOver || Instance.InFreeze);
    public static bool InputLocked => Instance != null && Instance.LocksInput();

    enum Phase { Freeze, Live }
    Phase phase;
    // Кэш для HUD: строка пересобирается только при изменении значений
    int lastHudSec = -1, lastHudRound = -1, lastHudT = -1, lastHudCT = -1;
    Phase lastHudPhase;
    float timer;
    HealthSystem[] units;

    void Awake()
    {
        if (GameModeUtil.Load() != GameMode.Competitive)
        {
            gameObject.SetActive(false);
            return;
        }
        Instance = this;
        roundsToWin = PlayerPrefs.GetInt("RoundsToWin", roundsToWin);
        freezeTime = PlayerPrefs.GetFloat("FreezeTime", freezeTime);
        roundTime = PlayerPrefs.GetFloat("RoundTime", roundTime);
        playerTeam = PlayerPrefs.GetString("PlayerTeam", "CounterTerrorist") == "Terrorist"
            ? Team.Terrorist
            : Team.CounterTerrorist;
    }

    void Start()
    {
        units = LimitBots(FindObjectsOfType<HealthSystem>());
        Economy.ResetMatch();
        AssignTeams();
        StartRound();
    }

    bool BombPlanted => bomb != null && bomb.IsPlanted;

    // BotLimit из кастомной игры: сколько ботов-противников оставить, остальных убрать со сцены.
    // -1 (по умолчанию) — все боты из сцены.
    HealthSystem[] LimitBots(HealthSystem[] all)
    {
        int limit = PlayerPrefs.GetInt("BotLimit", -1);
        if (limit < 0) return all;

        var kept = new System.Collections.Generic.List<HealthSystem>();
        int bots = 0;
        foreach (var u in all)
        {
            if (u.CompareTag("Player")) { kept.Add(u); continue; }
            if (bots < limit) { kept.Add(u); bots++; }
            else u.gameObject.SetActive(false);   // лишние боты не участвуют и не возрождаются
        }
        return kept.ToArray();
    }

    static Team Opposite(Team t) => t == Team.Terrorist ? Team.CounterTerrorist : Team.Terrorist;

    void AssignTeams()
    {
        foreach (var u in units)
            u.team = u.CompareTag("Player") ? playerTeam : Opposite(playerTeam);
    }

    void Update()
    {
        timer -= Time.deltaTime;

        if (!RoundOver)
        {
            if (phase == Phase.Freeze && timer <= 0f)
            {
                phase = Phase.Live;
                timer = roundTime;
                hud?.ShowMessage("GO!", 1.5f);
            }
            else if (phase == Phase.Live && timer <= 0f && !BombPlanted)
            {
                EndRound(Team.CounterTerrorist, "время вышло");
            }
        }

        if (hud)
        {
            int sec = Mathf.CeilToInt(Mathf.Max(timer, 0f));
            if (sec != lastHudSec || phase != lastHudPhase || round != lastHudRound
                || tScore != lastHudT || ctScore != lastHudCT)
            {
                lastHudSec = sec; lastHudPhase = phase; lastHudRound = round;
                lastHudT = tScore; lastHudCT = ctScore;
                string t = sec.ToString();
                string state = phase == Phase.Freeze ? "Разминка " + t : t + "с";
                hud.SetRoundInfo($"Раунд {round}   T {tScore} : {ctScore} CT   {state}");
            }
        }
    }

    public bool LocksInput() =>
        RoundOver || phase == Phase.Freeze || (HealthSystem.Player != null && HealthSystem.Player.IsDead);

    void StartRound()
    {
        RoundOver = false;
        phase = Phase.Freeze;
        timer = freezeTime;
        if (bomb) bomb.ResetBomb();

        int ti = 0, ci = 0;
        foreach (var u in units)
        {
            if (!u.CompareTag("Player")) u.gameObject.SetActive(true);
            u.GetComponentInChildren<WeaponHolder>(true)?.GiveRoundLoadout();
            u.GetComponentInChildren<GrenadeThrower>(true)?.ResetForRound();
            u.Revive();

            bool isT = u.team == Team.Terrorist;
            Transform[] spawns = isT ? terroristSpawns : counterTerroristSpawns;
            int idx = isT ? ti++ : ci++;
            if (spawns != null && spawns.Length > 0) u.MoveTo(spawns[idx % spawns.Length]);
        }

        hud?.ShowMessage($"Раунд {round}", 2f);
    }

    public void OnUnitDied(HealthSystem u)
    {
        if (!u.CompareTag("Player")) u.gameObject.SetActive(false);
        if (RoundOver) return;

        if (Alive(Team.Terrorist) == 0 && !BombPlanted)
            EndRound(Team.CounterTerrorist, "террористы уничтожены");
        else if (Alive(Team.CounterTerrorist) == 0)
            EndRound(Team.Terrorist, "контр-террористы уничтожены");
    }

    public void OnBombPlanted() => hud?.ShowMessage("Бомба установлена!", 2f);
    public void OnBombDefused() => EndRound(Team.CounterTerrorist, "бомба обезврежена");
    public void OnBombExploded() => EndRound(Team.Terrorist, "бомба взорвалась");

    int Alive(Team t)
    {
        int n = 0;
        foreach (var u in units) if (u != null && u.team == t && !u.IsDead) n++;
        return n;
    }

    void EndRound(Team winner, string reason)
    {
        if (RoundOver) return;
        RoundOver = true;
        phase = Phase.Live;

        if (winner == Team.Terrorist) tScore++; else ctScore++;
        if (winner == playerTeam) Economy.RoundWon(); else Economy.RoundLost();

        string winName = winner == Team.Terrorist ? "Террористы" : "Контр-террористы";
        hud?.ShowMessage($"{winName}: {reason}", roundEndDelay);
        round++;

        bool matchOver = tScore >= roundsToWin || ctScore >= roundsToWin;
        if (matchOver)
        {
            StatsManager.RecordMatch(winner == playerTeam);
            hud?.ShowMessage($"Матч окончен! Победа: {winName}", 5f);
            Invoke(nameof(EndMatch), 5f);
            return;
        }

        // Смена сторон в середине матча: команды меняются местами, счёт тоже
        if (tScore + ctScore == roundsToWin)
        {
            SwapSides();
            hud?.ShowMessage("Смена сторон!", roundEndDelay);
        }

        Invoke(nameof(StartRound), roundEndDelay);
    }

    void SwapSides()
    {
        playerTeam = Opposite(playerTeam);
        AssignTeams();
        (tScore, ctScore) = (ctScore, tScore);
    }

    void EndMatch() => SceneManager.LoadScene("MainMenu");
}
