using UnityEngine;
using TMPro;

public class StatsMenu : MonoBehaviour
{
    public GameObject panel;
    public TextMeshProUGUI killsText;
    public TextMeshProUGUI deathsText;
    public TextMeshProUGUI kdText;
    public TextMeshProUGUI matchesText;
    public TextMeshProUGUI winsText;
    public TextMeshProUGUI winRateText;

    void Start()
    {
        if (panel) panel.SetActive(false);
    }

    public void Open()
    {
        if (panel) panel.SetActive(true);
        Refresh();
    }

    public void Close()
    {
        if (panel) panel.SetActive(false);
    }

    public void ResetStats()
    {
        StatsManager.ResetAll();
        Refresh();
    }

    void Refresh()
    {
        if (killsText) killsText.text = "Убийства: " + StatsManager.Kills;
        if (deathsText) deathsText.text = "Смерти: " + StatsManager.Deaths;
        if (kdText) kdText.text = "K/D: " + StatsManager.KD.ToString("F2");
        if (matchesText) matchesText.text = "Матчи: " + StatsManager.Matches;
        if (winsText) winsText.text = "Победы: " + StatsManager.Wins;
        if (winRateText) winRateText.text = "Винрейт: " + StatsManager.WinRate.ToString("F1") + "%";
    }
}
