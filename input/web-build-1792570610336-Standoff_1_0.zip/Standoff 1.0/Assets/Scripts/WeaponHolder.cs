using System.Collections;
using UnityEngine;

// Вешается на пустой объект-точку (WeaponPivot). Модели оружия — его дочерние объекты
// с WeaponController. Holder анимирует сам pivot: доставание, убирание, смену оружия,
// смерть (оружие опускается) и покачивание. Сами WeaponController отдачей не конфликтуют,
// т.к. двигают только свой собственный transform.
// Используется и игроком, и ботами/врагами: у каждого свой WeaponHolder.
public class WeaponHolder : MonoBehaviour
{
    [Header("Who")]
    public bool isPlayer = false;          // true — управление клавишами 1..9; false — бот/враг
    public CharacterController owner;      // для покачивания при ходьбе (необязательно)

    [Header("Draw / Holster")]
    public float holsterTime = 0.25f;      // убирание текущего оружия при смене
    public float deathLowerTime = 0.4f;    // опускание при смерти
    public Vector3 loweredOffset = new Vector3(0.05f, -0.45f, -0.10f);
    public Vector3 loweredEuler = new Vector3(-30f, 20f, -10f);
    // Доставание: быстрый подъём с лёгким «отскоком» в конце (кривая > 1 даёт overshoot)
    public AnimationCurve drawCurve = new AnimationCurve(
        new Keyframe(0f, 0f, 0f, 2f),
        new Keyframe(0.75f, 1.06f, 0f, 0f),
        new Keyframe(1f, 1f, 0f, 0f));
    public AnimationCurve holsterCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

    [Header("Sway")]
    public float breathAmount = 0.004f;
    public float breathSpeed = 1.5f;
    public float bobAmount = 0.02f;
    public float bobSpeed = 9f;
    public float swaySmooth = 8f;

    [Header("Audio / Animator (необязательно)")]
    public AudioSource audioSource;
    public AudioClip drawSound;
    public AudioClip holsterSound;
    public Animator animator;              // триггеры "Draw" и "Holster", если нужны

    [Header("Weapons (заполняется автоматически)")]
    public WeaponController[] weapons;
    public bool[] unlocked;                 // какие слоты доступны (купленные)

    public int CurrentIndex { get; private set; } = -1;
    public WeaponController CurrentWeapon => CurrentIndex >= 0 ? weapons[CurrentIndex] : null;
    public bool IsBusy { get; private set; }     // сейчас доставание или смена
    public bool IsLowered { get; private set; }  // опущено (смерть / убрано)
    public bool CanFire => !IsBusy && !IsLowered && CurrentWeapon != null;

    Vector3 restPos, basePos;
    Quaternion restRot, baseRot;
    Vector3 swayOffset;
    float bobTimer;
    Coroutine routine;

    Vector3 LoweredPos => restPos + loweredOffset;
    Quaternion LoweredRot => restRot * Quaternion.Euler(loweredEuler);

    void Awake()
    {
        if (weapons == null || weapons.Length == 0)
            weapons = GetComponentsInChildren<WeaponController>(true);
        restPos = basePos = transform.localPosition;
        restRot = baseRot = transform.localRotation;
        if (!owner) owner = GetComponentInParent<CharacterController>();
        unlocked = new bool[weapons.Length];
        for (int i = 0; i < unlocked.Length; i++) unlocked[i] = !isPlayer || i == 0;
        if (!audioSource) audioSource = GetComponent<AudioSource>();
    }

    void Start()
    {
        if (CurrentIndex < 0) SetCurrent(FirstAvailable());
    }

    void Update()
    {
        if (!isPlayer) return;
        if (HealthSystem.Player != null && HealthSystem.Player.IsDead) return;

        for (int i = 0; i < weapons.Length && i < 9; i++)
            if (Input.GetKeyDown((KeyCode)((int)KeyCode.Alpha1 + i))) Switch(i);
        if (GameInput.NextWeaponDown) SwitchStep(+1);
        int swipe = GameInput.WeaponSwipeDir;
        if (swipe != 0) SwitchStep(swipe);
    }

    void LateUpdate()
    {
        float calm = IsBusy || IsLowered ? 0f : 1f;

        float breath = Mathf.Sin(Time.time * breathSpeed) * breathAmount * calm;

        float bob = 0f;
        if (owner && calm > 0f)
        {
            Vector3 v = owner.velocity;
            v.y = 0f;
            float speed01 = Mathf.Clamp01(v.magnitude / 5f);
            if (owner.isGrounded && speed01 > 0.05f) bobTimer += Time.deltaTime * bobSpeed * speed01;
            bob = Mathf.Sin(bobTimer) * bobAmount * speed01;
        }

        Vector3 target = new Vector3(bob, breath + Mathf.Abs(bob) * 0.5f, 0f);
        swayOffset = Vector3.Lerp(swayOffset, target, Time.deltaTime * swaySmooth);

        transform.localPosition = basePos + swayOffset;
        transform.localRotation = baseRot;
    }

    // ---------- Публичное API ----------

    // Доставание текущего оружия. snapLowered=true — сначала поставить pivot в опущенное положение
    // (используется при спавне/респавне, чтобы было видно доставание).
    public void Draw(bool snapLowered = false)
    {
        if (weapons == null || weapons.Length == 0) return;
        if (CurrentIndex < 0) SetCurrent(FirstAvailable());
        if (snapLowered)
        {
            basePos = LoweredPos;
            baseRot = LoweredRot;
        }
        StartRoutine(DrawRoutine());
    }

    // Смена оружия: убрать текущее, достать новое.
    public void Switch(int index)
    {
        if (index == CurrentIndex || index < 0 || index >= weapons.Length || weapons[index] == null || !unlocked[index]) return;
        StartRoutine(SwitchRoutine(index));
    }

    // Опустить оружие при смерти.
    public void LowerForDeath()
    {
        IsLowered = true;
        PlayHolster();
        StartRoutine(Transition(LoweredPos, LoweredRot, deathLowerTime, holsterCurve));
    }

    public bool IsUnlocked(int index) => index >= 0 && index < unlocked.Length && unlocked[index];
    public void Unlock(int index) { if (index >= 0 && index < unlocked.Length) unlocked[index] = true; }

    // ---------- Раунд (соревновательный режим) ----------

    // Начало раунда: полный магазин у всех; игрок получает только нож и пистолет,
    // остальное оружие снова нужно купить в фриз-тайм. Бот имеет всё оружие,
    // в руках — винтовка (или пистолет, если винтовки нет).
    public void GiveRoundLoadout()
    {
        if (weapons == null || weapons.Length == 0) return;

        for (int i = 0; i < weapons.Length; i++)
        {
            var w = weapons[i];
            if (w == null) { unlocked[i] = false; continue; }
            w.Refill();
            unlocked[i] = !isPlayer || w.IsMelee || w.IsPistol;
        }

        int start = PreferredStart();
        if (start >= 0) SetCurrent(start);
        IsLowered = false;
    }

    int PreferredStart()
    {
        int pistol = -1, rifle = -1;
        for (int i = 0; i < weapons.Length; i++)
        {
            if (weapons[i] == null || !unlocked[i]) continue;
            if (weapons[i].IsPistol && pistol < 0) pistol = i;
            if (!weapons[i].IsMelee && !weapons[i].IsPistol && rifle < 0) rifle = i;
        }
        if (isPlayer) return pistol >= 0 ? pistol : FirstAvailable();
        if (rifle >= 0) return rifle;
        return pistol >= 0 ? pistol : FirstAvailable();
    }

    // ---------- Внутреннее ----------

    void StartRoutine(IEnumerator r)
    {
        if (!isActiveAndEnabled) return;      // корутину нельзя запустить на неактивном объекте
        if (routine != null) StopCoroutine(routine);
        routine = StartCoroutine(r);
    }

    IEnumerator DrawRoutine()
    {
        IsBusy = true;
        IsLowered = false;
        if (animator) animator.SetTrigger("Draw");
        if (audioSource && drawSound) audioSource.PlayOneShot(drawSound);

        float duration = CurrentWeapon ? CurrentWeapon.drawTime : 0.5f;
        yield return Transition(restPos, restRot, duration, drawCurve);

        IsBusy = false;
    }

    IEnumerator SwitchRoutine(int index)
    {
        IsBusy = true;
        PlayHolster();
        yield return Transition(LoweredPos, LoweredRot, holsterTime, holsterCurve);

        SetCurrent(index);
        IsLowered = true;   // между убиранием и доставанием оружие опущено
        yield return DrawRoutine();
    }

    // Плавный переход pose от текущего положения к целевому (корректно прерывается).
    IEnumerator Transition(Vector3 toPos, Quaternion toRot, float duration, AnimationCurve curve)
    {
        Vector3 fromPos = basePos;
        Quaternion fromRot = baseRot;
        float t = 0f;
        duration = Mathf.Max(duration, 0.01f);

        while (t < duration)
        {
            t += Time.deltaTime;
            float k = curve.Evaluate(Mathf.Clamp01(t / duration));
            basePos = Vector3.LerpUnclamped(fromPos, toPos, k);
            baseRot = Quaternion.SlerpUnclamped(fromRot, toRot, k);
            yield return null;
        }

        basePos = toPos;
        baseRot = toRot;
    }

    void PlayHolster()
    {
        if (animator) animator.SetTrigger("Holster");
        if (audioSource && holsterSound) audioSource.PlayOneShot(holsterSound);
    }

    void SetCurrent(int index)
    {
        for (int i = 0; i < weapons.Length; i++)
            if (weapons[i] != null) weapons[i].gameObject.SetActive(i == index);
        CurrentIndex = index;
    }

    // Следующее (+1) или предыдущее (-1) открытое оружие: кнопка Q, свайп вверх/вниз
    void SwitchStep(int dir)
    {
        int n = weapons.Length;
        if (n == 0) return;
        for (int k = 1; k <= n; k++)
        {
            int i = ((CurrentIndex + dir * k) % n + n) % n;
            if (weapons[i] != null && unlocked[i])
            {
                Switch(i);
                HUDManager.Instance?.ShowMessage(weapons[i].weaponName, 1f);
                return;
            }
        }
    }

    int FirstAvailable()
    {
        for (int i = 0; i < weapons.Length; i++) if (weapons[i] != null && unlocked[i]) return i;
        return -1;
    }
}
