using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Сетевой матч (командный бой по сети). Вешается на объект в игровой сцене.
// Каждый клиент управляет своим игроком и шлёт его состояние (≈15 раз/с).
// Чужие игроки — RemotePlayer-прокси. Урон: стрелок шлёт hit, атакованный клиент применяет урон.
// Счёт и конец матча ведёт хост (сервер).
public class NetMatch : MonoBehaviour
{
    public static NetMatch Instance { get; private set; }

    [Tooltip("Префаб чужого игрока: HealthSystem (НЕ тег Player!), RemotePlayer, WeaponPivot с WeaponHolder")]
    public GameObject remotePlayerPrefab;
    public Transform[] spawns;
    public HUDManager hud;
    public float stateRate = 15f;
    public float endDelay = 5f;

    class RemoteEntry
    {
        public int id;
        public HealthSystem hs;
        public RemotePlayer view;
    }

    readonly Dictionary<int, RemoteEntry> remotes = new Dictionary<int, RemoteEntry>();
    NetManager net;
    HealthSystem local;
    float sendTimer;

    public bool IsActive => net != null && net.IsConnected && enabled;

    void Awake() => Instance = this;

    void Start()
    {
        net = NetManager.Instance;
        if (net == null || !net.IsConnected) { enabled = false; return; }

        net.MessageReceived += OnMessage;
        net.Disconnected += OnDisconnected;
        local = HealthSystem.Player;

        // В сетевом матче ботов нет — только люди
        foreach (var b in FindObjectsOfType<BotAI>()) b.gameObject.SetActive(false);

        for (int i = 0; i < net.Roster.Count; i++)
        {
            var e = net.Roster[i];
            if (e.id == net.LocalId)
            {
                if (local != null) { local.team = e.team; local.NetId = e.id; }
            }
            else SpawnRemote(e.id, e.name, e.team, i);
        }

        hud?.SetRoundInfo($"Матч по сети: до {net.LobbyLimit} убийств");
    }

    void OnDestroy()
    {
        if (Instance == this) Instance = null;
        if (net != null)
        {
            net.MessageReceived -= OnMessage;
            net.Disconnected -= OnDisconnected;
        }
    }

    void Update()
    {
        if (!IsActive || local == null) return;
        sendTimer -= Time.deltaTime;
        if (sendTimer > 0f) return;
        sendTimer = 1f / stateRate;

        Transform t = local.transform;
        net.Send(new NetMsg
        {
            type = "state",
            id = net.LocalId,
            x = t.position.x, y = t.position.y, z = t.position.z,
            ry = t.eulerAngles.y,
            health = local.IsDead ? 0f : local.currentHealth
        });
    }

    public Transform PickSpawn(int index = -1)
    {
        if (spawns == null || spawns.Length == 0) return transform;
        int i = index >= 0 ? index % spawns.Length : Random.Range(0, spawns.Length);
        return spawns[i];
    }

    // Вызывается WeaponController, когда стрелок попал в чужого игрока
    public void ReportHit(int targetId, float damage) =>
        net.Send(new NetMsg { type = "hit", id = targetId, damage = damage });

    // Вызывается HealthSystem, когда умер наш игрок
    public void ReportDeath(int killerId) =>
        net.Send(new NetMsg { type = "death", id = net.LocalId, attacker = killerId });

    void SpawnRemote(int id, string name, Team team, int index)
    {
        if (remotePlayerPrefab == null)
        {
            Debug.LogError("NetMatch: не назначен remotePlayerPrefab");
            return;
        }
        Transform sp = PickSpawn(index);
        var go = Instantiate(remotePlayerPrefab, sp.position, sp.rotation);
        go.name = "Remote_" + name;
        var hs = go.GetComponent<HealthSystem>();
        var view = go.GetComponent<RemotePlayer>();
        if (hs == null || view == null)
        {
            Debug.LogError("NetMatch: у префаба чужого игрока нет HealthSystem или RemotePlayer");
            return;
        }
        hs.IsRemote = true;
        hs.NetId = id;
        hs.team = team;
        remotes[id] = new RemoteEntry { id = id, hs = hs, view = view };
    }

    void OnMessage(NetMsg m)
    {
        switch (m.type)
        {
            case "state":
                if (m.id != net.LocalId && remotes.TryGetValue(m.id, out var r))
                    r.view.ApplyState(m.x, m.y, m.z, m.ry, m.health);
                break;

            case "hit":
                if (m.id == net.LocalId && local != null && !local.IsDead)
                {
                    HealthSystem attacker = null;
                    if (remotes.TryGetValue(m.attacker, out var a)) attacker = a.hs;
                    local.TakeDamage(m.damage, attacker);
                }
                break;

            case "score":
                ShowScore(m.data);
                break;

            case "end":
                hud?.ShowMessage("Матч окончен", endDelay);
                Invoke(nameof(BackToMenu), endDelay);
                enabled = false;
                break;

            case "bye":
                if (remotes.TryGetValue(m.id, out var gone))
                {
                    if (gone.hs != null) Destroy(gone.hs.gameObject);
                    remotes.Remove(m.id);
                }
                break;
        }
    }

    void ShowScore(string data)
    {
        var p = (data ?? "").Split(';');
        if (p.Length == 2) hud?.SetRoundInfo($"T {p[0]} : {p[1]} CT   (до {net.LobbyLimit})");
    }

    void OnDisconnected()
    {
        enabled = false;
        hud?.ShowMessage("Соединение с хостом потеряно", endDelay);
        Invoke(nameof(BackToMenu), endDelay);
    }

    void BackToMenu() => SceneManager.LoadScene("MainMenu");
}
