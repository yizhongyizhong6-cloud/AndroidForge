using UnityEngine;

// ИИ бота: видит игрока (raycast), после задержки реакции идёт к нему и стреляет.
// Движение через CharacterController: сквозь стены, ящики и пол не проходит.
// Обход препятствий: если впереди стена, ящик или другой бот — бот огибает их (без навмеша).
[RequireComponent(typeof(HealthSystem))]
public class BotAI : MonoBehaviour
{
    public Transform eyes;
    public WeaponHolder holder;
    public float viewRange = 60f;
    public float preferredDistance = 12f;
    public float fireInterval = 0.35f;
    public float turnSpeed = 8f;
    public float killY = -15f;              // ниже этого бот провалился под карту — убиваем

    BotSettings s;
    HealthSystem self;
    CharacterController cc;
    bool addedController;
    float reactionTimer, fireTimer, seeTimer, verticalVelocity;
    bool seesCached;

    const float Gravity = 20f;

    Vector3 EyesPos => eyes ? eyes.position : transform.position + Vector3.up * 1.6f;

    void Awake()
    {
        self = GetComponent<HealthSystem>();
        if (!holder) holder = GetComponentInChildren<WeaponHolder>(true);
        s = BotDifficultyUtil.Settings(BotDifficultyUtil.Load());
        self.maxHealth *= s.healthMultiplier;

        cc = GetComponent<CharacterController>();
        if (cc == null)
        {
            cc = gameObject.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.35f;
            cc.center = new Vector3(0f, 0.9f, 0f);
            cc.stepOffset = 0.4f;
            addedController = true;
        }
    }

    void Update()
    {
        if (self.IsDead) return;
        if (transform.position.y < killY)
        {
            self.TakeDamage(99999f);     // провалился под карту
            return;
        }

        float dt = Time.deltaTime;
        Vector3 horizontal = Vector3.zero;

        bool frozen = CompetitiveRoundManager.FreezeAll;
        HealthSystem p = HealthSystem.Player;

        if (!frozen && p != null && !p.IsDead && !(self.team != Team.None && self.team == p.team))
        {
            horizontal = Engage(p);
        }

        // Гравитация всегда, чтобы бот стоял на полу и не висел в воздухе
        verticalVelocity = cc.isGrounded ? -2f : verticalVelocity - Gravity * dt;
        cc.Move((horizontal + Vector3.up * verticalVelocity) * dt);
    }

    // Поворачивает к игроку, стреляет, возвращает желаемую скорость движения по горизонтали
    Vector3 Engage(HealthSystem p)
    {
        Vector3 toPlayer = p.transform.position - transform.position;
        Vector3 flat = new Vector3(toPlayer.x, 0f, toPlayer.z);

        seeTimer -= Time.deltaTime;
        if (seeTimer <= 0f)
        {
            seesCached = CanSee(p.transform);   // raycast дорогой — не каждый кадр
            seeTimer = 0.15f;
        }
        bool sees = seesCached;
        reactionTimer = sees ? reactionTimer + Time.deltaTime : 0f;
        bool engaged = sees && reactionTimer >= s.reactionTime;

        if (flat.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(flat), Time.deltaTime * turnSpeed);

        Vector3 move = Vector3.zero;
        if (flat.magnitude > preferredDistance)
            move = SteerDirection(flat.normalized) * s.moveSpeed;

        if (engaged && holder != null && holder.CanFire && holder.CurrentWeapon != null)
        {
            fireTimer -= Time.deltaTime;
            if (fireTimer <= 0f)
            {
                Vector3 aim = (p.transform.position + Vector3.up * 0.8f) - EyesPos;
                float spread = s.spread * (2f - s.accuracy);
                holder.CurrentWeapon.TryBotShoot(EyesPos, aim, spread);
                fireTimer = fireInterval * s.fireIntervalMultiplier;
            }
        }

        return move;
    }

    // Направление без препятствий: прямо, либо в обход. Если заперт — стоит на месте.
    Vector3 SteerDirection(Vector3 wanted)
    {
        if (IsClear(wanted)) return wanted;

        float[] angles = { 45f, -45f, 90f, -90f, 135f, -135f };
        foreach (float a in angles)
        {
            Vector3 d = Quaternion.Euler(0f, a, 0f) * wanted;
            if (IsClear(d)) return d;
        }
        return Vector3.zero;
    }

    // Нет ли препятствия впереди на уровне груди (игрока и себя не считаем препятствием)
    bool IsClear(Vector3 dir)
    {
        Vector3 origin = transform.position + Vector3.up * 0.5f + dir * (cc.radius + 0.1f);
        if (!Physics.SphereCast(origin, 0.3f, dir, out RaycastHit hit, 1.0f, ~0, QueryTriggerInteraction.Ignore))
            return true;
        return hit.transform.root == transform.root || hit.transform.root == HealthSystem.Player?.transform.root;
    }

    bool CanSee(Transform target)
    {
        Vector3 origin = EyesPos;
        Vector3 to = (target.position + Vector3.up) - origin;
        if (to.magnitude > viewRange) return false;

        Vector3 dir = to.normalized;
        Vector3 start = origin + dir * 0.5f;   // чтобы не попасть в свой коллайдер
        if (Physics.Raycast(start, dir, out RaycastHit hit, to.magnitude, ~0, QueryTriggerInteraction.Ignore))
            return hit.transform.root == target.root;
        return false;
    }
}
