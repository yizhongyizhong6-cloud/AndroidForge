using UnityEngine;

// Процедурная анимация рук и ног бота (как у персонажей CS:GO):
// ходьба (ноги и руки качаются), и руки тянутся вперёд, когда бот держит оружие.
// Назначь части модели: leftArm, rightArm, leftLeg, rightLeg (их pivot-кости в местах сгиба).
public class BotLimbAnimator : MonoBehaviour
{
    [Header("Limbs")]
    public Transform leftArm, rightArm, leftLeg, rightLeg;
    public WeaponHolder holder;

    [Header("Walk")]
    public float swingAngle = 35f;
    public float stepsPerMeter = 2.5f;

    [Header("Hold weapon")]
    public float aimArmAngle = -75f;
    public float poseSmooth = 10f;

    Quaternion lArmRest, rArmRest, lLegRest, rLegRest;
    Vector3 lastPos;
    float phase, aimBlend;

    void Start()
    {
        lArmRest = Rest(leftArm);
        rArmRest = Rest(rightArm);
        lLegRest = Rest(leftLeg);
        rLegRest = Rest(rightLeg);
        lastPos = transform.position;
    }

    static Quaternion Rest(Transform t) => t != null ? t.localRotation : Quaternion.identity;

    void Update()
    {
        float dt = Mathf.Max(Time.deltaTime, 0.0001f);
        Vector3 v = (transform.position - lastPos) / dt;
        lastPos = transform.position;
        v.y = 0f;

        float speed = v.magnitude;
        float k = Mathf.Clamp01(speed / 3f);
        phase += speed * stepsPerMeter * dt * Mathf.PI * 2f;
        float swing = Mathf.Sin(phase) * swingAngle * k;

        bool armed = holder != null && holder.CurrentWeapon != null;
        aimBlend = Mathf.Lerp(aimBlend, armed ? 1f : 0f, Time.deltaTime * poseSmooth);

        SetX(leftLeg, lLegRest, swing);
        SetX(rightLeg, rLegRest, -swing);
        SetX(leftArm, lArmRest, Mathf.Lerp(-swing * 0.6f, aimArmAngle * 0.8f, aimBlend));
        SetX(rightArm, rArmRest, Mathf.Lerp(swing * 0.6f, aimArmAngle, aimBlend));
    }

    static void SetX(Transform t, Quaternion rest, float angle)
    {
        if (t != null) t.localRotation = rest * Quaternion.Euler(angle, 0f, 0f);
    }
}
