// Инициализация Canvas и базовый игровой цикл
window.addEventListener('load', () => {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    // Тестовая анимация для проверки работоспособности
    let angle = 0;
    function loop() {
        ctx.fillStyle = '#111116';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.save();
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate(angle);
        
        // Рисуем квадрат
        ctx.fillStyle = '#00ffcc';
        ctx.fillRect(-50, -50, 100, 100);
        ctx.restore();

        // Вывод текста
        ctx.fillStyle = '#ffffff';
        ctx.font = '20px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Игра работает успешно!', canvas.width / 2, canvas.height / 2 + 100);

        angle += 0.02;
        requestAnimationFrame(loop);
    }
    loop();
});