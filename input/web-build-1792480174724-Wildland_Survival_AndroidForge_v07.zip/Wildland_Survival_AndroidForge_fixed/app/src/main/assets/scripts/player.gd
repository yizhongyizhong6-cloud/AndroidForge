extends CharacterBody3D

var game: Node
@export var move_speed := 7.0
var look_sensitivity := 0.01
var gravity := 28.0
var yaw := 0.0
var pitch := -0.18
var touch_look_id := -1
var previous_touch := Vector2.ZERO
var move_input := Vector2.ZERO
var joystick_origin := Vector2.ZERO
var joystick_touch_id := -1
var joystick_radius := 90.0
var camera: Camera3D
var vehicle_camera := false
var target_car: Node3D
var stick_visual: Control
var stick_knob: Panel

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_PAUSABLE
	floor_snap_length = 0.4
	floor_max_angle = deg_to_rad(50.0)

	for action in ["move_forward", "move_back", "move_left", "move_right"]:
		if not InputMap.has_action(action):
			InputMap.add_action(action)
	_add_default_key("move_forward", KEY_W)
	_add_default_key("move_back", KEY_S)
	_add_default_key("move_left", KEY_A)
	_add_default_key("move_right", KEY_D)

	var collision := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.4
	capsule.height = 1.7
	collision.shape = capsule
	collision.position.y = 0.95
	add_child(collision)

	var body_vis := MeshInstance3D.new()
	var body_mesh := CapsuleMesh.new()
	body_mesh.radius = 0.4
	body_mesh.height = 1.7
	body_vis.mesh = body_mesh
	body_vis.position.y = 0.95
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color(0.55, 0.38, 0.22)
	body_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	body_vis.material_override = body_mat
	add_child(body_vis)

	var head := MeshInstance3D.new()
	var head_mesh := SphereMesh.new()
	head_mesh.radius = 0.28
	head_mesh.height = 0.56
	head.mesh = head_mesh
	head.position.y = 2.05
	var head_mat := StandardMaterial3D.new()
	head_mat.albedo_color = Color(0.82, 0.65, 0.48)
	head_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	head.material_override = head_mat
	add_child(head)

	camera = Camera3D.new()
	camera.name = "PlayerCamera"
	camera.position = Vector3(0, 2.4, 6.0)
	camera.rotation.x = -0.22
	camera.current = true
	camera.far = 500.0
	camera.near = 0.08
	add_child(camera)

	_create_stick_ui()

func _create_stick_ui() -> void:
	var layer := CanvasLayer.new()
	layer.layer = 20
	add_child(layer)
	stick_visual = Control.new()
	stick_visual.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	stick_visual.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(stick_visual)

	var base := Panel.new()
	base.name = "StickBase"
	base.size = Vector2(joystick_radius * 2.2, joystick_radius * 2.2)
	base.modulate = Color(1, 1, 1, 0.28)
	base.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stick_visual.add_child(base)

	stick_knob = Panel.new()
	stick_knob.size = Vector2(56, 56)
	stick_knob.modulate = Color(0.9, 0.95, 1.0, 0.55)
	stick_knob.mouse_filter = Control.MOUSE_FILTER_IGNORE
	stick_visual.add_child(stick_knob)
	_hide_stick()

func _show_stick(at: Vector2) -> void:
	if not stick_visual:
		return
	var base: Panel = stick_visual.get_node("StickBase")
	base.position = at - base.size * 0.5
	stick_knob.position = at - stick_knob.size * 0.5
	base.visible = true
	stick_knob.visible = true

func _hide_stick() -> void:
	if not stick_visual:
		return
	stick_visual.get_node("StickBase").visible = false
	stick_knob.visible = false

func _add_default_key(action: String, keycode: Key) -> void:
	for e in InputMap.action_get_events(action):
		if e is InputEventKey and e.physical_keycode == keycode:
			return
	var ev := InputEventKey.new()
	ev.physical_keycode = keycode
	InputMap.action_add_event(action, ev)

func set_sensitivity(value: float) -> void:
	look_sensitivity = clampf(value, 0.002, 0.04)

func set_vehicle_camera(enabled: bool, vehicle: Node3D) -> void:
	vehicle_camera = enabled
	target_car = vehicle if enabled else null

func get_move_input() -> Vector2:
	var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if keyboard.length() > 0.1:
		return keyboard
	return move_input

func _physics_process(delta: float) -> void:
	if vehicle_camera and is_instance_valid(target_car):
		camera.global_position = target_car.global_position + target_car.global_transform.basis.z * 8.0 + Vector3(0, 3.5, 0)
		camera.look_at(target_car.global_position + Vector3(0, 1.2, 0), Vector3.UP)
		return

	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = 0.0

	var input_dir := get_move_input()
	var forward := -global_transform.basis.z
	var right := global_transform.basis.x
	var direction := right * input_dir.x + forward * -input_dir.y
	if direction.length() > 0.05:
		direction = direction.normalized()
		velocity.x = direction.x * move_speed
		velocity.z = direction.z * move_speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, move_speed * 8.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, move_speed * 8.0 * delta)

	move_and_slide()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed:
			var half := get_viewport().get_visible_rect().size.x * 0.45
			if event.position.x < half and joystick_touch_id == -1:
				joystick_touch_id = event.index
				joystick_origin = event.position
				_show_stick(event.position)
				_update_stick(event.position)
			else:
				touch_look_id = event.index
				previous_touch = event.position
		else:
			if event.index == joystick_touch_id:
				joystick_touch_id = -1
				move_input = Vector2.ZERO
				_hide_stick()
			if event.index == touch_look_id:
				touch_look_id = -1
	elif event is InputEventScreenDrag:
		if event.index == joystick_touch_id:
			_update_stick(event.position)
		elif event.index == touch_look_id:
			var d := event.position - previous_touch
			yaw -= d.x * look_sensitivity
			pitch = clampf(pitch - d.y * look_sensitivity, -0.85, 0.35)
			rotation.y = yaw
			camera.rotation.x = pitch
			previous_touch = event.position

func _update_stick(pos: Vector2) -> void:
	var delta := pos - joystick_origin
	if delta.length() > joystick_radius:
		delta = delta.normalized() * joystick_radius
	move_input = Vector2(delta.x, delta.y) / joystick_radius
	if stick_knob:
		stick_knob.position = joystick_origin + delta - stick_knob.size * 0.5
