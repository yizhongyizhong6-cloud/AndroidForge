console.log("Game loaded");

const canvas = document.getElementById("gameCanvas");

function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
window.addEventListener("resize", resize);
resize();
