using UnityEngine;
using UnityEngine.UI;
using TMPro;

// ============================================
// МЕНЕДЖЕР ИНТЕРФЕЙСА
// ============================================
public class HUDManager : MonoBehaviour
{
    [Header("Weapon Info")]
    public TextMeshProUGUI ammoText;
    public TextMeshProUGUI weaponNameText;
    public Image weaponIcon;

    [Header("Health")]
    public Image healthBar;
    public TextMeshProUGUI healthText;

    [Header("Crosshair")]
    public Image crosshair;

    private WeaponController currentWeapon;

    void Update()
    {
        if (currentWeapon == null)
        {
            GameObject weaponObj = GameObject.FindGameObjectWithTag("Weapon");
            if (weaponObj)
                currentWeapon = weaponObj.GetComponent<WeaponController>();
        }

        if (currentWeapon != null)
        {
            if (ammoText != null)
                ammoText.text = currentWeapon.currentAmmo + " / " + currentWeapon.maxAmmo;

            if (weaponNameText != null)
                weaponNameText.text = currentWeapon.weaponName;
        }
    }

    public void UpdateHealth(float currentHealth, float maxHealth)
    {
        if (healthBar != null)
            healthBar.fillAmount = maxHealth > 0 ? currentHealth / maxHealth : 0f;

        if (healthText != null)
            healthText.text = Mathf.RoundToInt(currentHealth).ToString();
    }
}
