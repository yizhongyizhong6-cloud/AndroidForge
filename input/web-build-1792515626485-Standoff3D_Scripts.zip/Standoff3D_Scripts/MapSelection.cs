using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

// ============================================
// ВЫБОР КАРТ (ДЛЯ ГЛАВНОГО МЕНЮ)
// ============================================
public class MapSelection : MonoBehaviour
{
    [Header("Map Buttons")]
    public Button sandstoneButton;
    public Button dust2Button;

    [Header("Game Mode")]
    public Toggle pvpToggle;

    void Start()
    {
        if (sandstoneButton != null)
            sandstoneButton.onClick.AddListener(() => LoadMap("Sandstone"));

        if (dust2Button != null)
            dust2Button.onClick.AddListener(() => LoadMap("Dust2"));
    }

    void LoadMap(string mapName)
    {
        if (pvpToggle != null && pvpToggle.isOn)
            PlayerPrefs.SetString("GameMode", "PVP");
        else
            PlayerPrefs.SetString("GameMode", "PVE");

        PlayerPrefs.Save();
        SceneManager.LoadScene(mapName);
    }
}
