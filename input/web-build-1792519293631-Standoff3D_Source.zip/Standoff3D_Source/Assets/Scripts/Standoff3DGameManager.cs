using UnityEngine;
using UnityEngine.SceneManagement;

public class Standoff3DGameManager : MonoBehaviour
{
    public static Standoff3DGameManager Instance;
    [Header("Game Settings")]
    public string gameMode = "PVP";
    public int playerScore = 0;
    public int enemyScore = 0;

    void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else { Destroy(gameObject); return; }
        gameMode = PlayerPrefs.GetString("GameMode", "PVP");
    }

    public void PlayerDied() => Invoke(nameof(RestartLevel), 3f);
    void RestartLevel() => SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    public void ReturnToMenu() => SceneManager.LoadScene("MainMenu");
}
