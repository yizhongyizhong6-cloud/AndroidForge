using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MapSelection : MonoBehaviour
{
    [Header("Map Buttons")]
    public Button sandstoneButton;
    public Button dust2Button;
    [Header("Game Mode")]
    public Toggle pvpToggle;

    void Start()
    {
        if (sandstoneButton) sandstoneButton.onClick.AddListener(() => LoadMap("Sandstone"));
        if (dust2Button) dust2Button.onClick.AddListener(() => LoadMap("Dust2"));
    }

    void LoadMap(string mapName)
    {
        PlayerPrefs.SetString("GameMode", pvpToggle != null && pvpToggle.isOn ? "PVP" : "PVE");
        PlayerPrefs.Save();
        SceneManager.LoadScene(mapName);
    }
}
