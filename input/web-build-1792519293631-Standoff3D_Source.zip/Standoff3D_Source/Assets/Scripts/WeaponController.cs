using UnityEngine;
using System.Collections;

public class WeaponController : MonoBehaviour
{
    [Header("Weapon Settings")]
    public string weaponName = "AK-47";
    public int maxAmmo = 30;
    public int currentAmmo;
    public float fireRate = 0.1f;
    public float reloadTime = 2.5f;
    public float damage = 25f;
    public float range = 100f;
    [Header("Audio")]
    public AudioClip shootSound, boltSound, reloadSound;
    public AudioSource audioSource;
    [Header("Animation")]
    public Animator weaponAnimator;
    [Header("Effects")]
    public ParticleSystem muzzleFlash;
    public GameObject bulletHoleDecal;
    [Header("Recoil")]
    public float recoilAmount = 2f;
    public float recoilSpeed = 10f;

    float nextTimeToFire;
    bool isReloading;
    Camera fpsCam;
    Vector3 originalPosition;

    void Start()
    {
        currentAmmo = maxAmmo;
        fpsCam = Camera.main;
        originalPosition = transform.localPosition;
        if (audioSource == null) audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        if (isReloading) return;
        if (currentAmmo <= 0) { StartReload(); return; }
        if (Input.GetButton("Fire1") && Time.time >= nextTimeToFire)
        {
            nextTimeToFire = Time.time + 1f / Mathf.Max(fireRate, 0.01f);
            Shoot();
        }
        if (Input.GetKeyDown(KeyCode.R) && currentAmmo < maxAmmo) StartReload();
    }

    void Shoot()
    {
        currentAmmo--;
        if (audioSource && shootSound) audioSource.PlayOneShot(shootSound);
        if (weaponAnimator) weaponAnimator.SetTrigger("Shoot");
        if (muzzleFlash) muzzleFlash.Play();
        if (boltSound) Invoke(nameof(PlayBoltSound), 0.1f);
        StartCoroutine(Recoil());
        if (fpsCam == null) return;
        if (Physics.Raycast(fpsCam.transform.position, fpsCam.transform.forward, out RaycastHit hit, range))
        {
            HealthSystem target = hit.transform.GetComponent<HealthSystem>();
            if (target != null) target.TakeDamage(damage);
            if (bulletHoleDecal)
            {
                GameObject decal = Instantiate(bulletHoleDecal, hit.point, Quaternion.LookRotation(hit.normal));
                Destroy(decal, 10f);
            }
        }
    }

    void PlayBoltSound() { if (audioSource && boltSound) audioSource.PlayOneShot(boltSound, 0.7f); }
    void StartReload()
    {
        if (isReloading) return;
        isReloading = true;
        if (weaponAnimator) weaponAnimator.SetTrigger("Reload");
        if (audioSource && reloadSound) audioSource.PlayOneShot(reloadSound);
        Invoke(nameof(FinishReload), reloadTime);
    }
    void FinishReload() { currentAmmo = maxAmmo; isReloading = false; }

    IEnumerator Recoil()
    {
        Vector3 targetPos = originalPosition - new Vector3(0, 0, recoilAmount * 0.01f);
        float elapsed = 0;
        while (elapsed < 0.05f)
        {
            transform.localPosition = Vector3.Lerp(transform.localPosition, targetPos, elapsed / 0.05f);
            elapsed += Time.deltaTime; yield return null;
        }
        elapsed = 0;
        while (elapsed < 0.15f)
        {
            transform.localPosition = Vector3.Lerp(transform.localPosition, originalPosition, elapsed / 0.15f);
            elapsed += Time.deltaTime; yield return null;
        }
        transform.localPosition = originalPosition;
    }
}
