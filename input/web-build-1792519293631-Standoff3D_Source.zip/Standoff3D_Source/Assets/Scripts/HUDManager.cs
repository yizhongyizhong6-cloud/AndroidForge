using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HUDManager : MonoBehaviour
{
    [Header("Weapon Info")]
    public TextMeshProUGUI ammoText;
    public TextMeshProUGUI weaponNameText;
    public Image weaponIcon;
    [Header("Health")]
    public Image healthBar;
    public TextMeshProUGUI healthText;
    [Header("Crosshair")]
    public Image crosshair;
    WeaponController currentWeapon;

    void Update()
    {
        if (currentWeapon == null)
        {
            GameObject weaponObj = GameObject.FindGameObjectWithTag("Weapon");
            if (weaponObj) currentWeapon = weaponObj.GetComponent<WeaponController>();
        }
        if (currentWeapon != null)
        {
            if (ammoText) ammoText.text = currentWeapon.currentAmmo + " / " + currentWeapon.maxAmmo;
            if (weaponNameText) weaponNameText.text = currentWeapon.weaponName;
        }
    }

    public void UpdateHealth(float currentHealth, float maxHealth)
    {
        if (healthBar) healthBar.fillAmount = maxHealth > 0 ? currentHealth / maxHealth : 0;
        if (healthText) healthText.text = Mathf.RoundToInt(currentHealth).ToString();
    }
}
