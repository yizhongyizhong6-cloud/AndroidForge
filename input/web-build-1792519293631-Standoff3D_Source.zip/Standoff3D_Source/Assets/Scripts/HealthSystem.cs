using UnityEngine;

public class HealthSystem : MonoBehaviour
{
    public float maxHealth = 100f;
    public float currentHealth;
    HUDManager hudManager;

    void Start() { currentHealth = maxHealth; hudManager = FindObjectOfType<HUDManager>(); }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;
        if (hudManager) hudManager.UpdateHealth(currentHealth, maxHealth);
        if (currentHealth <= 0) Die();
    }

    void Die()
    {
        Debug.Log(gameObject.name + " died!");
        if (gameObject.CompareTag("Player"))
        {
            if (Standoff3DGameManager.Instance) Standoff3DGameManager.Instance.PlayerDied();
        }
        else Destroy(gameObject);
    }
}
