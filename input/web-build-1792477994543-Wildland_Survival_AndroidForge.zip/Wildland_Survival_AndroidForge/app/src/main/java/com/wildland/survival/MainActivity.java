package com.wildland.survival;

import org.godotengine.godot.GodotActivity;

public class MainActivity extends GodotActivity {
}
