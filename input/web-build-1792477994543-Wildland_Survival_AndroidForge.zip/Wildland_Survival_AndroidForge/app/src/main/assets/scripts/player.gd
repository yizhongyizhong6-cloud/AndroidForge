extends CharacterBody3D

var game: Node
@export var move_speed := 5.5
var look_sensitivity := 0.008
var gravity := 20.0
var yaw := 0.0
var pitch := -0.12
var touch_look_id := -1
var previous_touch := Vector2.ZERO
var move_input := Vector2.ZERO
var joystick_origin := Vector2(110, 590)
var joystick_touch_id := -1
var joystick_radius := 72.0
var camera: Camera3D
var vehicle_camera := false
var target_car: Node3D

func _ready() -> void:
    for action in ["move_forward", "move_back", "move_left", "move_right"]:
        if not InputMap.has_action(action):
            InputMap.add_action(action)
    _add_default_key("move_forward", KEY_W)
    _add_default_key("move_back", KEY_S)
    _add_default_key("move_left", KEY_A)
    _add_default_key("move_right", KEY_D)

    var collision := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.8
    collision.shape = capsule
    collision.position.y = 0.9
    add_child(collision)

    var visual := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.38
    mesh.height = 1.8
    visual.mesh = mesh
    visual.position.y = 0.9
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.72, 0.55, 0.36)
    visual.material_override = mat
    add_child(visual)

    camera = Camera3D.new()
    camera.position = Vector3(0, 2.2, 5.4)
    camera.rotation.x = -0.24
    camera.current = true
    add_child(camera)

func _add_default_key(action: String, key: Key) -> void:
    if InputMap.action_get_events(action).is_empty():
        var event := InputEventKey.new()
        event.physical_keycode = key
        InputMap.action_add_event(action, event)

func set_sensitivity(value: float) -> void:
    look_sensitivity = value

func set_vehicle_camera(enabled: bool, vehicle: Node3D) -> void:
    vehicle_camera = enabled
    target_car = vehicle if enabled else null

func get_move_input() -> Vector2:
    var keyboard := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    if keyboard.length() > 0.1:
        return keyboard
    return move_input

func _physics_process(delta: float) -> void:
    if vehicle_camera and is_instance_valid(target_car):
        camera.global_position = target_car.global_position + target_car.global_transform.basis.z * 7.0 + Vector3(0, 3.2, 0)
        camera.look_at(target_car.global_position + Vector3(0, 1, 0), Vector3.UP)
        return
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0.0
    var input_dir := get_move_input()
    var forward := -global_transform.basis.z
    var right := global_transform.basis.x
    var direction := (right * input_dir.x + forward * -input_dir.y).normalized()
    velocity.x = direction.x * move_speed
    velocity.z = direction.z * move_speed
    move_and_slide()

func _input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < get_viewport().get_visible_rect().size.x * 0.42 and joystick_touch_id == -1:
                joystick_touch_id = event.index
                joystick_origin = event.position
                _update_stick(event.position)
            else:
                touch_look_id = event.index
                previous_touch = event.position
        else:
            if event.index == joystick_touch_id:
                joystick_touch_id = -1
                move_input = Vector2.ZERO
            if event.index == touch_look_id:
                touch_look_id = -1
    elif event is InputEventScreenDrag:
        if event.index == joystick_touch_id:
            _update_stick(event.position)
        elif event.index == touch_look_id:
            var delta := event.position - previous_touch
            yaw -= delta.x * look_sensitivity
            pitch = clampf(pitch - delta.y * look_sensitivity, -0.75, 0.25)
            rotation.y = yaw
            camera.rotation.x = pitch
            previous_touch = event.position

func _update_stick(pos: Vector2) -> void:
    var delta := pos - joystick_origin
    if delta.length() > joystick_radius:
        delta = delta.normalized() * joystick_radius
    move_input = Vector2(delta.x, delta.y) / joystick_radius
