extends CharacterBody3D

var driver: CharacterBody3D
var speed := 0.0
var max_speed := 19.0
var acceleration := 10.0
var gravity := 20.0
var steering := 0.0

func _ready() -> void:
    var body_mesh := MeshInstance3D.new()
    var body := BoxMesh.new()
    body.size = Vector3(2.2, 0.75, 4.0)
    body_mesh.mesh = body
    body_mesh.position.y = 0.85
    var paint := StandardMaterial3D.new()
    paint.albedo_color = Color(0.62, 0.22, 0.12)
    body_mesh.material_override = paint
    add_child(body_mesh)

    var cabin_mesh := MeshInstance3D.new()
    var cabin := BoxMesh.new()
    cabin.size = Vector3(1.8, 0.85, 1.8)
    cabin_mesh.mesh = cabin
    cabin_mesh.position = Vector3(0, 1.55, -0.25)
    cabin_mesh.material_override = paint
    add_child(cabin_mesh)

    for x in [-1.12, 1.12]:
        for z in [-1.25, 1.25]:
            var wheel := MeshInstance3D.new()
            var wheel_mesh := CylinderMesh.new()
            wheel_mesh.top_radius = 0.42
            wheel_mesh.bottom_radius = 0.42
            wheel_mesh.height = 0.25
            wheel.mesh = wheel_mesh
            wheel.rotation.z = PI / 2
            wheel.position = Vector3(x, 0.48, z)
            var rubber := StandardMaterial3D.new()
            rubber.albedo_color = Color(0.07, 0.07, 0.07)
            wheel.material_override = rubber
            add_child(wheel)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(2.25, 1.5, 4.1)
    collision.shape = shape
    collision.position.y = 0.85
    add_child(collision)

func set_driver(value: CharacterBody3D) -> void:
    driver = value

func clear_driver() -> void:
    driver = null

func _physics_process(delta: float) -> void:
    if driver and is_instance_valid(driver):
        var input_dir: Vector2 = driver.get_move_input()
        if input_dir.y < -0.1:
            speed = move_toward(speed, max_speed, acceleration * delta)
        elif input_dir.y > 0.1:
            speed = move_toward(speed, -max_speed * 0.45, acceleration * delta)
        else:
            speed = move_toward(speed, 0.0, acceleration * 0.45 * delta)
        steering = move_toward(steering, input_dir.x, 2.2 * delta)
        rotation.y -= steering * 1.15 * delta * clampf(absf(speed) / 5.0, 0.0, 1.0) * signf(speed if speed != 0 else 1)
    else:
        speed = move_toward(speed, 0.0, acceleration * delta)
    velocity.x = -global_transform.basis.z.x * speed
    velocity.z = -global_transform.basis.z.z * speed
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0.0
    move_and_slide()
