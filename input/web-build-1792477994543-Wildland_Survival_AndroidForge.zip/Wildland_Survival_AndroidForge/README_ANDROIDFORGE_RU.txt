Wildland: Survival v0.4 — пакет исходников для AndroidForge

Это исходный Android/Gradle-проект, подготовленный для сборщика AndroidForge.
Внутри app/src/main/assets находится проект Godot: project.godot, сцены и скрипты.

Параметры:
- Godot Android library: 4.3.0.stable
- Android Gradle Plugin: 8.6.1
- Gradle: 8.7
- compileSdk/targetSdk: 34
- minSdk: 24
- Архитектура приложения зависит от опубликованной Godot Android library.

Загрузите весь ZIP в AndroidForge и выберите сборку debug. Если сборка упадёт на загрузке зависимости org.godotengine:godot:4.3.0.stable, проверьте лог: версия библиотеки должна быть доступна из Maven Central.

Важно: проект упакован под сборку AndroidForge, но APK здесь не собран, а запуск на устройстве не проверен. Godot-версия в исходном проекте обозначена как 4.3+; для этой обёртки зафиксирована библиотека Godot 4.3.0.stable.
