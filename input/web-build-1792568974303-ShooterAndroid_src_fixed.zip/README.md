# Шутер 3D — Android (WebView)

Android-проект, который открывает игру `app/src/main/assets/index.html` во встроенном WebView.

- Пакет: `com.standoff3d.game`
- Название: «Шутер 3D»
- minSdk 24, targetSdk 34

Сборка: `./gradlew assembleDebug` (APK появится в `app/build/outputs/apk/debug/`).

Важно: игра подгружает Tailwind, Three.js и FontAwesome с CDN, поэтому нужен интернет
при первом запуске (или замени эти библиотеки локальными файлами в `assets/`).

## Изменения
- `assets/index.html`: если Three.js не загрузился (нет интернета), показывается сообщение вместо чёрного экрана.

## Известно
- Gradle wrapper (`gradlew`, `gradle/wrapper/`) в архиве отсутствует. Сборка требует установленного Gradle 8.x и Android SDK.
