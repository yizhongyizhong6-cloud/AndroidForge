# Aim Trainer Android

Standalone Android aim-trainer prototype. It does not read or control PUBG Mobile.

## Build APK
1. Open this folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on the Android device.

Requires Android Studio with Android SDK 35 and JDK 17.
