package com.example.aimtrainer;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.MotionEvent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.content.Context;
import java.util.Random;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        setContentView(new TrainerView(this));
    }

    static class TrainerView extends View {
        final Paint p = new Paint(3);
        final Random random = new Random();
        float targetX, targetY, vx = 190, vy = 120;
        float aimX, aimY, sensitivity = 0.18f, radius = 150;
        long last = 0;
        int score = 0, shots = 0;
        boolean tracking = false, dragging = false;
        float touchX, touchY;
        String message = "TAP TARGET  •  HOLD TRACK TO FOLLOW";

        TrainerView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            p.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        }

        void resetTarget() {
            float w = Math.max(1, getWidth()), h = Math.max(1, getHeight());
            targetX = 80 + random.nextFloat() * Math.max(1, w - 160);
            targetY = 100 + random.nextFloat() * Math.max(1, h - 200);
            vx = (random.nextBoolean() ? 1 : -1) * (100 + random.nextFloat()*170);
            vy = (random.nextBoolean() ? 1 : -1) * (70 + random.nextFloat()*140);
        }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(15,24,32));
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(2); p.setColor(Color.rgb(37,57,67));
            for (int x=0; x<w; x+=48) c.drawLine(x,0,x,h,p);
            for (int y=0; y<h; y+=48) c.drawLine(0,y,w,y,p);

            long now=System.nanoTime();
            if (last!=0) {
                float dt=Math.min(.04f,(now-last)/1_000_000_000f);
                targetX += vx*dt; targetY += vy*dt;
                if (targetX<36 || targetX>w-36) vx=-vx;
                if (targetY<80 || targetY>h-36) vy=-vy;
            }
            last=now;
            if (targetX==0) resetTarget();

            // Target
            p.setStyle(Paint.Style.FILL); p.setColor(Color.rgb(255,90,90));
            c.drawCircle(targetX,targetY,24,p);
            p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.WHITE);
            c.drawCircle(targetX,targetY,31,p);
            c.drawLine(targetX-40,targetY,targetX+40,targetY,p);
            c.drawLine(targetX,targetY-40,targetX,targetY+40,p);

            // Aim point follows target only while tracking is held.
            if (tracking) {
                aimX += (targetX-aimX)*sensitivity;
                aimY += (targetY-aimY)*sensitivity;
            }
            p.setColor(Color.rgb(87,227,137)); p.setStrokeWidth(3);
            c.drawCircle(aimX,aimY,18,p);
            c.drawLine(aimX-28,aimY,aimX+28,aimY,p);
            c.drawLine(aimX,aimY-28,aimX,aimY+28,p);

            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setTextSize(24);
            c.drawText("AIM TRAINER",24,34,p);
            p.setTextSize(18); p.setColor(Color.rgb(190,208,216));
            c.drawText("Score: "+score+"    Shots: "+shots+"    Tracking: "+(tracking?"ON":"OFF"),24,62,p);

            RectF b = trackButton();
            p.setColor(tracking?Color.rgb(87,227,137):Color.rgb(48,75,87));
            c.drawRoundRect(b,16,16,p);
            p.setColor(tracking?Color.rgb(10,30,20):Color.WHITE); p.setTextSize(19);
            c.drawText(tracking?"TRACKING ON":"HOLD TO TRACK",b.left+18,b.centerY()+7,p);

            RectF reset = resetButton();
            p.setColor(Color.rgb(48,75,87)); c.drawRoundRect(reset,14,14,p);
            p.setColor(Color.WHITE); p.setTextSize(17); c.drawText("RESET",reset.left+18,reset.centerY()+6,p);

            p.setColor(Color.rgb(190,208,216)); p.setTextSize(15);
            c.drawText("Move the green cross toward the red target. Hold TRACK to test follow.",24,h-18,p);
            postInvalidateDelayed(16);
        }

        RectF trackButton(){ return new RectF(getWidth()-245,getHeight()-78,getWidth()-28,getHeight()-24); }
        RectF resetButton(){ return new RectF(getWidth()-130,22,getWidth()-28,65); }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX(), y=e.getY();
            switch(e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    if (resetButton().contains(x,y)) { score=0; shots=0; resetTarget(); invalidate(); return true; }
                    if (trackButton().contains(x,y)) { tracking=true; return true; }
                    dragging=true; touchX=x; touchY=y;
                    if (Math.hypot(x-targetX,y-targetY)<55) { score++; resetTarget(); }
                    else shots++;
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if (dragging && !tracking) {
                        aimX += (x-touchX); aimY += (y-touchY);
                        touchX=x; touchY=y;
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    tracking=false; dragging=false; return true;
            }
            return true;
        }

        @Override protected void onSizeChanged(int w,int h,int oldw,int oldh) {
            aimX=w/2f; aimY=h/2f; resetTarget();
        }
    }
}
