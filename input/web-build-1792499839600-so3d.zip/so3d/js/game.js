// ============================================================
//  СОСТОЯНИЕ МАТЧА
// ============================================================
const lobby = { map:0, team:'CT', diff:'normal', size:4, freeze:5 };
const WIN_ROUNDS=5, ROUND_TIME=100, BUY_EXTRA=15;
let phase='lobby', phaseT=0, round=0, roundT=ROUND_TIME, roundElapsed=0, scoreCT=0, scoreT=0;
let running=false, paused=false, gt=0, editMode=false, diffKey='normal', lastCount=-1, msgT=0;

const DIFF = {
    easy:  { react:1.0, err:0.070, speed:2.7, dmg:0.60, fireMul:0.55, burst:[1,3], pause:[0.5,1.2], strafe:0.3, view:55, head:0.08, turn:4,  hear:0.25 },
    normal:{ react:0.55,err:0.038, speed:3.3, dmg:0.85, fireMul:0.80, burst:[2,5], pause:[0.3,0.8], strafe:0.7, view:70, head:0.25, turn:7,  hear:0.55 },
    expert:{ react:0.20,err:0.013, speed:3.9, dmg:1.00, fireMul:1.00, burst:[3,7], pause:[0.12,0.4],strafe:1.0, view:90, head:0.55, turn:13, hear:0.90 }
};
const BOT_NAMES=['Alex','Bravo','Cobra','Delta','Echo','Fox','Ghost','Hawk','Ivan','Jet','Kilo','Lynx','Max','Nova','Orion','Rex','Sam','Tiger','Viper','Wolf'];

// ---------- бойцы ----------
const me = { isMe:true, name:'Вы', team:'CT', pos:{x:0,y:0,z:0}, vel:{x:0,y:0,z:0}, yaw:0, pitch:0, hp:100, armor:0, alive:true,
    crouch:false, onGround:true, eyeH:1.7, h:1.8, money:0, kills:0, deaths:0, primary:null, pistol:'glock', cur:'pistol', ammo:{}, spotT:-9 };
const bots=[], fighters=[me];
let reloading=false, reloadEnd=0, lastShotT=-9, bloom=0, aiming=false, fireHeld=false, switchT=0, kick=0, swing=0, scopedNow=false;

const botMats={};
function botMat(team){
    return botMats[team]||(botMats[team]={ body:L(team==='CT'?0x2f6df0:0xf2b705), trim:L(team==='CT'?0x1a3f99:0x8a6500), skin:L(0xd9a066), dark:L(0x1a1f27) });
}
function buildBotMesh(team){
    const M=botMat(team), grp=new THREE.Group(); grp.rotation.order='YXZ';
    const part=(geo,mat,x,y,z,parent)=>{ const m=new THREE.Mesh(geo,mat); m.position.set(x,y,z); m.castShadow=true; (parent||grp).add(m); return m; };
    part(new THREE.BoxGeometry(0.5,0.62,0.28),M.body,0,1.08,0);
    part(new THREE.BoxGeometry(0.46,0.22,0.26),M.trim,0,0.7,0);
    part(new THREE.SphereGeometry(0.19,10,8),M.skin,0,1.57,0);
    part(new THREE.BoxGeometry(0.42,0.17,0.4),M.trim,0,1.68,0);
    const legL=new THREE.Group(), legR=new THREE.Group();
    legL.position.set(-0.12,0.62,0); legR.position.set(0.12,0.62,0); grp.add(legL); grp.add(legR);
    part(new THREE.BoxGeometry(0.18,0.62,0.2),M.dark,0,-0.31,0,legL);
    part(new THREE.BoxGeometry(0.18,0.62,0.2),M.dark,0,-0.31,0,legR);
    const armR=new THREE.Group(), armL=new THREE.Group();
    armR.position.set(0.32,1.3,0); armL.position.set(-0.32,1.3,0); armR.rotation.x=-1.25; armL.rotation.x=-1.35; grp.add(armR); grp.add(armL);
    part(new THREE.BoxGeometry(0.13,0.5,0.15),M.body,0,-0.22,0,armR);
    part(new THREE.BoxGeometry(0.13,0.5,0.15),M.body,0,-0.22,0,armL);
    const gun=part(new THREE.BoxGeometry(0.07,0.09,0.6),M.dark,0.18,1.1,-0.4);
    return { grp, legL, legR, gun };
}
function makeBot(team,name){
    const m=buildBotMesh(team); scene.add(m.grp);
    const b={ isMe:false, name, team, pos:{x:0,y:0,z:0}, yaw:0, hp:100, armor:0, alive:true, h:1.8, weapon:'glock',
        grp:m.grp, legL:m.legL, legR:m.legR, gun:m.gun, target:null, loseT:0, react:0, fireCd:0, burst:0, pauseT:0,
        strafeDir:0, strafeT:0, scanT:Math.random()*0.2, path:null, pi:0, pathCd:0, searchPos:null, searchT:0,
        stuckT:0, stuckX:0, stuckZ:0, moving:false, walk:0, fall:0, spotT:-9, detourT:0, lastX:0, lastZ:0, kills:0, deaths:0 };
    bots.push(b); fighters.push(b); return b;
}
function removeBots(){
    bots.forEach(b=>scene.remove(b.grp));
    bots.length=0; fighters.length=1; fighters[0]=me;
}
function createBots(){
    removeBots();
    const names=BOT_NAMES.slice().sort(()=>Math.random()-0.5);
    ['CT','T'].forEach(team=>{
        const n = team===me.team ? lobby.size-1 : lobby.size;
        for(let i=0;i<n;i++) makeBot(team, names.pop());
    });
}
function pickBotWeapon(){
    if(round===1) return pick(['glock','p350','berettas','fiveseven','deagle']);
    const r=Math.random();
    if(diffKey==='easy')   return r<0.4?pick(['mp7','ump45']):(r<0.75?pick(['famas','p350','deagle']):pick(['ak47','m4a1']));
    if(diffKey==='normal') return r<0.2?pick(['mp7','ump45']):(r<0.88?pick(['ak47','m4a1','famas']):'awp');
    return r<0.1?pick(['mp7','ump45']):(r<0.8?pick(['ak47','m4a1']):(r<0.9?'famas':'awp'));
}

// ---------- лучи / видимость ----------
const shot={t:0,f:null,head:false};
function castShot(shooter,ox,oy,oz,dx,dy,dz,maxT){
    let best=maxT, hf=null, head=false;
    for(let i=0;i<colliders.length;i++){
        const c=colliders[i], t=C.rayAABB(ox,oy,oz,dx,dy,dz,c.minX,c.maxX,0,c.h,c.minZ,c.maxZ,best);
        if(t<best) best=t;
    }
    for(let i=0;i<fighters.length;i++){
        const f=fighters[i]; if(!f.alive||f.team===shooter.team) continue;
        const p=f.pos;
        const th=C.raySphere(ox,oy,oz,dx,dy,dz,p.x,p.y+f.h-0.2,p.z,0.22,best);
        const tb=C.rayCylV(ox,oy,oz,dx,dy,dz,p.x,p.z,0.38,p.y,p.y+f.h-0.4,best);
        if(th<best&&th<=tb){ best=th; hf=f; head=true; }
        else if(tb<best){ best=tb; hf=f; head=false; }
    }
    shot.t=best; shot.f=hf; shot.head=head; return shot;
}
function los(ox,oy,oz,tx,ty,tz){
    let dx=tx-ox,dy=ty-oy,dz=tz-oz; const d=Math.sqrt(dx*dx+dy*dy+dz*dz);
    if(d<1e-4) return true; dx/=d; dy/=d; dz/=d;
    for(let i=0;i<colliders.length;i++){ const c=colliders[i]; if(C.rayAABB(ox,oy,oz,dx,dy,dz,c.minX,c.maxX,0,c.h,c.minZ,c.maxZ,d)<d) return false; }
    return true;
}

// ---------- трассеры ----------
const tracers=[]; let trIdx=0;
for(let i=0;i<24;i++){
    const geo=new THREE.BufferGeometry(); geo.setAttribute('position',new THREE.BufferAttribute(new Float32Array(6),3));
    const ln=new THREE.Line(geo,new THREE.LineBasicMaterial({color:0xffd27a,transparent:true,opacity:1}));
    ln.visible=false; ln.frustumCulled=false; scene.add(ln); tracers.push({ln,life:0});
}
function spawnTracer(x0,y0,z0,x1,y1,z1,color){
    const t=tracers[(trIdx++)%tracers.length], a=t.ln.geometry.attributes.position.array;
    a[0]=x0;a[1]=y0;a[2]=z0;a[3]=x1;a[4]=y1;a[5]=z1;
    t.ln.geometry.attributes.position.needsUpdate=true; t.ln.material.color.setHex(color); t.ln.visible=true; t.life=0.09;
}

// ---------- урон / смерть ----------
const hitEl=$('hitmarker'), dmgEl=$('damage'), killFeed=$('kill-feed');
let hitTimer=0;
function flashHit(head){ hitEl.classList.toggle('head',!!head); hitEl.style.opacity='1'; clearTimeout(hitTimer); hitTimer=setTimeout(()=>hitEl.style.opacity='0',90); }
function damage(target,dmg,attacker,head,wname){
    if(!target.alive||phase!=='live') return;
    let hpD=dmg;
    if(target.armor>0){ hpD=dmg*0.65; target.armor=Math.max(0,target.armor-dmg*0.35); }
    target.hp-=hpD;
    if(attacker.isMe){ flashHit(head); sfxHit(head); }
    if(target.isMe){
        dmgEl.style.boxShadow='inset 0 0 110px rgba(255,0,0,.65)'; setTimeout(()=>dmgEl.style.boxShadow='inset 0 0 0 rgba(255,0,0,0)',140);
        updateHud();
    }
    if(target.hp<=0) kill(target,attacker,head,wname);
}
function kill(t,a,head,wname){
    t.alive=false; t.hp=0; t.deaths++; a.kills++;
    if(a.isMe) me.money=Math.min(16000,me.money+300);
    addKillFeed(a,t,head,wname);
    if(t.isMe){ $('death-note').classList.remove('hidden'); gunGroup.visible=false; aiming=false; fireHeld=false; scopedNow=false; $('scope').style.display='none'; $('crosshair').style.display='none'; sfxDie(); }
    else { t.fall=0; t.target=null; if(a.isMe||t.team!==me.team) sfxDie(); }
    updateHud(); updateScore();
    checkRoundEnd();
}
function addKillFeed(a,t,head,wname){
    const d=document.createElement('div'); d.className='kf';
    const ca=a.team==='CT'?'c':'y', ct=t.team==='CT'?'c':'y';
    d.innerHTML='<span class="'+ca+'">'+a.name+'</span> '+(head?'◎':'✖')+' <span class="'+ct+'">'+t.name+'</span>';
    killFeed.insertBefore(d,killFeed.firstChild);
    while(killFeed.children.length>5) killFeed.removeChild(killFeed.lastChild);
    setTimeout(()=>{ if(d.parentNode) d.parentNode.removeChild(d); },4500);
}
function noise(x,z,team){
    const D=DIFF[diffKey];
    for(let i=0;i<bots.length;i++){
        const b=bots[i]; if(!b.alive||b.team===team||b.target) continue;
        const dx=b.pos.x-x, dz=b.pos.z-z;
        if(dx*dx+dz*dz<900 && Math.random()<D.hear){ b.searchPos={x:x,z:z}; b.searchT=6; b.path=null; }
    }
}

// ============================================================
//  БОТЫ: ИИ
// ============================================================
const mv={x:0,z:0}, goalTmp={x:0,z:0};
function pathDir(b){
    while(b.path && b.pi<b.path.length){
        const w=b.path[b.pi], dx=w.x-b.pos.x, dz=w.z-b.pos.z, d=Math.hypot(dx,dz);
        if(d<0.5){ b.pi++; continue; }
        mv.x=dx/d; mv.z=dz/d; return true;
    }
    return false;
}
function patrolGoal(b){
    const ez=b.team==='CT'?-1:1;
    for(let k=0;k<6;k++){
        C.cellCenter(nav, nav.free[(Math.random()*nav.free.length)|0], goalTmp);
        if(goalTmp.z*ez>0 || Math.random()<0.3) break;
    }
    return goalTmp;
}
function scanBot(b,D){
    const ex=b.pos.x, ey=b.pos.y+1.55, ez=b.pos.z;
    const fx=-Math.sin(b.yaw), fz=-Math.cos(b.yaw), cosV=Math.cos(D.view*Math.PI/180);
    let best=null, bd=1e9;
    for(let i=0;i<fighters.length;i++){
        const f=fighters[i]; if(!f.alive||f.team===b.team) continue;
        const dx=f.pos.x-ex, dz=f.pos.z-ez, d2=dx*dx+dz*dz;
        if(d2>2500||d2>=bd) continue;
        const d=Math.sqrt(d2);
        if(f!==b.target && d>3 && (dx*fx+dz*fz)/d<cosV) continue;
        if(!los(ex,ey,ez,f.pos.x,f.pos.y+f.h*0.7,f.pos.z)) continue;
        best=f; bd=d2;
    }
    if(best){
        if(best!==b.target){ b.target=best; b.react=D.react*rnd(0.8,1.2); b.burst=0; b.pauseT=0; b.path=null; b.detourT=0; }
        b.loseT=0; b.lastX=best.pos.x; b.lastZ=best.pos.z; best.spotT=gt;
    } else if(b.target){
        b.loseT+=0.2;
        if(b.loseT>0.8){ b.searchPos={x:b.lastX,z:b.lastZ}; b.searchT=6; b.target=null; b.path=null; }
    }
}
function botShoot(b,t){
    const W=WEAPONS[b.weapon], D=DIFF[diffKey];
    const ox=b.pos.x, oy=b.pos.y+1.5, oz=b.pos.z;
    const aimY=t.pos.y+t.h*(Math.random()<D.head?0.93:0.62);
    let dx=t.pos.x-ox, dy=aimY-oy, dz=t.pos.z-oz;
    const len=Math.sqrt(dx*dx+dy*dy+dz*dz); dx/=len; dy/=len; dz/=len;
    const err=D.err*(1+len*0.02)*(b.moving?1.5:1)*(W.cat==='sniper'?0.5:(W.cat==='smg'?1.2:1));
    dx+=(Math.random()*2-1)*err; dy+=(Math.random()*2-1)*err; dz+=(Math.random()*2-1)*err;
    const l2=Math.sqrt(dx*dx+dy*dy+dz*dz); dx/=l2; dy/=l2; dz/=l2;
    castShot(b,ox,oy,oz,dx,dy,dz,80);
    const end=Math.min(shot.t,80);
    spawnTracer(ox+dx*0.6,oy-0.25,oz+dz*0.6, ox+dx*end,oy+dy*end,oz+dz*end, b.team==='CT'?0x7fb2ff:0xffe08a);
    const f=shot.f, hd=shot.head;
    if(f) damage(f, W.dmg*D.dmg*(hd?2:1), b, hd, W.name);
    const dm=Math.hypot(b.pos.x-me.pos.x,b.pos.z-me.pos.z);
    sfxShot(W.snd, clamp(1-dm/45,0,1)*0.8);
    noise(b.pos.x,b.pos.z,b.team);
}
function updateBot(b,dt){
    const D=DIFF[diffKey];
    if(!b.alive){
        if(b.fall<1){ b.fall=Math.min(1,b.fall+dt*3); b.grp.rotation.x=-1.45*b.fall; b.grp.position.y=0.12*b.fall; }
        return;
    }
    b.grp.position.set(b.pos.x,b.pos.y,b.pos.z); b.grp.rotation.y=b.yaw;
    if(phase!=='live') return;
    b.scanT-=dt; if(b.scanT<=0){ b.scanT=rnd(0.16,0.26); scanBot(b,D); }
    const W=WEAPONS[b.weapon];
    let mvx=0, mvz=0;
    if(b.target && !b.target.alive) b.target=null;
    if(b.target){
        const t=b.target, dx=t.pos.x-b.pos.x, dz=t.pos.z-b.pos.z, dist=Math.hypot(dx,dz);
        const ad=angDiff(b.yaw,Math.atan2(-dx,-dz));
        b.yaw+=clamp(ad,-D.turn*dt,D.turn*dt);
        const rng=W.cat==='sniper'?26:(W.cat==='rifle'?16:(W.cat==='smg'?9:11));
        if(b.detourT>0){
            b.detourT-=dt;
            if(pathDir(b)){ mvx=mv.x; mvz=mv.z; }
        } else {
            const fwd=dist>rng+3?1:(dist<rng-4?-0.7:0);
            b.strafeT-=dt;
            if(b.strafeT<=0){ b.strafeT=rnd(0.5,1.5); b.strafeDir=Math.random()<D.strafe?(Math.random()<0.5?-1:1):0; }
            const fx=-Math.sin(b.yaw), fz=-Math.cos(b.yaw), rx=Math.cos(b.yaw), rz=-Math.sin(b.yaw);
            mvx=fx*fwd+rx*b.strafeDir*0.9; mvz=fz*fwd+rz*b.strafeDir*0.9;
        }
        if(b.react>0) b.react-=dt;
        else if(Math.abs(ad)<0.3){
            if(b.burst<=0){
                b.pauseT-=dt;
                if(b.pauseT<=0){
                    b.burst=(W.cat==='sniper'||(!W.auto&&W.cat!=='pistol'))?1:((rnd(D.burst[0],D.burst[1]+1))|0);
                    b.pauseT=rnd(D.pause[0],D.pause[1]);
                }
            } else {
                b.fireCd-=dt;
                if(b.fireCd<=0){ botShoot(b,t); b.burst--; b.fireCd=60/(W.rpm*D.fireMul)*(W.auto?1:1.25); }
            }
        }
    } else {
        if(b.searchPos){ b.searchT-=dt; if(b.searchT<=0) b.searchPos=null; }
        if(!b.path || b.pi>=b.path.length){
            b.path=null; b.pathCd-=dt;
            if(b.pathCd<=0){
                b.pathCd=0.35;
                let gx,gz;
                if(b.searchPos){ gx=b.searchPos.x; gz=b.searchPos.z; } else { const g=patrolGoal(b); gx=g.x; gz=g.z; }
                const p=C.findPath(nav,b.pos.x,b.pos.z,gx,gz);
                if(p){ b.path=p; b.pi=0; }
                if(b.searchPos && (!p || Math.hypot(gx-b.pos.x,gz-b.pos.z)<2)) b.searchPos=null;
            }
        }
        if(pathDir(b)){
            mvx=mv.x; mvz=mv.z;
            const ad=angDiff(b.yaw,Math.atan2(-mvx,-mvz));
            b.yaw+=clamp(ad,-D.turn*dt,D.turn*dt);
        }
    }
    // движение
    const ml=Math.hypot(mvx,mvz);
    if(ml>0.01){
        const sp=D.speed*W.speed*Math.min(1,ml)*dt;
        b.pos.x+=mvx/ml*sp; b.pos.z+=mvz/ml*sp;
        C.resolveCollisions(b.pos,0.42,colliders);
        b.moving=true; b.walk+=sp*3.2;
    } else b.moving=false;
    // отталкивание
    for(let i=0;i<fighters.length;i++){
        const o=fighters[i]; if(o===b||!o.alive) continue;
        const dx=b.pos.x-o.pos.x, dz=b.pos.z-o.pos.z, d2=dx*dx+dz*dz;
        if(d2<0.64&&d2>1e-6){ const d=Math.sqrt(d2), push=(0.8-d)*0.5; b.pos.x+=dx/d*push; b.pos.z+=dz/d*push; }
    }
    // застревание
    b.stuckT+=dt;
    if(b.stuckT>=0.8){
        const moved=Math.hypot(b.pos.x-b.stuckX,b.pos.z-b.stuckZ);
        if(b.moving && moved<0.25){
            if(b.target){ b.path=C.findPath(nav,b.pos.x,b.pos.z,b.target.pos.x,b.target.pos.z); b.pi=0; b.detourT=b.path?1.6:0; b.strafeDir*=-1; }
            else b.path=null;
        }
        b.stuckT=0; b.stuckX=b.pos.x; b.stuckZ=b.pos.z;
    }
    const sw=b.moving?Math.sin(b.walk)*0.75:0;
    b.legL.rotation.x=sw; b.legR.rotation.x=-sw;
    b.grp.position.set(b.pos.x,b.pos.y,b.pos.z); b.grp.rotation.y=b.yaw;
}

// ============================================================
//  ИГРОК: оружие / стрельба
// ============================================================
const curId=()=>me.cur==='primary'&&me.primary?me.primary:(me.cur==='knife'?'knife':me.pistol);
const ammoCurEl=$('ammo-cur'), ammoResEl=$('ammo-res');
function giveWeapon(id){
    const W=WEAPONS[id]; me.ammo[id]={mag:W.mag,reserve:W.reserve};
    if(W.cat==='pistol'){ me.pistol=id; me.cur='pistol'; } else { me.primary=id; me.cur='primary'; }
    reloading=false; buildGun(curId()); switchT=0.25; updateWeaponBar(); updateHud();
}
function selectSlot(slot){
    if(!me.alive) return;
    if(slot==='primary'&&!me.primary) return;
    me.cur=slot; reloading=false; aiming=false; $('btn-aim').classList.remove('active');
    buildGun(curId()); switchT=0.25; updateWeaponBar(); updateHud();
}
function startReload(){
    const id=curId(), W=WEAPONS[id]; if(W.cat==='knife'||!me.alive||reloading) return;
    const st=me.ammo[id]; if(st.mag>=W.mag||st.reserve<=0) return;
    reloading=true; reloadEnd=gt+W.reload/1000; $('btn-reload').classList.add('active');
}
function finishReload(){
    const id=curId(), W=WEAPONS[id], st=me.ammo[id];
    const take=Math.min(W.mag-st.mag,st.reserve); st.mag+=take; st.reserve-=take;
    reloading=false; $('btn-reload').classList.remove('active'); updateHud();
}
function knifeAttack(){
    if(gt-lastShotT<0.46) return; lastShotT=gt; swing=1; sfxKnife();
    const fx=-Math.sin(me.yaw), fz=-Math.cos(me.yaw);
    for(let i=0;i<fighters.length;i++){
        const f=fighters[i]; if(!f.alive||f.team===me.team) continue;
        const dx=f.pos.x-me.pos.x, dz=f.pos.z-me.pos.z, d=Math.hypot(dx,dz);
        if(d<2.2&&(dx*fx+dz*fz)/Math.max(d,0.01)>0.5){ damage(f,WEAPONS.knife.dmg,me,false,'Нож'); break; }
    }
}
function playerShoot(){
    if(!me.alive||phase!=='live'||editMode||paused) return;
    const id=curId(), W=WEAPONS[id];
    if(W.cat==='knife') return knifeAttack();
    if(reloading||gt-lastShotT<60/W.rpm) return;
    const st=me.ammo[id];
    if(st.mag<=0){ startReload(); return; }
    lastShotT=gt; st.mag--;
    const mvs=Math.min(1,Math.hypot(me.vel.x,me.vel.z)/5);
    let sp=(W.spread+bloom*0.02+mvs*0.02+(me.onGround?0:0.03))*(aiming?(W.scoped?0.15:0.45):1)*(me.crouch?0.7:1);
    if(W.scoped&&!aiming) sp+=0.06;
    const cp=Math.cos(me.pitch);
    let dx=-Math.sin(me.yaw)*cp, dy=Math.sin(me.pitch), dz=-Math.cos(me.yaw)*cp;
    dx+=(Math.random()*2-1)*sp; dy+=(Math.random()*2-1)*sp; dz+=(Math.random()*2-1)*sp;
    const l=Math.sqrt(dx*dx+dy*dy+dz*dz); dx/=l; dy/=l; dz/=l;
    const ox=me.pos.x, oy=me.pos.y+me.eyeH, oz=me.pos.z;
    castShot(me,ox,oy,oz,dx,dy,dz,100);
    const end=Math.min(shot.t,80);
    if(!scopedNow) spawnTracer(ox+dx*0.5+Math.cos(me.yaw)*0.18,oy-0.15,oz+dz*0.5-Math.sin(me.yaw)*0.18, ox+dx*end,oy+dy*end,oz+dz*end, 0xffd27a);
    if(shot.f) damage(shot.f,W.dmg*(shot.head?2:1),me,shot.head,W.name);
    sfxShot(W.snd,1); noise(me.pos.x,me.pos.z,me.team);
    me.pitch+=W.recoil*(aiming?0.6:1); me.yaw+=(Math.random()*2-1)*W.recoil*0.4;
    bloom=Math.min(1,bloom+(W.scoped?0.6:0.25)); kick=1; flash.visible=true; flashT=0.04;
    updateHud();
    if(st.mag<=0) startReload();
}

// ============================================================
//  HUD
// ============================================================
const hpEl=$('hp-val'), arEl=$('armor-val'), hpBar=$('hp-bar'), arBar=$('armor-bar');
function updateHud(){
    setText(hpEl,Math.ceil(me.hp)); setText(arEl,Math.ceil(me.armor));
    hpBar.style.width=clamp(me.hp,0,100)+'%'; arBar.style.width=clamp(me.armor,0,100)+'%';
    const id=curId(), W=WEAPONS[id], st=me.ammo[id];
    setText($('weapon-name'),W.name);
    if(W.cat==='knife'){ setText(ammoCurEl,'∞'); setText(ammoResEl,'—'); }
    else { setText(ammoCurEl,st.mag); setText(ammoResEl,st.reserve); ammoCurEl.style.color=st.mag===0?'#ef4444':(st.mag<=5?'#ff8c00':'#fff'); }
    setText($('money-val'),me.money); setText($('shop-money'),me.money);
}
function updateWeaponBar(){
    const p=$('ws-primary'); p.textContent=me.primary?WEAPONS[me.primary].name:'—'; p.disabled=!me.primary;
    $('ws-pistol').textContent=WEAPONS[me.pistol].name;
    ['primary','pistol','knife'].forEach(s=>$('ws-'+s).classList.toggle('on',me.cur===s||(s==='primary'&&me.cur==='primary')));
}
function updateScore(){
    setText($('score-ct'),scoreCT); setText($('score-t'),scoreT);
    let a=0,b=0; fighters.forEach(f=>{ if(f.alive){ if(f.team==='CT') a++; else b++; } });
    setText($('alive-ct'),a+' жив.'); setText($('alive-t'),b+' жив.');
}
const msgEl=$('center-msg');
function showMsg(html){ msgEl.innerHTML=html; msgEl.style.display='block'; }
function hideMsg(){ msgEl.style.display='none'; }

// ============================================================
//  РАУНДЫ
// ============================================================
const SPAWN_ORDER=[2,1,3,0,4];
function resetRound(){
    const sp=curMap.spawns, idx={CT:0,T:0};
    fighters.forEach(f=>{
        const list=sp[f.team], s=list[SPAWN_ORDER[idx[f.team]++ % list.length]];
        f.pos.x=s[0]; f.pos.z=s[1]; f.pos.y=0; f.hp=100; f.alive=true;
        const yaw=f.team==='CT'?0:Math.PI;
        if(f.isMe){
            if(!me.alive){ me.primary=null; me.pistol='glock'; me.armor=0; }
            me.yaw=yaw; me.pitch=0; me.vel.x=me.vel.y=me.vel.z=0; me.crouch=false; me.eyeH=1.7; me.h=1.8; me.onGround=true;
            if(!me.primary) me.cur='pistol';
            [me.primary,me.pistol].forEach(id=>{ if(id){ me.ammo[id]={mag:WEAPONS[id].mag,reserve:WEAPONS[id].reserve}; } });
            gunGroup.visible=true; $('crosshair').style.display='block'; $('death-note').classList.add('hidden');
            reloading=false; aiming=false; fireHeld=false; bloom=0; $('btn-reload').classList.remove('active'); $('btn-aim').classList.remove('active'); $('btn-crouch').classList.remove('active');
            buildGun(curId()); updateWeaponBar();
        } else {
            f.yaw=yaw; f.target=null; f.path=null; f.searchPos=null; f.react=0; f.burst=0; f.pauseT=0; f.fireCd=0; f.detourT=0; f.fall=0; f.moving=false;
            f.weapon=pickBotWeapon();
            f.armor=(round>1&&(diffKey==='expert'||(diffKey==='normal'&&Math.random()<0.5)))?100:0;
            f.grp.rotation.x=0; f.grp.position.set(f.pos.x,0,f.pos.z); f.grp.rotation.y=yaw;
            f.gun.scale.z=WEAPONS[f.weapon].cat==='pistol'?0.5:(WEAPONS[f.weapon].cat==='sniper'?1.3:1);
        }
    });
    me.spotT=-9;
}
function nextRound(){
    round++; resetRound();
    phase='freeze'; phaseT=lobby.freeze; roundT=ROUND_TIME; roundElapsed=0; lastCount=-1;
    $('death-note').classList.add('hidden');
    updateHud(); updateScore(); setText($('round-no'),'Раунд '+round);
}
function checkRoundEnd(){
    if(phase!=='live') return;
    let a=0,b=0; fighters.forEach(f=>{ if(f.alive){ if(f.team==='CT') a++; else b++; } });
    if(a===0) endRound('T'); else if(b===0) endRound('CT');
}
function endRound(w){
    phase='roundEnd'; phaseT=4;
    if(w==='CT') scoreCT++; else scoreT++;
    const won=w===me.team;
    me.money=Math.min(16000,me.money+(won?3000:2000));
    showMsg('<span style="color:'+(won?'#4ade80':'#f87171')+'">'+(won?'РАУНД ВЫИГРАН':'РАУНД ПРОИГРАН')+'</span><small>'+(w==='CT'?'Синие':'Жёлтые')+' побеждают · +$'+(won?3000:2000)+'</small>');
    updateScore(); updateHud();
}
function updatePhase(dt){
    if(phase==='freeze'){
        phaseT-=dt;
        const n=Math.max(1,Math.ceil(phaseT));
        if(n!==lastCount){ lastCount=n; showMsg('<div class="num">'+n+'</div><small>РАУНД '+round+' · ЗАКУПКА · выход из респауна закрыт</small>'); }
        if(phaseT<=0){ phase='live'; roundElapsed=0; showMsg('ВПЕРЁД!'); msgT=1.1; }
    } else if(phase==='live'){
        roundElapsed+=dt; roundT-=dt;
        if(msgT>0){ msgT-=dt; if(msgT<=0) hideMsg(); }
        if(roundT<=0){
            let a=0,b=0; fighters.forEach(f=>{ if(f.alive){ if(f.team==='CT') a++; else b++; } });
            endRound(b>a?'T':'CT');
        }
    } else if(phase==='roundEnd'){
        phaseT-=dt;
        if(phaseT<=0){
            if(scoreCT>=WIN_ROUNDS||scoreT>=WIN_ROUNDS) endMatch(); else nextRound();
        }
    }
    const t=Math.max(0,Math.ceil(roundT)), cl=$('round-clock');
    setText(cl,Math.floor(t/60)+':'+(t%60<10?'0':'')+(t%60));
    $('btn-shop').classList.toggle('pulse',phase==='freeze'&&me.alive);
}
function endMatch(){
    phase='matchEnd'; hideMsg();
    const win=(me.team==='CT'?scoreCT:scoreT)>=WIN_ROUNDS;
    $('match-title').innerHTML='<span style="color:'+(win?'#4ade80':'#f87171')+'">'+(win?'ПОБЕДА':'ПОРАЖЕНИЕ')+'</span>';
    $('match-score').textContent='CT '+scoreCT+' : '+scoreT+' T';
    $('match-end').classList.remove('hidden');
}

// ---------- старт / выход ----------
function startMatch(){
    audio();
    diffKey=lobby.diff; me.team=lobby.team;
    loadMap(MAPS[lobby.map]);
    createBots();
    scoreCT=scoreT=0; round=0; me.money=2500; me.kills=me.deaths=0; me.alive=true; me.armor=0; me.primary=null; me.pistol='glock'; me.cur='pistol'; me.ammo={};
    me.ammo.glock={mag:WEAPONS.glock.mag,reserve:WEAPONS.glock.reserve};
    $('lobby').classList.add('hidden'); $('game').classList.remove('hidden'); $('match-end').classList.add('hidden');
    killFeed.innerHTML='';
    onResize(); applyGraphics();
    running=true; paused=false; gt=0;
    nextRound();
}
function exitToLobby(){
    running=false; paused=false; phase='lobby'; hideMsg(); closeShop();
    removeBots(); $('settings').classList.add('hidden');
    $('game').classList.add('hidden'); $('lobby').classList.remove('hidden');
    if(document.exitPointerLock) document.exitPointerLock();
}

// ============================================================
//  МАГАЗИН
// ============================================================
let shopTab='pistol';
const shopEl=$('shop');
function canBuy(){ return me.alive && (phase==='freeze' || (phase==='live' && roundElapsed<BUY_EXTRA)); }
function owned(id){ return me.primary===id||me.pistol===id; }
function renderShop(){
    const tabs=$('shop-tabs'); tabs.innerHTML='';
    SHOP_TABS.forEach(t=>{ const b=document.createElement('button'); b.textContent=t[1]; if(t[0]===shopTab) b.className='on'; b.onclick=()=>{ shopTab=t[0]; renderShop(); }; tabs.appendChild(b); });
    const list=$('shop-list'); list.innerHTML='';
    const ok=canBuy();
    const note=$('shop-note');
    note.textContent = phase==='freeze' ? 'Закупка открыта' : (ok ? 'Закупка закроется через '+Math.ceil(BUY_EXTRA-roundElapsed)+' с' : 'Закупка закрыта — доступна в начале раунда');
    if(shopTab==='gear'){
        const c=document.createElement('div'); c.className='card'+(me.armor>=100?' own':'');
        c.innerHTML='<h4>Бронежилет</h4><div class="st"><span>Броня</span><i style="width:100%"></i></div>';
        const b=document.createElement('button'); b.className='btn small';
        b.textContent=me.armor>=100?'Куплено':'$'+ARMOR_PRICE; b.disabled=!ok||me.armor>=100||me.money<ARMOR_PRICE;
        b.onclick=()=>{ if(!canBuy()||me.money<ARMOR_PRICE) return; me.money-=ARMOR_PRICE; me.armor=100; sfxBuy(); updateHud(); renderShop(); };
        c.appendChild(b); list.appendChild(c); return;
    }
    Object.keys(WEAPONS).forEach(id=>{
        const W=WEAPONS[id]; if(W.cat!==shopTab) return;
        const has=owned(id), c=document.createElement('div'); c.className='card'+(has?' own':'');
        c.innerHTML='<h4>'+W.name+'</h4><div class="st"><span>Урон</span><i style="width:'+Math.min(100,W.dmg/1.15)+'%"></i><span>Скорость</span><i style="width:'+Math.min(100,W.rpm/9)+'%"></i><span>Магазин</span><i style="width:'+Math.min(100,W.mag*3)+'%"></i></div>';
        const b=document.createElement('button'); b.className='btn small';
        b.textContent=has?'Куплено':(W.price?'$'+W.price:'Бесплатно');
        b.disabled=!ok||has||me.money<W.price;
        b.onclick=()=>{ if(!canBuy()||me.money<W.price) return; me.money-=W.price; giveWeapon(id); sfxBuy(); renderShop(); };
        c.appendChild(b); list.appendChild(c);
    });
}
function openShop(){ renderShop(); updateHud(); shopEl.classList.remove('hidden'); }
function closeShop(){ shopEl.classList.add('hidden'); }
$('btn-shop').addEventListener('click',()=>{ audio(); shopEl.classList.contains('hidden')?openShop():closeShop(); });
$('shop-close').addEventListener('click',closeShop);

// ============================================================
//  ГРАФИКА / НАСТРОЙКИ
// ============================================================
let effScale=S.scale;
function setRes(){ renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2)*effScale); }
function applyLayout(){
    LAYOUT_IDS.forEach(id=>{ const el=$(id), l=layout[id]; el.style.left=(l.x*100)+'%'; el.style.top=(l.y*100)+'%'; el.style.setProperty('--s',(l.s*S.btnScale).toFixed(3)); });
}
function applyGraphics(){
    effScale=S.scale;
    renderer.shadowMap.enabled=S.shadows; sun.castShadow=S.shadows;
    const ms=S.preset==='ultra'?2048:1024;
    if(sun.shadow.mapSize.x!==ms){ sun.shadow.mapSize.set(ms,ms); if(sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map=null; } }
    scene.traverse(o=>{ if(o.material) (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{ m.needsUpdate=true; }); });
    if(scene.fog){ scene.fog.far=S.dist; scene.fog.near=Math.min(20,S.dist*0.3); }
    camera.far=S.dist+15; camera.updateProjectionMatrix();
    setRes();
    $('fps-box').style.display=S.showFps?'block':'none';
    const st=document.documentElement.style;
    st.setProperty('--ch',S.chColor); st.setProperty('--chs',S.chSize); st.setProperty('--hs',S.hudScale); st.setProperty('--bop',S.btnOp);
    applyLayout();
}
const setIn={ scale:$('set-scale'), fps:$('set-fps'), shadows:$('set-shadows'), auto:$('set-auto'), showfps:$('set-showfps'),
    sens:$('set-sens'), btnscale:$('set-btnscale'), btnop:$('set-btnop'), hudscale:$('set-hudscale'), chsize:$('set-chsize') };
function syncSettingsUI(){
    setIn.scale.value=S.scale; setIn.fps.value=String(S.fpsCap); setIn.shadows.checked=S.shadows; setIn.auto.checked=S.auto; setIn.showfps.checked=S.showFps;
    setIn.sens.value=S.sens; setIn.btnscale.value=S.btnScale; setIn.btnop.value=S.btnOp; setIn.hudscale.value=S.hudScale; setIn.chsize.value=S.chSize;
    $('scale-val').textContent=Math.round(S.scale*100)+'%'; $('sens-val').textContent=S.sens.toFixed(1);
    $('btnscale-val').textContent=Math.round(S.btnScale*100)+'%'; $('hudscale-val').textContent=Math.round(S.hudScale*100)+'%';
    document.querySelectorAll('#preset-seg button').forEach(b=>b.classList.toggle('on',b.dataset.v===S.preset));
    document.querySelectorAll('#ch-colors button').forEach(b=>b.classList.toggle('on',b.dataset.c===S.chColor));
}
function changed(custom){ if(custom) S.preset='custom'; saveSettings(); syncSettingsUI(); applyGraphics(); }
setIn.scale.addEventListener('input',()=>{ S.scale=parseFloat(setIn.scale.value); changed(true); });
setIn.fps.addEventListener('change',()=>{ S.fpsCap=parseInt(setIn.fps.value,10); changed(true); });
setIn.shadows.addEventListener('change',()=>{ S.shadows=setIn.shadows.checked; changed(true); });
setIn.auto.addEventListener('change',()=>{ S.auto=setIn.auto.checked; changed(false); });
setIn.showfps.addEventListener('change',()=>{ S.showFps=setIn.showfps.checked; changed(false); });
setIn.sens.addEventListener('input',()=>{ S.sens=parseFloat(setIn.sens.value); changed(false); });
setIn.btnscale.addEventListener('input',()=>{ S.btnScale=parseFloat(setIn.btnscale.value); changed(false); });
setIn.btnop.addEventListener('input',()=>{ S.btnOp=parseFloat(setIn.btnop.value); changed(false); });
setIn.hudscale.addEventListener('input',()=>{ S.hudScale=parseFloat(setIn.hudscale.value); changed(false); });
setIn.chsize.addEventListener('input',()=>{ S.chSize=parseFloat(setIn.chsize.value); changed(false); });
document.querySelectorAll('#preset-seg button').forEach(b=>b.addEventListener('click',()=>{ Object.assign(S,PRESETS[b.dataset.v],{preset:b.dataset.v}); changed(false); }));
['#34d399','#ffffff','#ef4444','#facc15','#38bdf8','#e879f9'].forEach(c=>{
    const b=document.createElement('button'); b.style.background=c; b.dataset.c=c;
    b.addEventListener('click',()=>{ S.chColor=c; changed(false); }); $('ch-colors').appendChild(b);
});
function openSettings(){
    syncSettingsUI();
    const inGame=running;
    $('sec-game').style.display=inGame?'block':'none'; $('btn-quit').style.display=inGame?'block':'none';
    $('settings').classList.remove('hidden'); if(inGame) paused=true;
    if(document.exitPointerLock) document.exitPointerLock();
}
function closeSettings(){ $('settings').classList.add('hidden'); if(!editMode) paused=false; }
$('btn-settings').addEventListener('click',openSettings);
$('btn-lobby-settings').addEventListener('click',openSettings);
$('settings-close').addEventListener('click',closeSettings);
$('btn-quit').addEventListener('click',exitToLobby);
$('btn-to-lobby').addEventListener('click',exitToLobby);

// ---------- редактор раскладки ----------
let selId='btn-fire', dragInfo=null, editFromLobby=false;
function enterEdit(){
    $('settings').classList.add('hidden');
    editFromLobby=!running; editMode=true; paused=true;
    if(editFromLobby){ $('lobby').classList.add('hidden'); $('game').classList.remove('hidden'); }
    $('game').classList.add('editing'); $('edit-bar').classList.remove('hidden'); $('edit-size').value=layout[selId].s;
    LAYOUT_IDS.forEach(id=>$(id).classList.toggle('sel',id===selId));
    applyLayout();
}
function leaveEdit(){
    editMode=false; paused=false; lsSet('so3d_layout',layout);
    $('game').classList.remove('editing'); $('edit-bar').classList.add('hidden');
    LAYOUT_IDS.forEach(id=>$(id).classList.remove('sel'));
    if(editFromLobby){ $('game').classList.add('hidden'); $('lobby').classList.remove('hidden'); paused=false; }
}
$('btn-edit-layout').addEventListener('click',enterEdit);
$('edit-done').addEventListener('click',leaveEdit);
$('edit-reset').addEventListener('click',()=>{ LAYOUT_IDS.forEach(id=>layout[id]=Object.assign({},DEF_LAYOUT[id])); applyLayout(); lsSet('so3d_layout',layout); });
$('edit-size').addEventListener('input',()=>{ layout[selId].s=parseFloat($('edit-size').value); applyLayout(); });
LAYOUT_IDS.forEach(id=>{
    const el=$(id);
    el.addEventListener('pointerdown',e=>{
        if(!editMode) return;
        e.preventDefault(); e.stopImmediatePropagation();
        dragInfo={id:id,pid:e.pointerId}; selId=id; el.setPointerCapture(e.pointerId);
        $('edit-size').value=layout[id].s; LAYOUT_IDS.forEach(i=>$(i).classList.toggle('sel',i===id));
    },true);
    el.addEventListener('pointermove',e=>{
        if(!editMode||!dragInfo||dragInfo.pid!==e.pointerId) return;
        e.stopImmediatePropagation();
        layout[id].x=clamp(e.clientX/innerWidth,0.04,0.96); layout[id].y=clamp(e.clientY/innerHeight,0.06,0.94); applyLayout();
    },true);
    el.addEventListener('pointerup',e=>{ if(editMode&&dragInfo){ dragInfo=null; lsSet('so3d_layout',layout); } },true);
});

// ============================================================
//  ВВОД
// ============================================================
const keys={};
function toggleCrouch(){ me.crouch=!me.crouch; $('btn-crouch').classList.toggle('active',me.crouch); }
function lookBy(dx,dy,base){
    const W=WEAPONS[curId()], m=aiming?(W.scoped?0.35:0.6):1;
    me.yaw-=dx*base*S.sens*m; me.pitch=clamp(me.pitch-dy*base*S.sens*m,-1.45,1.45);
}
addEventListener('keydown',e=>{
    if(!running||editMode) return; keys[e.code]=true;
    if(e.code==='KeyR') startReload(); else if(e.code==='KeyC') toggleCrouch();
    else if(e.code==='Digit1') selectSlot('primary'); else if(e.code==='Digit2') selectSlot('pistol'); else if(e.code==='Digit3') selectSlot('knife');
    else if(e.code==='KeyB') shopEl.classList.contains('hidden')?openShop():closeShop();
});
addEventListener('keyup',e=>{ keys[e.code]=false; });
document.querySelectorAll('.wslot').forEach(b=>b.addEventListener('pointerdown',e=>{ e.preventDefault(); selectSlot(b.dataset.slot); }));

// мышь (десктоп)
const glc=renderer.domElement;
addEventListener('mousemove',e=>{ if(running&&document.pointerLockElement===glc&&!paused) lookBy(e.movementX,e.movementY,0.0022); });
addEventListener('mousedown',e=>{ if(!running||document.pointerLockElement!==glc) return; if(e.button===0){ fireHeld=true; playerShoot(); } if(e.button===2) aiming=true; });
addEventListener('mouseup',e=>{ if(e.button===0) fireHeld=false; if(e.button===2) aiming=false; });
addEventListener('contextmenu',e=>e.preventDefault());

// зона обзора (тач)
const lookEl=$('look'); let lookId=null, lx=0, ly=0;
lookEl.addEventListener('pointerdown',e=>{
    audio();
    if(e.pointerType==='mouse'){ if(document.pointerLockElement!==glc && glc.requestPointerLock) glc.requestPointerLock(); return; }
    if(lookId!==null||editMode) return;
    lookId=e.pointerId; lx=e.clientX; ly=e.clientY; lookEl.setPointerCapture(e.pointerId);
});
lookEl.addEventListener('pointermove',e=>{ if(e.pointerId!==lookId||paused) return; lookBy(e.clientX-lx,e.clientY-ly,0.0042); lx=e.clientX; ly=e.clientY; });
const lookEnd=e=>{ if(e.pointerId===lookId) lookId=null; };
lookEl.addEventListener('pointerup',lookEnd); lookEl.addEventListener('pointercancel',lookEnd);

// джойстик (фиксированный)
const joy={x:0,y:0,id:null}, joyEl=$('joy'), stickEl=$('stick');
function joyMove(e){
    const r=joyEl.getBoundingClientRect(), sc=r.width/128, R=r.width/2*0.6;
    let dx=e.clientX-(r.left+r.width/2), dy=e.clientY-(r.top+r.height/2);
    const len=Math.hypot(dx,dy); if(len>R){ dx=dx/len*R; dy=dy/len*R; }
    stickEl.style.transform='translate('+(dx/sc)+'px,'+(dy/sc)+'px)'; joy.x=dx/R; joy.y=dy/R;
}
joyEl.addEventListener('pointerdown',e=>{ e.preventDefault(); audio(); joy.id=e.pointerId; joyEl.setPointerCapture(e.pointerId); joyMove(e); });
joyEl.addEventListener('pointermove',e=>{ if(e.pointerId===joy.id) joyMove(e); });
const joyEnd=e=>{ if(e.pointerId!==joy.id) return; joy.id=null; joy.x=joy.y=0; stickEl.style.transform='translate(0,0)'; };
joyEl.addEventListener('pointerup',joyEnd); joyEl.addEventListener('pointercancel',joyEnd);

// кнопка огня: кнопка неподвижна, но палец на ней вращает камеру
const fireEl=$('btn-fire'); let fireId=null, fpx=0, fpy=0;
fireEl.addEventListener('pointerdown',e=>{ e.preventDefault(); audio(); fireEl.setPointerCapture(e.pointerId); fireId=e.pointerId; fpx=e.clientX; fpy=e.clientY; fireHeld=true; fireEl.classList.add('down'); playerShoot(); });
fireEl.addEventListener('pointermove',e=>{ if(e.pointerId!==fireId||paused) return; lookBy(e.clientX-fpx,e.clientY-fpy,0.0042); fpx=e.clientX; fpy=e.clientY; });
const fireEnd=e=>{ if(e.pointerId!==fireId) return; fireId=null; fireHeld=false; fireEl.classList.remove('down'); };
fireEl.addEventListener('pointerup',fireEnd); fireEl.addEventListener('pointercancel',fireEnd); fireEl.addEventListener('lostpointercapture',fireEnd);

function tapBtn(id,fn,up){
    const el=$(id);
    el.addEventListener('pointerdown',e=>{ e.preventDefault(); audio(); el.setPointerCapture(e.pointerId); fn(); });
    if(up){ el.addEventListener('pointerup',up); el.addEventListener('pointercancel',up); }
}
tapBtn('btn-jump',()=>{ keys.Space=true; },()=>{ keys.Space=false; });
tapBtn('btn-aim',()=>{ aiming=!aiming; $('btn-aim').classList.toggle('active',aiming); });
tapBtn('btn-crouch',toggleCrouch);
tapBtn('btn-reload',startReload);

// ============================================================
//  ОБНОВЛЕНИЕ ИГРОКА
// ============================================================
const chArms={t:$('ch-t'),b:$('ch-b'),l:$('ch-l'),r:$('ch-r')}; let lastGap=-1;
let scanMeT=0, bobT=0;
function updatePlayer(dt){
    if(!me.alive){
        let tb=null; for(let i=0;i<bots.length;i++){ if(bots[i].alive&&bots[i].team===me.team){ tb=bots[i]; break; } }
        if(tb){ camera.position.set(tb.pos.x-Math.sin(tb.yaw)*0.25,tb.pos.y+1.6,tb.pos.z-Math.cos(tb.yaw)*0.25); camera.rotation.y=tb.yaw; camera.rotation.x=0; }
        else camera.position.y=Math.max(0.3,camera.position.y-dt*2);
        return;
    }
    const canMove=phase==='live'||phase==='roundEnd';
    let f=0,s=0;
    if(canMove){ f=(keys.KeyW?1:0)-(keys.KeyS?1:0)-joy.y; s=(keys.KeyD?1:0)-(keys.KeyA?1:0)+joy.x; const l=Math.hypot(f,s); if(l>1){ f/=l; s/=l; } }
    const W=WEAPONS[curId()];
    const speed=(me.crouch?2.6:5.2)*W.speed*((aiming&&W.scoped)?0.6:1);
    const sy=Math.sin(me.yaw), cy=Math.cos(me.yaw);
    me.vel.x=(-sy*f+cy*s)*speed; me.vel.z=(-cy*f-sy*s)*speed;
    me.vel.y-=22*dt;
    if(canMove&&keys.Space&&me.onGround){ me.vel.y=7.2; me.onGround=false; }
    me.pos.x+=me.vel.x*dt; me.pos.z+=me.vel.z*dt; me.pos.y+=me.vel.y*dt;
    if(me.pos.y<=0){ me.pos.y=0; me.vel.y=0; me.onGround=true; }
    C.resolveCollisions(me.pos,0.4,colliders);
    for(let i=0;i<bots.length;i++){
        const b=bots[i]; if(!b.alive) continue;
        const dx=me.pos.x-b.pos.x, dz=me.pos.z-b.pos.z, d2=dx*dx+dz*dz;
        if(d2<0.64&&d2>1e-6){ const d=Math.sqrt(d2), p=(0.8-d)*0.6; me.pos.x+=dx/d*p; me.pos.z+=dz/d*p; }
    }
    me.h=me.crouch?1.35:1.8;
    const te=me.crouch?1.2:1.7; me.eyeH+=(te-me.eyeH)*Math.min(1,dt*10);
    let by=0;
    if(me.onGround&&Math.hypot(me.vel.x,me.vel.z)>0.5){ bobT+=dt*11; by=Math.sin(bobT)*0.02; }
    camera.position.set(me.pos.x,me.pos.y+me.eyeH+by,me.pos.z);
    camera.rotation.y=me.yaw; camera.rotation.x=me.pitch;

    if(reloading&&gt>=reloadEnd) finishReload();
    if(fireHeld&&W.auto) playerShoot();

    // обзорность врагов для радара
    scanMeT-=dt;
    if(scanMeT<=0){
        scanMeT=0.25;
        const ey=me.pos.y+me.eyeH;
        for(let i=0;i<bots.length;i++){ const b=bots[i]; if(!b.alive||b.team===me.team) continue;
            const dx=b.pos.x-me.pos.x, dz=b.pos.z-me.pos.z;
            if(dx*dx+dz*dz<2025 && los(me.pos.x,ey,me.pos.z,b.pos.x,b.pos.y+1.3,b.pos.z)) b.spotT=gt; }
    }
    // FOV / прицел
    const tf=aiming?W.aimFov:75;
    if(Math.abs(camera.fov-tf)>0.05){ camera.fov+=(tf-camera.fov)*Math.min(1,dt*12); camera.updateProjectionMatrix(); }
    const sc=!!(W.scoped&&aiming&&camera.fov<40);
    if(sc!==scopedNow){ scopedNow=sc; $('scope').style.display=sc?'block':'none'; $('crosshair').style.display=sc?'none':'block'; gunGroup.visible=!sc; }

    // анимации оружия
    if(flashT>0){ flashT-=dt; if(flashT<=0) flash.visible=false; }
    kick=Math.max(0,kick-dt*9); swing=Math.max(0,swing-dt*4); switchT=Math.max(0,switchT-dt);
    const base=WEAPONS[curId()].cat==='knife'?0.26:0.24;
    gunGroup.position.z=-0.35+kick*0.07;
    gunGroup.position.y=-0.22-switchT*0.5-(aiming&&!W.scoped?0.02:0);
    gunGroup.position.x=aiming&&!W.scoped?base*0.35:base;
    gunGroup.rotation.x=(reloading?0.55:0)+kick*0.05-swing*0.9;
    gunGroup.rotation.z=swing*0.5;

    // прицел
    bloom=Math.max(0,bloom-dt*1.6);
    const gap=Math.round(6+bloom*14+Math.min(8,Math.hypot(me.vel.x,me.vel.z)*1.1))*S.chSize;
    if(gap!==lastGap){
        lastGap=gap;
        chArms.t.style.transform='translateY('+(-gap-8*S.chSize)+'px)'; chArms.b.style.transform='translateY('+gap+'px)';
        chArms.l.style.transform='translateX('+(-gap-8*S.chSize)+'px)'; chArms.r.style.transform='translateX('+gap+'px)';
    }
}

// ============================================================
//  ЦИКЛ / FPS
// ============================================================
let lastFrame=0, adAcc=0, adN=0, adGood=0, mmT=0, shopT=0;
const fpsEl=$('fps-val');
function adapt(dt){
    adAcc+=dt; adN++;
    if(adAcc<1) return;
    const avg=adAcc/adN*1000, fps=Math.round(adN/adAcc); adAcc=0; adN=0;
    setText(fpsEl,fps); fpsEl.style.color=fps>=50?'#4ade80':(fps>=30?'#fbbf24':'#f87171');
    if(!S.auto) return;
    const target=1000/Math.min(S.fpsCap||60,60);
    if(avg>target*1.3 && effScale>0.45){ effScale=Math.max(0.45,effScale-0.1); setRes(); adGood=0; }
    else if(avg<target*1.12){ if(++adGood>=4 && effScale<S.scale){ effScale=Math.min(S.scale,effScale+0.05); setRes(); adGood=0; } }
    else adGood=0;
}
function loop(now){
    requestAnimationFrame(loop);
    if(!running) return;
    const interval=S.fpsCap>0?1000/S.fpsCap:0;
    if(now-lastFrame<interval-1.5) return;
    let dt=(now-lastFrame)/1000; lastFrame=now;
    if(dt>0.06) dt=0.06; if(dt<=0) dt=0.001;
    adapt(dt);
    if(!paused){
        gt+=dt;
        updatePhase(dt);
        updatePlayer(dt);
        for(let i=0;i<bots.length;i++) updateBot(bots[i],dt);
        for(let i=0;i<tracers.length;i++){ const t=tracers[i]; if(t.ln.visible){ t.life-=dt; if(t.life<=0) t.ln.visible=false; else t.ln.material.opacity=Math.min(1,t.life/0.05); } }
        mmT-=dt; if(mmT<=0){ mmT=0.08; drawMinimap(); updateScore(); }
        if(!shopEl.classList.contains('hidden')){ shopT-=dt; if(shopT<=0){ shopT=0.5; renderShop(); } }
    }
    renderer.render(scene,camera);
}
function onResize(){
    camera.aspect=innerWidth/Math.max(1,innerHeight); camera.updateProjectionMatrix();
    renderer.setSize(innerWidth,innerHeight);
}
addEventListener('resize',onResize);

// ============================================================
//  ЛОББИ
// ============================================================
function drawPreview(cv,def){
    const W=120, k=(W-6)/(def.hx*2), H=Math.round(def.hz*2*k+6); cv.width=W; cv.height=H;
    const g=cv.getContext('2d'); g.fillStyle='#1b2230'; g.fillRect(0,0,W,H);
    g.fillStyle='#8fa0b8'; def.boxes.forEach(b=>g.fillRect(W/2+(b[0]-b[2]/2)*k,H/2+(b[1]-b[4]/2)*k,Math.max(1.5,b[2]*k),Math.max(1.5,b[4]*k)));
    g.fillStyle='#fbbf24'; def.spawns.T.forEach(s=>g.fillRect(W/2+s[0]*k-2,H/2+s[1]*k-2,4,4));
    g.fillStyle='#3b82f6'; def.spawns.CT.forEach(s=>g.fillRect(W/2+s[0]*k-2,H/2+s[1]*k-2,4,4));
}
function buildLobby(){
    const list=$('map-list'); list.innerHTML='';
    MAPS.forEach((m,i)=>{
        const c=document.createElement('div'); c.className='map-card'+(i===lobby.map?' on':'');
        const cv=document.createElement('canvas'); c.appendChild(cv);
        c.insertAdjacentHTML('beforeend','<b>'+m.name+'</b><small>'+m.desc+'</small>');
        drawPreview(cv,m);
        c.addEventListener('click',()=>{ lobby.map=i; list.querySelectorAll('.map-card').forEach((x,j)=>x.classList.toggle('on',j===i)); });
        list.appendChild(c);
    });
    document.querySelectorAll('.seg[data-opt]').forEach(seg=>{
        seg.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{
            const o=seg.dataset.opt; let v=b.dataset.v; if(o==='size'||o==='freeze') v=parseInt(v,10);
            lobby[o]=v; seg.querySelectorAll('button').forEach(x=>x.classList.toggle('on',x===b));
        }));
    });
    $('btn-play').addEventListener('click',startMatch);
}

// ============================================================
//  INIT
// ============================================================
buildLobby();
syncSettingsUI();
onResize();
applyGraphics();
requestAnimationFrame(loop);

})();
