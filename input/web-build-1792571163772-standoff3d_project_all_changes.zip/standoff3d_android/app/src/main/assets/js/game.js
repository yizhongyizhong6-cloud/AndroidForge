/* ============================================================
   STANDOFF 3D — движок (Three.js r128)
   ============================================================ */
(function(){
'use strict';

// ---------- DOM ----------
const wrapper = document.getElementById('game-wrapper');
const container = document.getElementById('game-container');
const $ = id => document.getElementById(id);
const fpsVal=$('fps-val'), frameTimeEl=$('frame-time'), entityCount=$('entity-count');
const hpVal=$('hp-val'), armorVal=$('armor-val'), ammoCur=$('ammo-cur'), ammoMax=$('ammo-max');
const scoreCtEl=$('score-ct'), scoreTrEl=$('score-tr');
const killFeedEl=$('kill-feed'), vignette=$('damage-vignette'), scopeEl=$('sniper-scope');
const hitmarkerEl=$('hitmarker'), crosshairEl=$('crosshair');
const minimap=$('minimap'), mmCtx=minimap.getContext('2d');
const fpsGraph=$('fps-graph'), fgCtx=fpsGraph.getContext('2d');

// ---------- AUDIO (синтез, без ассетов) ----------
let AC=null;
function audio(){ if(!AC){ try{ AC=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){} } if(AC && AC.state==='suspended') AC.resume(); return AC; }
function sfxShot(pitch){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime, len=Math.floor(ac.sampleRate*0.11);
    const buf=ac.createBuffer(1,len,ac.sampleRate), d=buf.getChannelData(0);
    for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/len,2);
    const src=ac.createBufferSource(); src.buffer=buf;
    const f=ac.createBiquadFilter(); f.type='lowpass'; f.frequency.value=pitch;
    const g=ac.createGain(); g.gain.setValueAtTime(0.22,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.12);
    src.connect(f); f.connect(g); g.connect(ac.destination); src.start(t);
}
function sfxHit(){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime;
    const o=ac.createOscillator(), g=ac.createGain();
    o.type='square'; o.frequency.setValueAtTime(900,t); o.frequency.exponentialRampToValueAtTime(300,t+0.06);
    g.gain.setValueAtTime(0.12,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.07);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t+0.08);
}
function sfxDie(){
    const ac=audio(); if(!ac) return;
    const t=ac.currentTime;
    const o=ac.createOscillator(), g=ac.createGain();
    o.type='sawtooth'; o.frequency.setValueAtTime(220,t); o.frequency.exponentialRampToValueAtTime(60,t+0.35);
    g.gain.setValueAtTime(0.18,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.4);
    o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t+0.45);
}

// ---------- THREE: сцена ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b0f16);
scene.fog = new THREE.Fog(0x0b0f16, 45, 120);

const camera = new THREE.PerspectiveCamera(75, innerWidth/innerHeight, 0.08, 400);
camera.rotation.order='YXZ';
scene.add(camera);

const renderer = new THREE.WebGLRenderer({ antialias: !('ontouchstart' in window), powerPreference:'high-performance' });
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
// Улучшенная цветопередача и контраст материалов (сохраняем совместимость с Three.js r128).
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.12;
renderer.domElement.style.position='absolute';
renderer.domElement.style.inset='0';
renderer.domElement.style.zIndex='1';
container.insertBefore(renderer.domElement, container.firstChild);

const hemi = new THREE.HemisphereLight(0x9db8e8, 0x2a241c, 0.6);
scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffe9c4, 1.05);
sun.position.set(35, 55, 25);
sun.castShadow = true;
sun.shadow.mapSize.set(2048,2048);
sun.shadow.camera.left=-45; sun.shadow.camera.right=45;
sun.shadow.camera.top=45; sun.shadow.camera.bottom=-45;
sun.shadow.camera.far=140;
scene.add(sun);

// ---------- КАРТА ----------
const WORLD = 30; // полуразмер арены
const colliders = [];   // {minX,maxX,minZ,maxZ}
const wallMeshes = [];  // для рейкастов

// Процедурные текстуры: создаются локально, без скачивания картинок и без тяжёлых ассетов.
const surfaceTextures = {};
function makeSurfaceTexture(kind){
    if(surfaceTextures[kind]) return surfaceTextures[kind];
    const cv=document.createElement('canvas'); cv.width=512; cv.height=512;
    const cx=cv.getContext('2d');
    if(kind==='concrete'){
        cx.fillStyle='#77766e'; cx.fillRect(0,0,512,512);
        for(let i=0;i<9000;i++){ const x=Math.random()*512,y=Math.random()*512,a=0.025+Math.random()*0.12; cx.fillStyle=Math.random()>.5?`rgba(235,230,210,${a})`:`rgba(20,24,26,${a})`; cx.fillRect(x,y,1+Math.random()*3,1+Math.random()*2); }
        cx.strokeStyle='rgba(25,29,30,.22)'; cx.lineWidth=2;
        for(let y=0;y<512;y+=128){cx.beginPath();cx.moveTo(0,y);cx.lineTo(512,y);cx.stroke();}
        for(let x=0;x<512;x+=128){cx.beginPath();cx.moveTo(x,0);cx.lineTo(x,512);cx.stroke();}
    } else if(kind==='crate'){
        cx.fillStyle='#98784b'; cx.fillRect(0,0,512,512);
        for(let y=12;y<512;y+=58){cx.fillStyle='rgba(43,29,15,.16)';cx.fillRect(0,y,512,4);cx.fillStyle='rgba(235,196,129,.13)';cx.fillRect(0,y+5,512,2);}
        for(let i=0;i<2600;i++){cx.fillStyle=Math.random()>.5?'rgba(30,22,13,.10)':'rgba(255,225,170,.09)';cx.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*8,1+Math.random()*2);}
        cx.strokeStyle='rgba(35,25,14,.55)';cx.lineWidth=8;cx.strokeRect(8,8,496,496);cx.lineWidth=3;cx.strokeRect(20,20,472,472);
    } else {
        cx.fillStyle='#85847d';cx.fillRect(0,0,512,512);
        for(let i=0;i<6500;i++){let a=.02+Math.random()*.10;cx.fillStyle=Math.random()>.5?`rgba(255,255,255,${a})`:`rgba(10,12,14,${a})`;cx.fillRect(Math.random()*512,Math.random()*512,1+Math.random()*2,1+Math.random()*2);}
        cx.strokeStyle='rgba(20,24,28,.12)';cx.lineWidth=2;for(let y=64;y<512;y+=64){cx.beginPath();cx.moveTo(0,y);cx.lineTo(512,y);cx.stroke();}
    }
    const tex=new THREE.CanvasTexture(cv); tex.wrapS=tex.wrapT=THREE.RepeatWrapping; tex.anisotropy= Math.min(8, renderer.capabilities.getMaxAnisotropy()); tex.encoding=THREE.sRGBEncoding; tex.needsUpdate=true;
    surfaceTextures[kind]=tex; return tex;
}
function addBox(x, z, w, h, d, color, opts){
    opts = opts || {};
    const isCrate = color===0x6b5432 || color===0x77603a || color===0x5c4a2e;
    const tex=makeSurfaceTexture(isCrate?'crate':'concrete');
    const m = new THREE.Mesh(
        new THREE.BoxGeometry(w,h,d),
        new THREE.MeshStandardMaterial({ color: color, map:tex, roughness: opts.rough!=null?opts.rough:0.88, metalness:0.03 })
    );
    m.position.set(x, opts.y!=null?opts.y:h/2, z);
    m.castShadow = true; m.receiveShadow = true;
    scene.add(m);
    colliders.push({ minX:x-w/2, maxX:x+w/2, minZ:z-d/2, maxZ:z+d/2 });
    wallMeshes.push(m);
    return m;
}

// земля
const groundTex=makeSurfaceTexture('floor');
groundTex.repeat.set(12,12);
const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(WORLD*2+4, WORLD*2+4),
    new THREE.MeshStandardMaterial({ color:0x8d918e, map:groundTex, roughness:0.96, metalness:0.01 })
);
ground.rotation.x=-Math.PI/2; ground.receiveShadow=true;
scene.add(ground);
const grid = new THREE.GridHelper(WORLD*2, WORLD, 0x3d4a5c, 0x2c3542);
grid.position.y=0.01; scene.add(grid);

// периметр
addBox(0, -WORLD-0.5, WORLD*2+4, 5, 1, 0x39424f);
addBox(0,  WORLD+0.5, WORLD*2+4, 5, 1, 0x39424f);
addBox(-WORLD-0.5, 0, 1, 5, WORLD*2+4, 0x39424f);
addBox( WORLD+0.5, 0, 1, 5, WORLD*2+4, 0x39424f);

// интерьер: укрытия
addBox(0, 0, 10, 2.6, 1.2, 0x4a4038);          // центральная стена
addBox(-12, -10, 2, 2.2, 2, 0x6b5432);         // ящики
addBox(-9.2, -10.5, 1.6, 1.4, 1.6, 0x77603a);
addBox(12, -12, 2, 2.2, 2, 0x6b5432);
addBox(9, 12, 2.4, 2.2, 2.4, 0x6b5432);
addBox(-11, 11, 2, 2.2, 2, 0x6b5432);
addBox(-13, 13.2, 1.5, 1.3, 1.5, 0x77603a);
addBox(0, -18, 6, 2.4, 1, 0x4a5568);
addBox(0, 18, 6, 2.4, 1, 0x4a5568);
addBox(-20, 0, 1, 2.6, 8, 0x4a5568);
addBox(20, 2, 1, 2.6, 8, 0x4a5568);
addBox(16, -4, 3, 1.6, 3, 0x5c4a2e);
addBox(-16, 5, 3, 1.6, 3, 0x5c4a2e);

// декоративные светящиеся полосы
const stripMat = new THREE.MeshBasicMaterial({ color:0xff8c00 });
[[0,-0.72,10.4,0.06],[0,0.72,10.4,0.06]].forEach(s=>{
    const st=new THREE.Mesh(new THREE.BoxGeometry(s[2],0.06,s[3]||0.06), stripMat);
    st.position.set(s[0], 2.65, s[1]); scene.add(st);
});

// ---------- ИГРОК ----------
const player = {
    pos: new THREE.Vector3(0, 0, 24),
    vel: new THREE.Vector3(),
    yaw: 0, pitch: 0,
    hp: 100, armor: 100,
    crouch: false, onGround: true,
    alive: true, eyeH: 1.7
};

// ---------- ОРУЖИЕ ----------
const WEAPONS = {
    1:{ name:'AK-47', dmg:34, rpm:600, mag:30, reserve:90,  auto:true,  reloadTime:2100, aimFov:55,  spread:0.014, recoil:0.014, scoped:false, snd:1800 },
    2:{ name:'M4A1',  dmg:31, rpm:680, mag:30, reserve:90,  auto:true,  reloadTime:2000, aimFov:55,  spread:0.011, recoil:0.011, scoped:false, snd:2200 },
    3:{ name:'AWP',   dmg:115,rpm:45,  mag:5,  reserve:15,  auto:false, reloadTime:3200, aimFov:20,  spread:0.0015,recoil:0.05,  scoped:true,  snd:900  },
    4:{ name:'GLOCK', dmg:25, rpm:380, mag:20, reserve:120, auto:false, reloadTime:1500, aimFov:62,  spread:0.016, recoil:0.009, scoped:false, snd:2600 }
};
const wstate = {}; // ammo/reserve per slot
for (const k in WEAPONS){ wstate[k]={ ammo:WEAPONS[k].mag, reserve:WEAPONS[k].reserve }; }
let curWeapon = 1, lastShot = 0, reloading = false, reloadTimer = null;
let aiming = false, fireHeld = false, bloom = 0;
let sensitivity = 1.0;

// viewmodel оружия (примитивы)
const gunGroup = new THREE.Group();
camera.add(gunGroup);
const muzzleLight = new THREE.PointLight(0xffb347, 0, 9);
muzzleLight.position.set(0.15,-0.1,-1.0);
camera.add(muzzleLight);

function buildGun(slot){
    while(gunGroup.children.length) gunGroup.remove(gunGroup.children[0]);
    const dark = new THREE.MeshStandardMaterial({ color:0x1c2129, roughness:0.5, metalness:0.5 });
    const wood = new THREE.MeshStandardMaterial({ color:0x7a4a1e, roughness:0.7 });
    const acc  = new THREE.MeshStandardMaterial({ color:0xff8c00, roughness:0.4, emissive:0x3a1e00 });
    const g = gunGroup;
    const add=(geo,mat,x,y,z)=>{ const m=new THREE.Mesh(geo,mat); m.position.set(x,y,z); g.add(m); return m; };
    if(slot===3){ // AWP
        add(new THREE.BoxGeometry(0.07,0.09,0.9), dark, 0, 0, -0.55);
        add(new THREE.CylinderGeometry(0.02,0.02,0.7,8), dark, 0, 0.01, -1.05).rotation.x=Math.PI/2;
        add(new THREE.BoxGeometry(0.06,0.08,0.25), wood, 0, -0.01, -0.12);
        add(new THREE.CylinderGeometry(0.035,0.035,0.16,8), dark, 0, 0.075, -0.45).rotation.x=Math.PI/2;
    } else if(slot===4){ // Glock
        add(new THREE.BoxGeometry(0.06,0.09,0.28), dark, 0, 0, -0.22);
        add(new THREE.BoxGeometry(0.055,0.14,0.08), dark, 0, -0.09, -0.1);
        add(new THREE.BoxGeometry(0.02,0.02,0.02), acc, 0, 0.055, -0.32);
    } else { // AK / M4
        add(new THREE.BoxGeometry(0.07,0.1,0.62), dark, 0, 0, -0.42);
        add(new THREE.CylinderGeometry(0.018,0.018,0.34,8), dark, 0, 0.015, -0.85).rotation.x=Math.PI/2;
        add(new THREE.BoxGeometry(0.055,0.16,0.09), dark, 0, -0.12, -0.3);
        if(slot===1) add(new THREE.BoxGeometry(0.075,0.08,0.22), wood, 0, -0.005, -0.06);
        else add(new THREE.BoxGeometry(0.075,0.07,0.2), new THREE.MeshStandardMaterial({color:0x2b333f,roughness:0.5}), 0, -0.005, -0.06);
        add(new THREE.BoxGeometry(0.02,0.03,0.1), acc, 0, 0.075, -0.6);
    }
    g.position.set(0.24, -0.22, -0.35);
    g.rotation.set(0, 0, 0);
    g.visible = true;
}
buildGun(1);

// ---------- КОМАНДЫ И БОТЫ ----------
const ALLY_COUNT = 4, ENEMY_COUNT = 5, KILL_LIMIT = 30;
const ALLY_NAMES  = ['Alex','Bravo','Cobra','Delta','Echo','Fox'];
const ENEMY_NAMES = ['Viper','Wolf','Ghost','Hawk','Rex','Nova','Jet','Lynx'];
const TEAMS = {
    ally:  { body:0x2f6df0, head:0xd9a066, tag:'#38bdf8' },
    enemy: { body:0xb3401e, head:0xd9a066, tag:'#f87171' }
};
const SPAWNS = {
    ally:  [[-6,26],[-2,27],[2,27],[6,26],[10,25],[-10,25]],
    enemy: [[-6,-26],[-2,-27],[2,-27],[6,-26],[10,-25],[-10,-25],[14,-24],[-14,-24]]
};
player.name = 'Вы';
const bots = [];
let botIdSeq = 0, scoreCT = 0, scoreTR = 0, matchOver = false;

function pointInCollider(x,z,r){
    for(const c of colliders){
        if(x>c.minX-r && x<c.maxX+r && z>c.minZ-r && z<c.maxZ+r) return true;
    }
    return false;
}

function makeTag(name, color){
    const cv = document.createElement('canvas'); cv.width = 128; cv.height = 48;
    const g = cv.getContext('2d');
    g.font = 'bold 22px sans-serif'; g.textAlign = 'center';
    g.lineWidth = 4; g.strokeStyle = 'rgba(0,0,0,.85)'; g.strokeText(name, 64, 22);
    g.fillStyle = color; g.fillText(name, 64, 22);
    g.beginPath(); g.moveTo(54,30); g.lineTo(74,30); g.lineTo(64,44); g.closePath(); g.fill();
    const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map:new THREE.CanvasTexture(cv), depthTest:false, transparent:true }));
    spr.scale.set(1.3, 0.49, 1); spr.position.y = 2.35; spr.renderOrder = 10;
    return spr;
}

function spawnBot(team, name){
    const id = ++botIdSeq, T = TEAMS[team];
    const grp = new THREE.Group();
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.34,0.42,1.05,10), new THREE.MeshStandardMaterial({ color:T.body, roughness:0.7 }));
    body.position.y = 0.85; body.castShadow = true;
    const head = new THREE.Mesh(new THREE.SphereGeometry(0.23,12,10), new THREE.MeshStandardMaterial({ color:T.head, roughness:0.6 }));
    head.position.y = 1.62; head.castShadow = true;
    const visor = new THREE.Mesh(new THREE.BoxGeometry(0.3,0.08,0.1), new THREE.MeshStandardMaterial({ color:0x14181f }));
    visor.position.set(0,1.64,0.16);
    const gun = new THREE.Mesh(new THREE.BoxGeometry(0.07,0.08,0.55), new THREE.MeshStandardMaterial({ color:0x1c2129 }));
    gun.position.set(0.3,1.05,0.3);
    grp.add(body, head, visor, gun);
    if(team==='ally') grp.add(makeTag(name, T.tag));
    scene.add(grp);
    const bot = { id, name, team, grp, body, head, hp:100, dead:false, respawnT:0,
        target:new THREE.Vector3(), fireCd:1+Math.random(), strafe:Math.random()<0.5?1:-1, strafeT:0,
        checkT:Math.random()*0.4, enemy:null, enemyDist:99, stuckT:0, lastX:0, lastZ:0, slot:botIdSeq%6 };
    body.userData.bot = bot; body.userData.part = 'body';
    head.userData.bot = bot; head.userData.part = 'head';
    bots.push(bot);
    respawnBot(bot);
    return bot;
}

function respawnBot(bot){
    const list = SPAWNS[bot.team];
    let sp, tries = 0;
    do { sp = list[Math.floor(Math.random()*list.length)]; tries++; }
    while(tries<10 && bots.some(o=>o!==bot && !o.dead && Math.hypot(o.grp.position.x-sp[0], o.grp.position.z-sp[1])<1.4));
    bot.grp.position.set(sp[0]+(Math.random()-0.5), 0, sp[1]);
    bot.grp.rotation.y = bot.team==='ally' ? Math.PI : 0;
    bot.hp = 100; bot.dead = false; bot.enemy = null; bot.fireCd = 1+Math.random();
    bot.target.copy(bot.grp.position); bot.stuckT = 0;
    bot.grp.visible = true;
}

function enemyMeshes(){
    const out = [];
    for(const b of bots) if(b.team==='enemy' && !b.dead) out.push(b.body, b.head);
    return out;
}

function countAlive(team){ let n=0; for(const b of bots) if(b.team===team && !b.dead) n++; return n; }

function createTeams(){
    const an = ALLY_NAMES.slice().sort(()=>Math.random()-0.5), en = ENEMY_NAMES.slice().sort(()=>Math.random()-0.5);
    for(let i=0;i<ALLY_COUNT;i++)  spawnBot('ally',  an[i]);
    for(let i=0;i<ENEMY_COUNT;i++) spawnBot('enemy', en[i]);
}

// ---------- ТРАССЕРЫ ----------
const tracers = [];
function spawnTracer(from, to, color){
    const geo = new THREE.BufferGeometry().setFromPoints([from, to]);
    const mat = new THREE.LineBasicMaterial({ color: color||0xffd27a, transparent:true, opacity:0.9 });
    const line = new THREE.Line(geo, mat);
    scene.add(line);
    tracers.push({ line, life:0.07 });
}

// ---------- СТРЕЛЬБА ----------
const raycaster = new THREE.Raycaster();
raycaster.far = 300;

function flashHitmarker(){
    hitmarkerEl.style.opacity='1';
    clearTimeout(flashHitmarker._t);
    flashHitmarker._t=setTimeout(()=>hitmarkerEl.style.opacity='0', 70);
}

function updateAmmoHUD(){
    const st = wstate[curWeapon];
    ammoCur.textContent = st.ammo;
    ammoMax.textContent = st.reserve;
    ammoCur.style.color = st.ammo===0 ? '#ff3b3b' : (st.ammo<=5 ? '#ff8c00' : '#fff');
}

function startReload(){
    const W = WEAPONS[curWeapon], st = wstate[curWeapon];
    if(reloading || st.ammo===W.mag || st.reserve<=0) return;
    reloading = true;
    $('btn-reload').classList.add('active');
    setTimeout(()=>{},0);
    reloadTimer = setTimeout(()=>{
        const need = W.mag - st.ammo;
        const take = Math.min(need, st.reserve);
        st.ammo += take; st.reserve -= take;
        reloading = false;
        $('btn-reload').classList.remove('active');
        updateAmmoHUD();
    }, W.reloadTime);
}

function showBanner(html, ms){
    let el = $('team-banner');
    if(!el){
        el = document.createElement('div'); el.id = 'team-banner';
        el.style.cssText = 'position:absolute;left:50%;top:30%;transform:translate(-50%,-50%);z-index:60;pointer-events:none;text-align:center;font:900 34px sans-serif;letter-spacing:.12em;color:#fff;text-shadow:0 2px 12px #000;display:none';
        container.appendChild(el);
    }
    el.innerHTML = html; el.style.display = 'block';
    clearTimeout(showBanner._t); showBanner._t = setTimeout(()=>{ el.style.display='none'; }, ms||2500);
}

function addScore(team){
    if(team==='ally'){ scoreCT++; scoreCtEl.textContent = scoreCT; }
    else { scoreTR++; scoreTrEl.textContent = scoreTR; }
    if(!matchOver && (scoreCT>=KILL_LIMIT || scoreTR>=KILL_LIMIT)){
        matchOver = true;
        const win = scoreCT>=KILL_LIMIT;
        showBanner(win?'<span style="color:#4ade80">ПОБЕДА КОМАНДЫ</span>':'<span style="color:#f87171">ПОРАЖЕНИЕ</span>', 4500);
        setTimeout(resetMatch, 5000);
    }
}

function resetMatch(){
    scoreCT = scoreTR = 0; scoreCtEl.textContent = 0; scoreTrEl.textContent = 0;
    bots.forEach(respawnBot);
    respawnPlayer();
    matchOver = false;
}

function killBot(bot, attacker, headshot){
    bot.dead = true; bot.grp.visible = false; bot.enemy = null;
    bot.respawnT = 4 + Math.random()*2;
    const aTeam = attacker===player ? 'ally' : attacker.team;
    addScore(aTeam);
    addKillFeed(attacker.name, bot.name, attacker===player, headshot, aTeam, bot.team);
    if(attacker===player) sfxDie();
}

function damageBot(bot, dmg, part, attacker){
    if(bot.dead) return;
    bot.hp -= dmg;
    if(attacker===player){ flashHitmarker(); sfxHit(); }
    if(bot.hp<=0) killBot(bot, attacker, part==='head');
}

function tryFire(now){
    if(!player.alive || reloading) return;
    const W = WEAPONS[curWeapon], st = wstate[curWeapon];
    if(now - lastShot < 60000/W.rpm) return;
    if(st.ammo<=0){ startReload(); return; }
    lastShot = now;
    st.ammo--;
    updateAmmoHUD();
    sfxShot(W.snd);

    // спред
    const moveFactor = Math.min(1, player.vel.length()/5);
    const spread = (W.spread + bloom*0.02 + moveFactor*0.02) * (aiming?0.45:1);
    const dir = new THREE.Vector3(0,0,-1).applyQuaternion(camera.quaternion);
    dir.x += (Math.random()*2-1)*spread;
    dir.y += (Math.random()*2-1)*spread;
    dir.z += (Math.random()*2-1)*spread;
    dir.normalize();
    raycaster.set(camera.position.clone(), dir);

    const botHits = raycaster.intersectObjects(enemyMeshes(), false);
    const wallHits = raycaster.intersectObjects(wallMeshes, false);
    const wallDist = wallHits.length ? wallHits[0].distance : Infinity;

    let endPoint = camera.position.clone().add(dir.clone().multiplyScalar(80));
    if(botHits.length && botHits[0].distance < wallDist){
        const h = botHits[0];
        endPoint = h.point;
        const part = h.object.userData.part;
        damageBot(h.object.userData.bot, W.dmg * (part==='head'?2:1), part, player);
    } else if(wallHits.length){
        endPoint = wallHits[0].point;
    }
    const from = camera.position.clone().add(new THREE.Vector3(0.22,-0.2,-0.6).applyQuaternion(camera.quaternion));
    spawnTracer(from, endPoint);

    muzzleLight.intensity = 2.2;
    player.pitch += W.recoil * (aiming?0.6:1);
    player.yaw += (Math.random()*2-1)*W.recoil*0.4;
    bloom = Math.min(1, bloom + (curWeapon===3?0.6:0.25));
    gunGroup.position.z = -0.28; // откат
}

// ---------- УРОН ПО ИГРОКУ ----------
function applyDamage(d, attacker){
    if(!player.alive) return;
    const absorbed = Math.min(player.armor, d*0.55);
    player.armor = Math.max(0, player.armor - absorbed);
    player.hp = Math.max(0, player.hp - (d - absorbed));
    hpVal.textContent = Math.ceil(player.hp);
    armorVal.textContent = Math.ceil(player.armor);
    vignette.style.boxShadow = 'inset 0 0 120px rgba(255,0,0,0.65)';
    clearTimeout(applyDamage._t);
    applyDamage._t = setTimeout(()=>vignette.style.boxShadow='inset 0 0 100px rgba(255,0,0,0)', 130);
    if(player.hp<=0) playerDie(attacker);
}

function respawnPlayer(){
    const sp = SPAWNS.ally[Math.floor(Math.random()*3)+1] || [0,24];
    player.pos.set(sp[0], 0, sp[1]); player.vel.set(0,0,0);
    player.yaw = 0; player.pitch = 0;
    player.hp = 100; player.armor = 100; player.alive = true;
    for(const k in WEAPONS){ wstate[k].ammo = WEAPONS[k].mag; wstate[k].reserve = WEAPONS[k].reserve; }
    reloading = false; clearTimeout(reloadTimer); $('btn-reload').classList.remove('active');
    hpVal.textContent = 100; armorVal.textContent = 100; bloom = 0;
    updateAmmoHUD();
    $('death-overlay').style.display = 'none';
}

function playerDie(attacker){
    player.alive = false;
    const killer = attacker || { name:'?', team:'enemy' };
    addScore('enemy');
    addKillFeed(killer.name, 'Вы', false, false, 'enemy', 'ally');
    $('death-overlay').style.display = 'flex';
    clearTimeout(playerDie._t);
    playerDie._t = setTimeout(()=>{ if(!player.alive) respawnPlayer(); }, 3000);
}

// ---------- KILL FEED ----------
function addKillFeed(a, b, playerIsKiller, headshot, aTeam, bTeam){
    const col = t => t==='ally' ? 'text-cyan-300' : 'text-amber-400';
    const div = document.createElement('div');
    div.className='kill-item so2-panel px-2 py-0.5 rounded text-[10px] font-sans';
    if(playerIsKiller) div.style.borderColor = '#38e8ff';
    div.innerHTML = '<span class="'+col(aTeam||'ally')+'">'+a+'</span>' +
        ' <i class="fa-solid '+(headshot?'fa-crosshairs':'fa-skull')+' text-slate-400 mx-1"></i> ' +
        '<span class="'+col(bTeam||'enemy')+'">'+b+'</span>';
    killFeedEl.prepend(div);
    while(killFeedEl.children.length>5) killFeedEl.lastChild.remove();
    setTimeout(()=>{ if(div.parentNode) div.remove(); }, 4500);
}

// ---------- ПЕРЕКЛЮЧЕНИЕ ОРУЖИЯ ----------
window.switchWeapon = function(slot){
    if(slot===curWeapon) return;
    curWeapon = slot;
    save.weapon = slot; writeSave();
    reloading = false; clearTimeout(reloadTimer);
    $('btn-reload').classList.remove('active');
    aiming = false;
    for(let i=1;i<=4;i++){
        const b=$('wslot-'+i);
        if(i===slot){ b.classList.add('bg-white/20','border-orange-500'); b.classList.remove('bg-black/40','border-white/10','opacity-60'); }
        else { b.classList.remove('bg-white/20','border-orange-500'); b.classList.add('bg-black/40','border-white/10','opacity-60'); }
    }
    buildGun(slot);
    updateAmmoHUD();
};

// ---------- ВВОД: клавиатура/мышь ----------
const keys = {};
addEventListener('keydown', e=>{
    keys[e.code]=true;
    if(e.code==='KeyR') startReload();
    if(e.code==='KeyC') toggleCrouch();
    if(e.code==='Digit1') switchWeapon(1);
    if(e.code==='Digit2') switchWeapon(2);
    if(e.code==='Digit3') switchWeapon(3);
    if(e.code==='Digit4') switchWeapon(4);
});
addEventListener('keyup', e=>keys[e.code]=false);

const canvas = renderer.domElement;
canvas.addEventListener('click', ()=>{
    audio();
    if(!('ontouchstart' in window) && document.pointerLockElement!==canvas){
        canvas.requestPointerLock && canvas.requestPointerLock();
    }
});
addEventListener('mousemove', e=>{
    if(document.pointerLockElement===canvas){
        const sens = 0.0022 * sensitivity * (aiming?(WEAPONS[curWeapon].scoped?0.35:0.6):1);
        player.yaw -= e.movementX*sens;
        player.pitch -= e.movementY*sens;
        player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch));
    }
});
addEventListener('mousedown', e=>{
    audio();
    if(document.pointerLockElement!==canvas) return;
    if(e.button===0){ fireHeld=true; tryFire(performance.now()); }
    if(e.button===2){ aiming=true; }
});
addEventListener('mouseup', e=>{
    if(e.button===0) fireHeld=false;
    if(e.button===2) aiming=false;
});
addEventListener('contextmenu', e=>e.preventDefault());

function toggleCrouch(){
    player.crouch=!player.crouch;
    $('btn-crouch').classList.toggle('active', player.crouch);
}

// ---------- ВВОД: тач ----------
const joy = { x:0, y:0, id:null };
const joyEl=$('joystick-container'), stickEl=$('joystick-stick');
const JOY_R = 46;

joyEl.addEventListener('pointerdown', e=>{
    if(hudEdit) return;
    joy.id = e.pointerId; joyEl.setPointerCapture(e.pointerId);
});
joyEl.addEventListener('pointermove', e=>{
    if(e.pointerId!==joy.id) return;
    const r = joyEl.getBoundingClientRect();
    let dx = e.clientX-(r.left+r.width/2), dy = e.clientY-(r.top+r.height/2);
    const len = Math.hypot(dx,dy);
    if(len>JOY_R){ dx=dx/len*JOY_R; dy=dy/len*JOY_R; }
    stickEl.style.transform = 'translate(calc(-50% + '+dx+'px), calc(-50% + '+dy+'px))';
    joy.x = dx/JOY_R; joy.y = dy/JOY_R;
});
function joyEnd(e){
    if(e.pointerId!==joy.id) return;
    joy.id=null; joy.x=0; joy.y=0;
    stickEl.style.transform='translate(-50%,-50%)';
}
joyEl.addEventListener('pointerup', joyEnd);
joyEl.addEventListener('pointercancel', joyEnd);

// зона обзора
const camArea=$('touch-camera-area');
let lookId=null, lookX=0, lookY=0;
function applyLook(dx,dy){
    const sens = 0.0042 * sensitivity * (aiming?(WEAPONS[curWeapon].scoped?0.35:0.6):1);
    player.yaw -= dx*sens;
    player.pitch -= dy*sens;
    player.pitch = Math.max(-1.45, Math.min(1.45, player.pitch));
}
camArea.addEventListener('pointerdown', e=>{
    audio();
    if(lookId!==null) return;
    lookId=e.pointerId; lookX=e.clientX; lookY=e.clientY;
    camArea.setPointerCapture(e.pointerId);
});
camArea.addEventListener('pointermove', e=>{
    if(e.pointerId!==lookId) return;
    applyLook(e.clientX-lookX, e.clientY-lookY);
    lookX=e.clientX; lookY=e.clientY;
});
function lookEnd(e){ if(e.pointerId===lookId) lookId=null; }
camArea.addEventListener('pointerup', lookEnd);
camArea.addEventListener('pointercancel', lookEnd);

// кнопки (удержание привязано к конкретному пальцу)
function bindHold(el, down, up){
    let pid=null;
    el.addEventListener('pointerdown', e=>{
        if(hudEdit) return;
        e.preventDefault(); audio();
        pid=e.pointerId; el.setPointerCapture(e.pointerId); down();
    });
    const end=e=>{ if(e.pointerId!==pid) return; pid=null; up&&up(); };
    ['pointerup','pointercancel','lostpointercapture'].forEach(ev=>el.addEventListener(ev, end));
}
bindHold($('btn-jump'), ()=>{ keys['Space']=true; }, ()=>{ keys['Space']=false; });

// МОБИЛЬНЫЙ ОГОНЬ + ОБЗОР: палец можно уводить за пределы кнопки,
// сама кнопка остаётся на месте. Захват указателя сохраняет стрельбу.
const fireBtn=$('btn-fire');
let fireLookId=null, fireLX=0, fireLY=0;
fireBtn.style.touchAction='none';
fireBtn.addEventListener('pointerdown', e=>{
    if(hudEdit) return;
    e.preventDefault(); e.stopPropagation(); audio();
    if(fireLookId!==null) return;
    fireLookId=e.pointerId; fireLX=e.clientX; fireLY=e.clientY;
    fireHeld=true; tryFire(performance.now());
    try { fireBtn.setPointerCapture(e.pointerId); } catch(_) {}
});
addEventListener('pointermove', e=>{
    if(e.pointerId!==fireLookId) return;
    e.preventDefault();
    applyLook(e.clientX-fireLX, e.clientY-fireLY);
    fireLX=e.clientX; fireLY=e.clientY;
},{passive:false});
function fireTouchEnd(e){
    if(e.pointerId!==fireLookId) return;
    fireLookId=null; fireHeld=false;
}
['pointerup','pointercancel'].forEach(ev=>addEventListener(ev, fireTouchEnd));

$('btn-aim').addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; aiming=!aiming; $('btn-aim').classList.toggle('active', aiming); });
$('btn-crouch').addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; toggleCrouch(); });
$('btn-reload').addEventListener('pointerdown', e=>{ e.preventDefault(); if(hudEdit) return; startReload(); });

// ---------- ПАМЯТЬ ИГРЫ (localStorage) ----------
const SAVE_KEY = 'standoff3d_save_v1';
const save = {
    gfx: { rs:1.0, sh:'high', fps:'60', sens:1.0, preset:'high', auto:true },
    hud: {},        // позиции кнопок в долях экрана {x,y}
    hudScale: 1,    // размер кнопок
    weapon: 1
};
function loadSave(){
    try{
        const raw = localStorage.getItem(SAVE_KEY);
        if(!raw) return;
        const d = JSON.parse(raw);
        if(!d || typeof d!=='object') return;
        Object.assign(save.gfx, d.gfx||{});
        save.hud = (d.hud && typeof d.hud==='object') ? d.hud : {};
        const hs = parseFloat(d.hudScale);
        save.hudScale = (hs>=0.7 && hs<=1.5) ? hs : 1;
        const w = parseInt(d.weapon,10);
        save.weapon = (w>=1 && w<=4) ? w : 1;
    }catch(e){}
}
function writeSave(){
    try{ localStorage.setItem(SAVE_KEY, JSON.stringify(save)); }catch(e){}
}

// ---------- HUD EDIT MODE ----------
let hudEdit=false;
const hudEls = { joy:$('joystick-container'), fire:$('btn-fire'), aim:$('btn-aim'), jump:$('btn-jump'), crouch:$('btn-crouch'), reload:$('btn-reload') };
const hudBase = {}, hudInit = {};
for(const k in hudEls){
    hudInit[k] = hudEls[k].style.cssText;
    hudBase[k] = k==='joy' ? 130 : (parseFloat(hudEls[k].style.width)||52);
}
function setHudEdit(on){
    hudEdit = on;
    wrapper.classList.toggle('hud-edit-mode', hudEdit);
    $('btn-hud-edit').classList.toggle('bg-orange-500', hudEdit);
    // отпускаем всё, что могло остаться зажатым
    fireHeld=false; keys['Space']=false; joy.id=null; joy.x=0; joy.y=0;
    stickEl.style.transform='translate(-50%,-50%)';
    if(hudEdit) showBanner('Перетаскивайте кнопки пальцем<br><span style="font-size:18px">Нажмите HUD ещё раз — сохранить</span>', 2600);
    else { writeSave(); showBanner('✔ Раскладка сохранена', 1200); }
}
$('btn-hud-edit').addEventListener('click', ()=>setHudEdit(!hudEdit));
$('btn-hud-move').addEventListener('click', ()=>{ $('graphics-modal').classList.add('hidden'); setHudEdit(true); });

function clampHud(el){
    const w=el.offsetWidth, h=el.offsetHeight;
    let l=parseFloat(el.style.left), t=parseFloat(el.style.top);
    if(isNaN(l)||isNaN(t)) return;
    el.style.left = Math.max(0, Math.min(innerWidth-w, l))+'px';
    el.style.top  = Math.max(0, Math.min(innerHeight-h, t))+'px';
}
function applyHudScale(){
    const sc = save.hudScale;
    for(const k in hudEls){
        if(k==='joy') continue;
        const px = Math.round(hudBase[k]*sc);
        hudEls[k].style.width = px+'px'; hudEls[k].style.height = px+'px';
    }
    $('hud-scale-val').textContent = sc.toFixed(2)+'x';
    $('setting-hud-scale').value = sc;
    for(const k in hudEls) clampHud(hudEls[k]);
}
function applyHudLayout(){
    for(const k in hudEls){
        const p = save.hud[k];
        if(!p || typeof p.x!=='number' || typeof p.y!=='number') continue;
        const el = hudEls[k];
        el.style.left = (p.x*innerWidth)+'px';
        el.style.top  = (p.y*innerHeight)+'px';
        el.style.right='auto'; el.style.bottom='auto';
        clampHud(el);
    }
}
let dragEl=null, dragOX=0, dragOY=0;
for(const k in hudEls){
    const el = hudEls[k];
    el.addEventListener('pointerdown', e=>{
        if(!hudEdit) return;
        e.preventDefault(); e.stopPropagation();
        dragEl=el; el.setPointerCapture(e.pointerId);
        const r=el.getBoundingClientRect();
        dragOX=e.clientX-r.left; dragOY=e.clientY-r.top;
        el.style.left=r.left+'px'; el.style.top=r.top+'px';
        el.style.right='auto'; el.style.bottom='auto';
    });
    el.addEventListener('pointermove', e=>{
        if(!hudEdit || dragEl!==el) return;
        el.style.left=(e.clientX-dragOX)+'px';
        el.style.top=(e.clientY-dragOY)+'px';
        clampHud(el);
    });
    const dragEnd = ()=>{
        if(dragEl!==el) return;
        dragEl=null;
        const r=el.getBoundingClientRect();
        save.hud[k] = { x:r.left/innerWidth, y:r.top/innerHeight };
        writeSave();
    };
    el.addEventListener('pointerup', dragEnd);
    el.addEventListener('pointercancel', dragEnd);
}
$('setting-hud-scale').addEventListener('input', e=>{
    save.hudScale = parseFloat(e.target.value);
    applyHudScale(); writeSave();
});
$('btn-hud-reset').addEventListener('click', ()=>{
    for(const k in hudEls) hudEls[k].style.cssText = hudInit[k];
    save.hud = {}; save.hudScale = 1;
    applyHudScale(); writeSave();
    showBanner('Раскладка сброшена', 1200);
});

// ---------- НАСТРОЙКИ ГРАФИКИ ----------
let fpsCap = 60, preset = 'high';
const rsInput=$('setting-render-scale'), shadowSel=$('setting-shadows'), fpsSel=$('setting-fps-cap'), sensInput=$('setting-sens'), autoChk=$('setting-auto');

function markPreset(p){
    document.querySelectorAll('.preset-btn').forEach(b=>{
        const on = b.dataset.preset===p;
        b.classList.toggle('border-orange-500', on);
        b.classList.toggle('text-orange-400', on);
        b.classList.toggle('border-slate-700', !on);
    });
}
function syncGfxUI(){
    const g = save.gfx;
    const rs = parseFloat(g.rs);
    rsInput.value = (rs>=0.5 && rs<=1.25) ? rs : 1.0;
    shadowSel.value = ['off','low','high','ultra'].includes(g.sh) ? g.sh : 'high';
    fpsSel.value = ['30','60','90','120','0'].includes(String(g.fps)) ? String(g.fps) : '60';
    const se = parseFloat(g.sens);
    sensInput.value = (se>=0.3 && se<=2.5) ? se : 1.0;
    autoChk.checked = g.auto!==false;
    preset = ['low','medium','high','ultra'].includes(g.preset) ? g.preset : null;
    markPreset(preset);
}

function applyGraphics(){
    const scale = parseFloat(rsInput.value);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, 2)*scale);
    renderer.setSize(innerWidth, innerHeight);
    $('render-scale-val').textContent = scale.toFixed(2)+'x';
    const sh = shadowSel.value;
    const shadowsOn = sh!=='off';
    renderer.shadowMap.enabled = shadowsOn;
    sun.castShadow = shadowsOn;
    if(shadowsOn){
        const size = sh==='low'?1024 : sh==='high'?2048 : 4096;
        if(sun.shadow.mapSize.x!==size){
            sun.shadow.mapSize.set(size,size);
            if(sun.shadow.map){ sun.shadow.map.dispose(); sun.shadow.map=null; }
        }
    }
    scene.traverse(o=>{
        if(o.material){ (Array.isArray(o.material)?o.material:[o.material]).forEach(m=>m.needsUpdate=true); }
    });
    fpsCap = parseInt(fpsSel.value,10);
    sensitivity = parseFloat(sensInput.value);
    $('sens-val').textContent = sensitivity.toFixed(1);
    save.gfx = { rs:scale, sh:sh, fps:fpsSel.value, sens:sensitivity, preset:preset, auto:autoChk.checked };
    writeSave();
}
function onManualGfx(){ preset=null; markPreset(null); applyGraphics(); }
[rsInput, shadowSel, fpsSel].forEach(el=>el.addEventListener('change', onManualGfx));
sensInput.addEventListener('input', applyGraphics);
autoChk.addEventListener('change', applyGraphics);

window.setGraphicPreset = function(p){
    const map = {
        low:    { rs:0.5,  sh:'off',  fps:'30'  },
        medium: { rs:0.75, sh:'low',  fps:'60'  },
        high:   { rs:1.0,  sh:'high', fps:'60'  },
        ultra:  { rs:1.25, sh:'ultra',fps:'120' }
    }[p];
    rsInput.value=map.rs; shadowSel.value=map.sh; fpsSel.value=map.fps;
    preset=p; markPreset(p);
    applyGraphics();
};

// Авто-качество: если FPS стабильно ниже цели (60), снижаем нагрузку по шагам
let aqLow=0, aqCool=performance.now()+4000;
function autoQuality(fps, now){
    if(!autoChk.checked || document.hidden || hudEdit || !$('graphics-modal').classList.contains('hidden') || now<aqCool){ aqLow=0; return; }
    const target = fpsCap>0 ? Math.min(fpsCap,60) : 60;
    if(fps >= target*0.88){ aqLow=0; return; }
    if(++aqLow<3) return;
    aqLow=0; aqCool=now+3000;
    const rs=parseFloat(rsInput.value), sh=shadowSel.value;
    if(sh==='ultra') shadowSel.value='high';
    else if(rs>0.75) rsInput.value=rs-0.25;
    else if(sh==='high') shadowSel.value='low';
    else if(rs>0.5) rsInput.value=rs-0.25;
    else if(sh==='low') shadowSel.value='off';
    else return;
    onManualGfx();
    showBanner('Авто-качество: снижена нагрузка для 60 FPS', 1500);
}

$('btn-graphics').addEventListener('click', ()=>$('graphics-modal').classList.remove('hidden'));
$('close-graphics-btn').addEventListener('click', ()=>$('graphics-modal').classList.add('hidden'));
$('btn-fullscreen').addEventListener('click', ()=>{
    if(document.fullscreenElement) document.exitFullscreen();
    else wrapper.requestFullscreen && wrapper.requestFullscreen();
});

// ---------- КОЛЛИЗИИ ----------
function resolveCollisions(p, r){
    for(const c of colliders){
        const cx = Math.max(c.minX, Math.min(p.x, c.maxX));
        const cz = Math.max(c.minZ, Math.min(p.z, c.maxZ));
        const dx = p.x-cx, dz = p.z-cz;
        const d2 = dx*dx+dz*dz;
        if(d2 < r*r){
            if(d2>1e-6){
                const d=Math.sqrt(d2), push=r-d;
                p.x += dx/d*push; p.z += dz/d*push;
            } else {
                // внутри бокса — выталкиваем по минимальной оси
                const ox = Math.min(p.x-c.minX+r, c.maxX+r-p.x);
                const oz = Math.min(p.z-c.minZ+r, c.maxZ+r-p.z);
                if(ox<oz) p.x = (p.x-c.minX < c.maxX-p.x) ? c.minX-r : c.maxX+r;
                else p.z = (p.z-c.minZ < c.maxZ-p.z) ? c.minZ-r : c.maxZ+r;
            }
        }
    }
    p.x = Math.max(-WORLD+1, Math.min(WORLD-1, p.x));
    p.z = Math.max(-WORLD+1, Math.min(WORLD-1, p.z));
}

// ---------- МИНИКАРТА ----------
function drawMinimap(){
    const S = minimap.width;
    mmCtx.clearRect(0,0,S,S);
    mmCtx.fillStyle='rgba(10,14,20,0.92)';
    mmCtx.beginPath(); mmCtx.arc(S/2,S/2,S/2,0,Math.PI*2); mmCtx.fill();
    const k = S/(WORLD*2);
    mmCtx.fillStyle='rgba(120,140,170,0.75)';
    for(const c of colliders){
        mmCtx.fillRect((c.minX+WORLD)*k, (c.minZ+WORLD)*k, (c.maxX-c.minX)*k, (c.maxZ-c.minZ)*k);
    }
    // боты: союзники синие, враги красные
    for(const b of bots){
        if(b.dead) continue;
        mmCtx.fillStyle = b.team==='ally' ? '#38bdf8' : '#ff5544';
        const bx=(b.grp.position.x+WORLD)*k, bz=(b.grp.position.z+WORLD)*k;
        mmCtx.beginPath(); mmCtx.arc(bx,bz,b.team==='ally'?2.2:1.8,0,Math.PI*2); mmCtx.fill();
    }
    // игрок (стрелка)
    const px=(player.pos.x+WORLD)*k, pz=(player.pos.z+WORLD)*k;
    mmCtx.save();
    mmCtx.translate(px,pz);
    mmCtx.rotate(-player.yaw);
    mmCtx.fillStyle='#38e8ff';
    mmCtx.beginPath(); mmCtx.moveTo(0,-3.5); mmCtx.lineTo(2.5,2.5); mmCtx.lineTo(-2.5,2.5); mmCtx.closePath(); mmCtx.fill();
    mmCtx.restore();
}

const tmpV = new THREE.Vector3();
// ---------- БОТ ИИ ----------
const aiRay = new THREE.Raycaster();
const aiFrom = new THREE.Vector3(), aiTo = new THREE.Vector3(), aiDir = new THREE.Vector3();
const posOf = t => t===player ? player.pos : t.grp.position;

function canSee(a, b){
    aiFrom.set(a.x, 1.5, a.z); aiTo.set(b.x, 1.5, b.z);
    aiDir.subVectors(aiTo, aiFrom); const d = aiDir.length(); if(d<0.01) return true;
    aiDir.divideScalar(d);
    aiRay.set(aiFrom, aiDir); aiRay.near = 0.1; aiRay.far = d;
    return aiRay.intersectObjects(wallMeshes,false).length===0;
}

function findEnemy(bot){
    const me = bot.grp.position;
    let best = null, bd = 42;
    const consider = t => {
        const p = posOf(t), d = Math.hypot(p.x-me.x, p.z-me.z);
        if(d<bd && canSee(me,p)){ bd=d; best=t; }
    };
    if(bot.team==='enemy'){
        if(player.alive) consider(player);
        for(const o of bots) if(o.team==='ally' && !o.dead) consider(o);
    } else {
        for(const o of bots) if(o.team==='enemy' && !o.dead) consider(o);
    }
    bot.enemy = best; bot.enemyDist = bd;
}

function randomPoint(){
    let nx, nz, t=0;
    do{ nx=(Math.random()*2-1)*(WORLD-3); nz=(Math.random()*2-1)*(WORLD-3); t++; }
    while(t<15 && pointInCollider(nx,nz,0.8));
    return [nx,nz];
}

function botShoot(bot, tgt, dist){
    const isP = tgt===player, tp = posOf(tgt);
    const base = bot.team==='ally' ? 0.5 : 0.4;
    const hit = Math.random() < Math.max(0.1, base - dist*0.008);
    const from = bot.grp.position.clone(); from.y = 1.35;
    const to = new THREE.Vector3(tp.x, isP ? player.eyeH*0.85 : 1.2, tp.z);
    if(!hit){ to.x += (Math.random()*2-1)*2.2; to.y += (Math.random()*2-1)*1.2; to.z += (Math.random()*2-1)*2.2; }
    spawnTracer(from, to, bot.team==='ally' ? 0x7ab8ff : 0xff8866);
    if(!hit) return;
    if(isP) applyDamage(7+Math.random()*7, bot);
    else damageBot(tgt, 22+Math.random()*14, Math.random()<0.15?'head':'body', bot);
}

function updateBot(bot, dt){
    const g = bot.grp;
    if(bot.dead){
        bot.respawnT -= dt;
        if(bot.respawnT<=0 && !matchOver) respawnBot(bot);
        return;
    }
    bot.checkT -= dt;
    if(bot.checkT<=0){ bot.checkT = 0.3 + Math.random()*0.15; findEnemy(bot); }
    // цель могла умереть
    if(bot.enemy && ((bot.enemy===player && !player.alive) || (bot.enemy!==player && bot.enemy.dead))) bot.enemy = null;

    let mvx=0, mvz=0;
    const speed = bot.team==='ally' ? 3.5 : 3.1;

    if(bot.enemy){
        const tp = posOf(bot.enemy);
        const ang = Math.atan2(tp.x-g.position.x, tp.z-g.position.z);
        g.rotation.y = ang;
        const dist = Math.hypot(tp.x-g.position.x, tp.z-g.position.z);
        bot.enemyDist = dist;
        bot.strafeT -= dt;
        if(bot.strafeT<=0){ bot.strafeT = 1+Math.random()*1.5; bot.strafe *= -1; }
        const ideal = 14;
        const toward = dist>ideal ? 1 : (dist<ideal-5 ? -1 : 0);
        mvx = Math.sin(ang)*toward + Math.cos(ang)*bot.strafe*0.8;
        mvz = Math.cos(ang)*toward - Math.sin(ang)*bot.strafe*0.8;
        bot.fireCd -= dt;
        if(bot.fireCd<=0){
            bot.fireCd = 0.7 + Math.random()*0.8;
            botShoot(bot, bot.enemy, dist);
        }
    } else {
        // нет цели: союзники держатся рядом с игроком, враги патрулируют и давят
        let gx, gz;
        if(bot.team==='ally' && player.alive){
            const a = bot.slot*1.05 + player.yaw*0 ;
            gx = player.pos.x + Math.cos(a)*4.5; gz = player.pos.z + Math.sin(a)*4.5;
            bot.target.set(gx,0,gz);
        } else {
            tmpV.set(bot.target.x-g.position.x, 0, bot.target.z-g.position.z);
            if(tmpV.length()<1.4){
                let p;
                if(bot.team==='enemy' && Math.random()<0.5){
                    const pool = [player.alive?player.pos:null].concat(bots.filter(o=>o.team==='ally'&&!o.dead).map(o=>o.grp.position)).filter(Boolean);
                    const t = pool.length ? pool[Math.floor(Math.random()*pool.length)] : null;
                    p = t ? [t.x+(Math.random()-0.5)*10, t.z+(Math.random()-0.5)*10] : randomPoint();
                    if(pointInCollider(p[0],p[1],0.8)) p = randomPoint();
                } else p = randomPoint();
                bot.target.set(Math.max(-WORLD+2,Math.min(WORLD-2,p[0])),0,Math.max(-WORLD+2,Math.min(WORLD-2,p[1])));
            }
        }
        tmpV.set(bot.target.x-g.position.x, 0, bot.target.z-g.position.z);
        const d = tmpV.length();
        if(d>(bot.team==='ally'?1.6:1.0)){
            tmpV.normalize(); mvx=tmpV.x; mvz=tmpV.z;
            g.rotation.y = Math.atan2(mvx, mvz);
            // застрял -> новая точка
            bot.stuckT += dt;
            if(bot.stuckT>0.6){
                if(Math.hypot(g.position.x-bot.lastX, g.position.z-bot.lastZ)<0.25){
                    const p = randomPoint(); bot.target.set(p[0],0,p[1]);
                    bot.strafe *= -1;
                }
                bot.stuckT = 0; bot.lastX = g.position.x; bot.lastZ = g.position.z;
            }
        }
    }
    const len = Math.hypot(mvx,mvz);
    if(len>0.01){
        const sp = (bot.enemy?0.85:1) * speed;
        g.position.x += mvx/len*sp*dt;
        g.position.z += mvz/len*sp*dt;
        resolveCollisions(g.position, 0.45);
    }
    // отталкивание от других ботов и игрока
    for(const o of bots){
        if(o===bot || o.dead) continue;
        const dx=g.position.x-o.grp.position.x, dz=g.position.z-o.grp.position.z;
        const d2=dx*dx+dz*dz;
        if(d2<0.81 && d2>1e-4){
            const d=Math.sqrt(d2), push=(0.9-d)*0.5;
            g.position.x+=dx/d*push; g.position.z+=dz/d*push;
        }
    }
    if(player.alive){
        const dx=g.position.x-player.pos.x, dz=g.position.z-player.pos.z, d2=dx*dx+dz*dz;
        if(d2<0.64 && d2>1e-4){ const d=Math.sqrt(d2), push=(0.8-d)*0.5; g.position.x+=dx/d*push; g.position.z+=dz/d*push; }
    }
    bot.body.position.y = 0.85 + Math.sin(performance.now()*0.008 + bot.id)*0.03;
}

// ---------- ОБНОВЛЕНИЕ ИГРОКА ----------
const chArms = { top:$('ch-top'), bottom:$('ch-bottom'), left:$('ch-left'), right:$('ch-right') };
[chArms.top,chArms.bottom,chArms.left,chArms.right].forEach(a=>{
    a.style.transform='translate(-50%,-50%)'; a.style.left='50%'; a.style.top='50%';
});

function updatePlayer(dt, now){
    // ввод
    let f = (keys['KeyW']?1:0)-(keys['KeyS']?1:0) + (-joy.y);
    let s = (keys['KeyD']?1:0)-(keys['KeyA']?1:0) + joy.x;
    const fl = Math.hypot(f,s);
    if(fl>1){ f/=fl; s/=fl; }
    const speed = player.crouch?2.6:5.4;
    const sinY=Math.sin(player.yaw), cosY=Math.cos(player.yaw);
    const mx = (-sinY*f + cosY*s)*speed;
    const mz = (-cosY*f - sinY*s)*speed;
    player.vel.x = mx; player.vel.z = mz;
    // гравитация и прыжок
    player.vel.y -= 22*dt;
    if(keys['Space'] && player.onGround){ player.vel.y=7.5; player.onGround=false; }
    player.pos.x += player.vel.x*dt;
    player.pos.z += player.vel.z*dt;
    player.pos.y += player.vel.y*dt;
    if(player.pos.y<=0){ player.pos.y=0; player.vel.y=0; player.onGround=true; }
    resolveCollisions(player.pos, 0.4);

    // камера
    const targetEye = player.crouch?1.08:1.7;
    player.eyeH += (targetEye-player.eyeH)*Math.min(1, dt*10);
    camera.position.set(player.pos.x, player.pos.y+player.eyeH, player.pos.z);
    camera.rotation.y = player.yaw;
    camera.rotation.x = player.pitch;

    // авто-огонь
    if(fireHeld && WEAPONS[curWeapon].auto) tryFire(now);

    // fov / прицел
    const W = WEAPONS[curWeapon];
    const targetFov = aiming ? W.aimFov : 75;
    camera.fov += (targetFov-camera.fov)*Math.min(1, dt*12);
    camera.updateProjectionMatrix();
    const scoped = W.scoped && aiming;
    scopeEl.style.display = scoped ? 'block' : 'none';
    crosshairEl.style.opacity = scoped ? '0' : '1';
    gunGroup.visible = !scoped;

    // откат оружия
    gunGroup.position.z += (-0.35-gunGroup.position.z)*Math.min(1, dt*8);
    gunGroup.rotation.x += ((reloading?0.5:0)-gunGroup.rotation.x)*Math.min(1, dt*6);

    // блум прицела
    bloom = Math.max(0, bloom - dt*1.6);
    const moveSpread = Math.min(8, Math.hypot(player.vel.x,player.vel.z)*1.1);
    const gap = 8 + bloom*14 + moveSpread;
    chArms.top.style.top = 'calc(50% - '+gap+'px)';
    chArms.bottom.style.top = 'calc(50% + '+gap+'px)';
    chArms.left.style.left = 'calc(50% - '+gap+'px)';
    chArms.right.style.left = 'calc(50% + '+gap+'px)';

    // дыхание
    if(player.alive && Math.hypot(player.vel.x,player.vel.z)>0.5 && player.onGround){
        camera.position.y += Math.sin(now*0.012)*0.02;
    }
}

// ---------- FPS-МЕТР ----------
const frameTimes = [];
let fpsAccum=0, fpsFrames=0, lastFpsUpdate=performance.now();

function updateFps(dt, now){
    fpsAccum+=dt; fpsFrames++;
    frameTimes.push(dt*1000);
    if(frameTimes.length>55) frameTimes.shift();
    if(now-lastFpsUpdate>=500){
        const fps = Math.round(fpsFrames/fpsAccum);
        fpsVal.textContent = fps;
        autoQuality(fps, now);
        fpsVal.className = fps>=50?'text-green-400':(fps>=30?'text-amber-400':'text-red-400');
        frameTimeEl.textContent = (fpsAccum/fpsFrames*1000).toFixed(1);
        fpsAccum=0; fpsFrames=0; lastFpsUpdate=now;
        // график
        fgCtx.clearRect(0,0,110,30);
        const max=40;
        frameTimes.forEach((ms,i)=>{
            const h=Math.min(30, ms/max*30);
            fgCtx.fillStyle = ms<20?'#4ade80':(ms<33?'#fbbf24':'#f87171');
            fgCtx.fillRect(108-i*2, 30-h, 1.6, h);
        });
    }
}

// ---------- MAIN LOOP ----------
let lastRender = 0, prevFrame = 0;
function loop(now){
    requestAnimationFrame(loop);
    const interval = fpsCap>0 ? 1000/fpsCap : 0;
    const elapsed = now - lastRender;
    if(elapsed < interval - 1) return;           // ещё рано (допуск 1 мс на джиттер)
    // компенсация дрейфа: ровный ритм 60 кадров на экранах 60/90/120 Гц
    lastRender = (interval && elapsed < interval*4) ? now - (elapsed % interval) : now;
    let dt = (now - prevFrame)/1000;
    prevFrame = now;
    if(dt>0.05) dt=0.05;
    if(dt<=0) dt=0.001;

    if(player.alive) updatePlayer(dt, now);
    else { camera.rotation.y += dt*0.4; }

    for(let i=bots.length-1;i>=0;i--) updateBot(bots[i], dt);
    entityCount.textContent = countAlive('ally')+' / '+countAlive('enemy');

    // трассеры
    for(let i=tracers.length-1;i>=0;i--){
        const t=tracers[i];
        t.life-=dt;
        if(t.life<=0){ scene.remove(t.line); t.line.geometry.dispose(); t.line.material.dispose(); tracers.splice(i,1); }
        else t.line.material.opacity = t.life/0.07*0.9;
    }
    muzzleLight.intensity = Math.max(0, muzzleLight.intensity - dt*30);

    drawMinimap();
    updateFps(dt, now);
    renderer.render(scene, camera);
}

// ---------- RESIZE ----------
function onResize(){
    camera.aspect = innerWidth/innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight);
    for(const k in hudEls) clampHud(hudEls[k]);
}
addEventListener('resize', onResize);

// ---------- INIT ----------
if('ontouchstart' in window) $('desktop-hint').style.display='none';
loadSave();
syncGfxUI();
onResize();
applyGraphics();
applyHudScale();
applyHudLayout();
switchWeapon(save.weapon);
createTeams();
updateAmmoHUD();
requestAnimationFrame(loop);

})();
