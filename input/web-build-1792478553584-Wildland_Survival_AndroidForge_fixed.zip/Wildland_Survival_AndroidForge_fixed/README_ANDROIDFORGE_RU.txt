Wildland: Survival v0.4 — пакет для AndroidForge (wrapper исправлен)

Исправление v0.4.1:
- заменён сломанный gradlew (ошибка ClassNotFoundException: "-Xmx64m")
  на официальный Gradle 8.7 wrapper + jar
- в манифест добавлен package="com.wildland.survival" (как делал AndroidForge)

Ранее уже было:
- aaptOptions для Godot assets
- OpenGL ES 3, landscape, hardwareAccelerated
- MainActivity extends GodotActivity
- org.godotengine:godot:4.3.0.stable
- project.godot + скрипты в assets/

Загрузка: весь ZIP → AndroidForge → debug APK.
Скрипты игры не менялись.
