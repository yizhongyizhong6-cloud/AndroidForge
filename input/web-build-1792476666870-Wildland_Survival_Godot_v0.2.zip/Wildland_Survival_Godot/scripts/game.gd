extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const CAR_SCRIPT = preload("res://scripts/car.gd")

var player: CharacterBody3D
var car: CharacterBody3D
var inventory := {"Дерево": 0, "Камень": 0, "Волокно": 0}
var trees: Array[Node3D] = []
var stones: Array[Node3D] = []
var nearby: Node3D
var in_car := false

var ui: CanvasLayer
var hud: Control
var main_menu: PanelContainer
var settings_menu: PanelContainer
var inventory_label: Label
var hint_label: Label
var message_label: Label
var action_button: Button
var waiting_action := ""
var sensitivity := 0.008
var button_scale := 1.0
var touch_move := Vector2.ZERO

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    randomize()
    _create_world()
    _create_player()
    _create_car()
    _create_ui()
    _show_main_menu()

func _process(_delta: float) -> void:
    if player and not in_car:
        _find_nearby()
    elif in_car:
        nearby = car
        hint_label.text = "Ты за рулём. Нажми «Действие», чтобы выйти."
        action_button.text = "Выйти"
    if player and not in_car and nearby:
        action_button.text = "Сесть" if nearby == car else "Собрать"
        hint_label.text = "Рядом: машина" if nearby == car else "Рядом: " + str(nearby.get_meta("kind"))
    elif player and not in_car:
        action_button.text = "Действие"
        hint_label.text = "Исследуй остров, собирай ресурсы и строй базу."

func _create_world() -> void:
    var env_node := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = Sky.new()
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.72, 0.78, 0.86)
    env.ambient_light_energy = 0.85
    env_node.environment = env
    add_child(env_node)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52, -28, 0)
    sun.light_energy = 1.15
    add_child(sun)

    var ground := StaticBody3D.new()
    var ground_mesh := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(220, 220)
    ground_mesh.mesh = plane
    var grass := StandardMaterial3D.new()
    grass.albedo_color = Color(0.24, 0.39, 0.20)
    ground_mesh.material_override = grass
    ground.add_child(ground_mesh)
    var ground_collision := CollisionShape3D.new()
    var ground_shape := BoxShape3D.new()
    ground_shape.size = Vector3(220, 1, 220)
    ground_collision.shape = ground_shape
    ground_collision.position.y = -0.5
    ground.add_child(ground_collision)
    add_child(ground)

    _make_road(Vector3(0, 0.015, 0), Vector2(10, 180))
    _make_road(Vector3(0, 0.02, 0), Vector2(180, 10))
    _make_road(Vector3(38, 0.025, 35), Vector2(8, 75))
    _make_road(Vector3(-40, 0.025, -30), Vector2(75, 8))

    for i in range(42):
        var pos := Vector3(randf_range(-85, 85), 0, randf_range(-85, 85))
        if absf(pos.x) < 7 or absf(pos.z) < 7:
            continue
        _make_tree(pos)
    for i in range(30):
        var pos := Vector3(randf_range(-85, 85), 0, randf_range(-85, 85))
        if absf(pos.x) < 7 or absf(pos.z) < 7:
            continue
        _make_stone(pos)

func _make_road(pos: Vector3, size: Vector2) -> void:
    var road := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = size
    road.mesh = mesh
    road.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.16, 0.17, 0.16)
    mat.roughness = 1.0
    road.material_override = mat
    add_child(road)
    # Road markings
    if size.x > size.y:
        for z in range(-int(size.y / 2) + 5, int(size.y / 2), 10):
            var mark := MeshInstance3D.new()
            var mark_mesh := BoxMesh.new()
            mark_mesh.size = Vector3(0.22, 0.025, 4.0)
            mark.mesh = mark_mesh
            mark.position = pos + Vector3(0, 0.025, z)
            var mark_mat := StandardMaterial3D.new()
            mark_mat.albedo_color = Color(0.86, 0.82, 0.58)
            mark.material_override = mark_mat
            add_child(mark)
    else:
        for x in range(-int(size.x / 2) + 5, int(size.x / 2), 10):
            var mark := MeshInstance3D.new()
            var mark_mesh := BoxMesh.new()
            mark_mesh.size = Vector3(4.0, 0.025, 0.22)
            mark.mesh = mark_mesh
            mark.position = pos + Vector3(x, 0.025, 0)
            var mark_mat := StandardMaterial3D.new()
            mark_mat.albedo_color = Color(0.86, 0.82, 0.58)
            mark.material_override = mark_mat
            add_child(mark)

func _make_tree(pos: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.set_meta("kind", "дерево")
    var trunk := MeshInstance3D.new()
    var trunk_mesh := CylinderMesh.new()
    trunk_mesh.top_radius = 0.22
    trunk_mesh.bottom_radius = 0.34
    trunk_mesh.height = 2.2
    trunk.mesh = trunk_mesh
    trunk.position.y = 1.1
    var trunk_mat := StandardMaterial3D.new()
    trunk_mat.albedo_color = Color(0.30, 0.17, 0.09)
    trunk.material_override = trunk_mat
    body.add_child(trunk)
    var crown := MeshInstance3D.new()
    var crown_mesh := SphereMesh.new()
    crown_mesh.radius = 1.25
    crown_mesh.height = 2.2
    crown.mesh = crown_mesh
    crown.position.y = 2.6
    var crown_mat := StandardMaterial3D.new()
    crown_mat.albedo_color = Color(0.12, 0.31, 0.12)
    crown.material_override = crown_mat
    body.add_child(crown)
    var cs := CollisionShape3D.new()
    var shape := CylinderShape3D.new()
    shape.radius = 0.55
    shape.height = 3.2
    cs.shape = shape
    cs.position.y = 1.6
    body.add_child(cs)
    add_child(body)
    trees.append(body)

func _make_stone(pos: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    body.set_meta("kind", "камень")
    var rock := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 0.8
    mesh.height = 1.1
    rock.mesh = mesh
    rock.scale = Vector3(1.25, 0.75, 1.0)
    rock.position.y = 0.45
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.40, 0.42, 0.43)
    rock.material_override = mat
    body.add_child(rock)
    var cs := CollisionShape3D.new()
    var shape := SphereShape3D.new()
    shape.radius = 0.8
    cs.shape = shape
    cs.position.y = 0.45
    body.add_child(cs)
    add_child(body)
    stones.append(body)

func _create_player() -> void:
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PLAYER_SCRIPT)
    player.position = Vector3(3, 0.1, 3)
    add_child(player)
    player.game = self
    player.set_sensitivity(sensitivity)

func _create_car() -> void:
    car = CharacterBody3D.new()
    car.name = "RustStyleCar"
    car.set_script(CAR_SCRIPT)
    car.position = Vector3(5, 0.0, 4)
    add_child(car)

func _create_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    hud = Control.new()
    hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ui.add_child(hud)

    var top := PanelContainer.new()
    top.position = Vector2(16, 16)
    top.custom_minimum_size = Vector2(360, 112)
    hud.add_child(top)
    var top_box := VBoxContainer.new()
    top.add_child(top_box)
    var title := Label.new()
    title.text = "WILDLAND: SURVIVAL"
    title.add_theme_font_size_override("font_size", 22)
    top_box.add_child(title)
    inventory_label = Label.new()
    top_box.add_child(inventory_label)
    hint_label = Label.new()
    top_box.add_child(hint_label)

    message_label = Label.new()
    message_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
    message_label.position = Vector2(-250, 145)
    message_label.size = Vector2(500, 48)
    message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    message_label.add_theme_font_size_override("font_size", 21)
    hud.add_child(message_label)

    action_button = Button.new()
    action_button.text = "Действие"
    action_button.size = Vector2(150, 70) * button_scale
    action_button.anchor_left = 1
    action_button.anchor_right = 1
    action_button.anchor_top = 1
    action_button.anchor_bottom = 1
    action_button.position = Vector2(-175, -100)
    action_button.pressed.connect(_on_action)
    hud.add_child(action_button)

    var craft_button := Button.new()
    craft_button.text = "Крафт"
    craft_button.size = Vector2(125, 62) * button_scale
    craft_button.anchor_left = 1
    craft_button.anchor_right = 1
    craft_button.anchor_top = 1
    craft_button.anchor_bottom = 1
    craft_button.position = Vector2(-315, -95)
    craft_button.pressed.connect(_craft)
    hud.add_child(craft_button)

    var build_button := Button.new()
    build_button.text = "Строить"
    build_button.size = Vector2(125, 62) * button_scale
    build_button.anchor_left = 1
    build_button.anchor_right = 1
    build_button.anchor_top = 1
    build_button.anchor_bottom = 1
    build_button.position = Vector2(-455, -95)
    build_button.pressed.connect(_build_wall)
    hud.add_child(build_button)

    var menu_button := Button.new()
    menu_button.text = "☰"
    menu_button.size = Vector2(64, 56)
    menu_button.anchor_left = 1
    menu_button.anchor_right = 1
    menu_button.position = Vector2(-82, 18)
    menu_button.pressed.connect(_show_pause_menu)
    hud.add_child(menu_button)

    _refresh_inventory()
    _create_main_menu()
    _create_settings_menu()

func _create_main_menu() -> void:
    main_menu = PanelContainer.new()
    main_menu.set_anchors_preset(Control.PRESET_CENTER)
    main_menu.position = Vector2(-210, -210)
    main_menu.size = Vector2(420, 420)
    ui.add_child(main_menu)
    var box := VBoxContainer.new()
    box.alignment = BoxContainer.ALIGNMENT_CENTER
    main_menu.add_child(box)
    var heading := Label.new()
    heading.text = "WILDLAND: SURVIVAL"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 28)
    box.add_child(heading)
    var sub := Label.new()
    sub.text = "Остров. Ресурсы. Строительство. Выживание."
    sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    box.add_child(sub)
    _menu_button(box, "Играть", _start_game)
    _menu_button(box, "Настройки", _open_settings)
    _menu_button(box, "Выйти", _exit_game)

func _create_settings_menu() -> void:
    settings_menu = PanelContainer.new()
    settings_menu.set_anchors_preset(Control.PRESET_CENTER)
    settings_menu.position = Vector2(-250, -260)
    settings_menu.size = Vector2(500, 520)
    ui.add_child(settings_menu)
    var box := VBoxContainer.new()
    settings_menu.add_child(box)
    var heading := Label.new()
    heading.text = "НАСТРОЙКИ УПРАВЛЕНИЯ"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 24)
    box.add_child(heading)

    var sens_label := Label.new()
    sens_label.text = "Чувствительность камеры: %.3f" % sensitivity
    box.add_child(sens_label)
    var sens_slider := HSlider.new()
    sens_slider.min_value = 0.002
    sens_slider.max_value = 0.025
    sens_slider.step = 0.001
    sens_slider.value = sensitivity
    sens_slider.value_changed.connect(func(value: float):
        sensitivity = value
        sens_label.text = "Чувствительность камеры: %.3f" % sensitivity
        player.set_sensitivity(sensitivity)
    )
    box.add_child(sens_slider)

    var size_label := Label.new()
    size_label.text = "Размер кнопок: %.1f×" % button_scale
    box.add_child(size_label)
    var size_slider := HSlider.new()
    size_slider.min_value = 0.75
    size_slider.max_value = 1.5
    size_slider.step = 0.05
    size_slider.value = button_scale
    size_slider.value_changed.connect(func(value: float):
        button_scale = value
        size_label.text = "Размер кнопок: %.1f×" % button_scale
        _resize_hud_buttons()
    )
    box.add_child(size_slider)

    var controls_title := Label.new()
    controls_title.text = "Клавиатура (для теста на ПК)"
    box.add_child(controls_title)
    _add_rebind_button(box, "Вперёд", "move_forward")
    _add_rebind_button(box, "Назад", "move_back")
    _add_rebind_button(box, "Влево", "move_left")
    _add_rebind_button(box, "Вправо", "move_right")
    var note := Label.new()
    note.text = "На телефоне: слева движение, справа поворот камеры."
    note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    box.add_child(note)
    _menu_button(box, "Назад", _close_settings)

func _menu_button(parent: VBoxContainer, caption: String, callback: Callable) -> void:
    var button := Button.new()
    button.text = caption
    button.custom_minimum_size = Vector2(0, 54)
    button.pressed.connect(callback)
    parent.add_child(button)

func _add_rebind_button(parent: VBoxContainer, caption: String, action: String) -> void:
    var button := Button.new()
    button.text = caption + ": " + _get_action_key(action)
    button.custom_minimum_size.y = 42
    button.pressed.connect(func():
        waiting_action = action
        button.text = caption + ": нажми клавишу..."
    )
    parent.add_child(button)
    button.set_meta("action_name", action)
    button.set_meta("caption", caption)

func _get_action_key(action: String) -> String:
    if not InputMap.has_action(action):
        return "не назначено"
    var events := InputMap.action_get_events(action)
    if events.size() > 0 and events[0] is InputEventKey:
        return OS.get_keycode_string(events[0].physical_keycode)
    return "не назначено"

func _input(event: InputEvent) -> void:
    if waiting_action != "" and event is InputEventKey and event.pressed and not event.echo:
        InputMap.action_erase_events(waiting_action)
        InputMap.action_add_event(waiting_action, event)
        waiting_action = ""
        _refresh_rebind_labels()
        get_viewport().set_input_as_handled()

func _refresh_rebind_labels() -> void:
    _refresh_settings_buttons(settings_menu)

func _refresh_settings_buttons(node: Node) -> void:
    for child in node.get_children():
        if child is Button and child.has_meta("action_name"):
            child.text = str(child.get_meta("caption")) + ": " + _get_action_key(str(child.get_meta("action_name")))
        _refresh_settings_buttons(child)

func _resize_hud_buttons() -> void:
    for child in hud.get_children():
        if child is Button and child != action_button and child.text != "☰":
            child.size = Vector2(125, 62) * button_scale
    action_button.size = Vector2(150, 70) * button_scale

func _show_main_menu() -> void:
    main_menu.visible = true
    settings_menu.visible = false
    hud.visible = false
    get_tree().paused = true

func _show_pause_menu() -> void:
    main_menu.visible = true
    settings_menu.visible = false
    hud.visible = false
    get_tree().paused = true

func _start_game() -> void:
    main_menu.visible = false
    settings_menu.visible = false
    hud.visible = true
    get_tree().paused = false

func _open_settings() -> void:
    main_menu.visible = false
    settings_menu.visible = true
    hud.visible = false

func _close_settings() -> void:
    settings_menu.visible = false
    main_menu.visible = true

func _exit_game() -> void:
    get_tree().quit()

func _find_nearby() -> void:
    nearby = null
    var best := 3.5
    for item in trees + stones:
        if not is_instance_valid(item):
            continue
        var distance := player.global_position.distance_to(item.global_position)
        if distance < best:
            best = distance
            nearby = item
    if car and player.global_position.distance_to(car.global_position) < best:
        nearby = car

func _on_action() -> void:
    if in_car:
        _exit_car()
        return
    if not nearby or not is_instance_valid(nearby):
        _say("Подойди ближе к ресурсу или машине.")
        return
    if nearby == car:
        _enter_car()
        return
    if nearby.get_meta("kind") == "дерево":
        inventory["Дерево"] += randi_range(3, 6)
        trees.erase(nearby)
    else:
        inventory["Камень"] += randi_range(2, 5)
        stones.erase(nearby)
    nearby.queue_free()
    nearby = null
    _refresh_inventory()
    _say("Ресурс собран.")

func _enter_car() -> void:
    in_car = true
    player.visible = false
    player.set_physics_process(false)
    player.global_position = car.global_position
    car.set_driver(player)
    player.set_vehicle_camera(true, car)
    _say("Ты сел в машину. Используй левый стик для езды.")

func _exit_car() -> void:
    in_car = false
    car.clear_driver()
    player.visible = true
    player.set_physics_process(true)
    player.global_position = car.global_position + car.global_transform.basis.x * 2.2 + Vector3.UP
    player.set_vehicle_camera(false, car)
    _say("Ты вышел из машины.")

func _craft() -> void:
    if inventory["Дерево"] >= 5 and inventory["Камень"] >= 3:
        inventory["Дерево"] -= 5
        inventory["Камень"] -= 3
        inventory["Волокно"] += 1
        _refresh_inventory()
        _say("Создан простой инструмент.")
    else:
        _say("Нужно 5 дерева и 3 камня.")

func _build_wall() -> void:
    if inventory["Дерево"] < 12:
        _say("Для стены нужно 12 дерева.")
        return
    inventory["Дерево"] -= 12
    var wall := StaticBody3D.new()
    wall.position = player.global_position - player.global_transform.basis.z * 3
    wall.position.y = 1.2
    wall.rotation.y = player.rotation.y
    var mesh := MeshInstance3D.new()
    var cube := BoxMesh.new()
    cube.size = Vector3(3, 2.4, 0.35)
    mesh.mesh = cube
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.4, 0.25, 0.13)
    mesh.material_override = mat
    wall.add_child(mesh)
    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = cube.size
    collision.shape = shape
    wall.add_child(collision)
    add_child(wall)
    _refresh_inventory()
    _say("Деревянная стена построена.")

func _refresh_inventory() -> void:
    if inventory_label:
        inventory_label.text = "Дерево: %d   Камень: %d   Волокно: %d" % [inventory["Дерево"], inventory["Камень"], inventory["Волокно"]]

func _say(text: String) -> void:
    message_label.text = text
    get_tree().create_timer(2.5).timeout.connect(func(): message_label.text = "")
