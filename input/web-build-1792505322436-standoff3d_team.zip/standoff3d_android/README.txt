Standoff 3D — Android (WebView), командный режим
Вы + 4 бота-союзника (синие, с именами над головой) против 5 вражеских ботов (красные).
Союзники идут за вами, сами ищут и стреляют во врагов; враги патрулируют и давят на вашу команду.
Убитые боты и вы возрождаетесь. Матч до 30 убийств, затем сброс счёта.
Игра лежит в app/src/main/assets/ (index.html, css/, js/).
Сборка: AGP 8.5.2, Gradle 8.7+, JDK 17, compileSdk 34.
Команда: gradle :app:assembleDebug
APK: app/build/outputs/apk/debug/app-debug.apk
Библиотеки (Three.js, Tailwind, FontAwesome) грузятся с CDN — нужен интернет.
